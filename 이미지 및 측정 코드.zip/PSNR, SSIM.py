import cv2
import numpy as np
from skimage.metrics import structural_similarity as ssim

# PSNR 계산 함수
def calculate_psnr(img1, img2):
    img1 = img1.astype(np.float64)
    img2 = img2.astype(np.float64)
    mse = np.mean((img1 - img2) ** 2)
    if mse == 0:
        return float('inf')
    max_pixel = 255.0
    psnr_value = 20 * np.log10(max_pixel / np.sqrt(mse))
    return psnr_value

# SSIM + Luminance / Contrast / Structure 계산 함수
def calculate_ssim_components_with_maps(img1, img2):
    # skimage의 컬러 SSIM (공식 SSIM 값)
    ssim_value, ssim_map = ssim(
        img1,
        img2,
        channel_axis=2,   # 마지막 축이 채널(RGB)
        win_size=7,
        data_range=255,
        full=True
    )

    # 아래부터는 l(x,y), c(x,y), s(x,y) 직접 계산
    img1 = img1.astype(np.float64)
    img2 = img2.astype(np.float64)

    K1, K2 = 0.01, 0.03
    L = 255
    C1 = (K1 * L) ** 2
    C2 = (K2 * L) ** 2
    C3 = C2 / 2
    eps = 1e-12  # 0 나누기/루트 음수 방지용

    # 가우시안 블러로 평균, 분산 근사
    mu1 = cv2.GaussianBlur(img1, (11, 11), 1.5)
    mu2 = cv2.GaussianBlur(img2, (11, 11), 1.5)
    mu1_sq = mu1 * mu1
    mu2_sq = mu2 * mu2
    mu1_mu2 = mu1 * mu2

    sigma1_sq = cv2.GaussianBlur(img1 * img1, (11, 11), 1.5) - mu1_sq
    sigma2_sq = cv2.GaussianBlur(img2 * img2, (11, 11), 1.5) - mu2_sq
    sigma12  = cv2.GaussianBlur(img1 * img2, (11, 11), 1.5) - mu1_mu2

    # 🔹 분산 값이 음수로 살짝 내려가는 부동소수점 오차 보정
    sigma1_sq = np.maximum(sigma1_sq, 0)
    sigma2_sq = np.maximum(sigma2_sq, 0)

    sigma_prod = sigma1_sq * sigma2_sq
    sigma_prod = np.maximum(sigma_prod, 0)  # sqrt 안에 음수 방지

    # 분모가 0 근처인 것 방지
    denom_l = mu1_sq + mu2_sq + C1
    denom_l = np.maximum(denom_l, eps)

    denom_c = sigma1_sq + sigma2_sq + C2
    denom_c = np.maximum(denom_c, eps)

    sqrt_sigma_prod = np.sqrt(sigma_prod)
    denom_s = sqrt_sigma_prod + C3
    denom_s = np.maximum(denom_s, eps)

    # ⬇ 여기서 나오는 값들이 l(x,y), c(x,y), s(x,y) 맵
    l_map = (2 * mu1_mu2 + C1) / denom_l       # luminance(x,y)
    c_map = (2 * sqrt_sigma_prod + C2) / denom_c  # contrast(x,y)
    s_map = (sigma12 + C3) / denom_s           # structure(x,y)

    # 전체 평균값 (보고 있던 Luminance (l), Contrast (c), Structure (s))
    l_mean = float(np.mean(l_map))
    c_mean = float(np.mean(c_map))
    s_mean = float(np.mean(s_map))

    return ssim_value, l_mean, c_mean, s_mean, l_map, c_map, s_map


# --------- 메인 코드 ---------
# 이미지 읽기 (경로만 바꿔서 사용)
img1 = cv2.imread(r"20.png")
img2 = cv2.imread(r"origin al3\dehaze\20o2.png")

if img1 is None or img2 is None:
    raise FileNotFoundError("이미지 경로를 확인하세요.")

# BGR -> RGB
img1 = cv2.cvtColor(img1, cv2.COLOR_BGR2RGB)
img2 = cv2.cvtColor(img2, cv2.COLOR_BGR2RGB)

# 크기 맞추기
if img1.shape != img2.shape:
    print("⚠️ 이미지 크기가 달라서 img2를 img1 크기에 맞춰 리사이즈합니다.")
    img2 = cv2.resize(img2, (img1.shape[1], img1.shape[0]))

# PSNR
psnr_value = calculate_psnr(img1, img2)

# SSIM + 구성 요소 + 맵
ssim_value, l_mean, c_mean, s_mean, l_map, c_map, s_map = calculate_ssim_components_with_maps(img1, img2)

# MSE
mse_value = np.mean((img1.astype(np.float64) - img2.astype(np.float64)) ** 2)

print(f"\n\nMSE: {mse_value:.4f}")
print(f"Luminance (l): {l_mean:.4f}")
print(f"Contrast  (c): {c_mean:.4f}")
print(f"Structure (s): {s_mean:.4f}")
print(f"SSIM : {ssim_value:.6f}")
print(f"PSNR: {psnr_value:.4f} dB")

# =====================================================
# 🔍 여기부터 l(x,y), c(x,y), s(x,y) 값 출력 부분
# =====================================================

print("\n[ l_map 통계 ]")
print(" mean:", float(l_map.mean()))
print("[ c_map 통계 ]")
print(" mean:", float(c_map.mean()))
print("[ s_map 통계 ]")
print(" mean:", float(s_map.mean()))

# 중앙 픽셀 값 한 개 찍어보기
h, w = l_map.shape[:2]
cy, cx = h // 2, w // 2

# 필요하면 주변 3x3 값도 보고 싶을 때 (주석 해제해서 사용)
# print("\n중앙 주변 3x3 영역의 l(x,y) 값:")
# print(l_map[cy-1:cy+2, cx-1:cx+2])

# print("\n중앙 주변 3x3 영역의 c(x,y) 값:")
# print(c_map[cy-1:cy+2, cx-1:cx+2])

# print("\n중앙 주변 3x3 영역의 s(x,y) 값:")
# print(s_map[cy-1:cy+2, cx-1:cx+2])
