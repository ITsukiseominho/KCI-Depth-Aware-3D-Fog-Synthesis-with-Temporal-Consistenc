// VS2022_DefaultDlg.cpp 
//

#include "stdafx.h"
#include "VS2022_Default.h"
#include "VS2022_DefaultDlg.h"
#include "afxdialogex.h"
#include <string>
#include <stdlib.h>


// FFmpeg
extern "C" {
#include <libavcodec/avcodec.h>
#include <libavformat/avformat.h>
#include <libswscale/swscale.h>
#include <libavutil/rational.h>
#include <libavutil/opt.h>
#include <libavutil/imgutils.h>
#include <libavutil/timestamp.h>
#include <libavutil/common.h>
#include <libavutil/channel_layout.h>
#include <libavutil/frame.h>
#include <libavutil/samplefmt.h>
#include <libavutil/error.h>
#include <libavdevice/avdevice.h>
#include <libavutil/avassert.h>
#include <libavutil/mathematics.h>
#include <libswresample/swresample.h>
}


// MP4 save
#include "file_mp4save.h"


// DirectShow - webcam detect
#include <dshow.h>
#pragma comment(lib, "strmiids")
#include <map>
#include "dshow_webcam_detect.h"


// Webcam MP4 save
#include "webcam_mp4save.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////////
#include <stdio.h>
#include <Windows.h>

#define UM_UPDATE WM_USER

#define _FILE_OFFSET_BITS 64


using namespace std;
#pragma warning(disable : 4996)

// MP4 save
// output
AVFormatContext* ofmt_ctx = NULL;
AVFrame* avframe = NULL;
AVPacket* pkt = NULL;
Mat mresultImg;
const char* sfilename = "ffmpeg_save.mp4";
// input
AVFormatContext* ifmt_ctx = NULL;
int stream_index = 0;
int ret = 0;
enum AVMediaType type;
int got_frame;
int video_index = -1;
int audio_index = -1;
// CV -- FFMPEG conversion
struct SwsContext* sws_ctx = NULL;
struct SwsContext* sws_ctx_bgr_yuv = NULL;
int total_frame_count = 0; // avoid blocking
// process according to file extension
bool mp4_found1 = false;
bool mp4_found2 = false;
bool avi_found1 = false;
bool avi_found2 = false;
bool yuv_found1 = false;
bool yuv_found2 = false;
bool ycbcr_found1 = false;
bool ycbcr_found2 = false;


// Webcam detect
std::map<int, Device> aud_devices;
std::map<int, Device> vid_devices;
int audio_id = -1, video_id = -1;


// Webcam MP4 save
OutputStream video_st = { 0 }, audio_st = { 0 };
AVOutputFormat* fmt;
AVFormatContext* oc;
AVCodec* video_codec, * audio_codec;
int have_video = 0, encode_video = 0;
int have_audio = 0, encode_audio = 0;
AVDictionary* opt = NULL;
AVFrame* pFrameRGB = NULL;


HWND hDlgMain;
LPBYTE m_lpDib;
BOOL g_OnOff = TRUE;
BOOL ProcessExitFlag = TRUE;

// Images
Mat SaveImage;
BYTE* frameY;
BYTE* frameU;
BYTE* frameV;
BYTE* frameY1;
BYTE* frameCb;
BYTE* frameCr;

// Class
VideoWriter VideoOut;// = NULL;
VideoWriter VideoOutPro;// = NULL;

// Thread
HANDLE hVideoThread = NULL;
DWORD dwVideoThredID;
DWORD lpdwExitCode;

// Functions
void Initialize();
void Release();
UINT ThreadProcessingAVI(LPVOID lParam);

// Color Converting Output Data
float Conv_Y1, Conv_Cb, Conv_Cr;
float Conv_Y2, Conv_U, Conv_V;
float Conv_R, Conv_G, Conv_B;

int m_radio_read;
int m_radio_write;

//processing operation time for waitkey delay
double elapsed;

//video-audio temp presentation time stamp(for sync)
int temp_video_pts;
int temp_audio_pts;

//Flag signal to prevent thread crash between main <-> sub
int mp4saveflag = 0;
int camstopflag = 0;
int cammp4flag = 0;
int avistopflag = 0;
int repeatprocendflag = 0;

//----------------Test Only-------------//
//FILE *test_RGB;
//FILE *test_YCbCr;
//FILE *test_data;
//--------------------------------------//

CString temp_m_edit_save_fps = 0;
CString temp_m_repeat_processing = 0;
CString temp_m_edit_Video_width = 0;
CString temp_m_edit_Video_height = 0;
CString temp_m_edit_frame_rate = 0;

/////////////////////////////////////////////////////////////////////////////////
//Basic Funtions---------------------------------------------------------------//

LRESULT CVS2022_DefaultDlg::OnUpdateData(WPARAM wParam, LPARAM lParam)
{
	UpdateData(FALSE);

	return 0;
}

CVS2022_DefaultDlg::CVS2022_DefaultDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CVS2022_DefaultDlg::IDD, pParent)
	, m_Y_average(0)
	, m_repeat_processing(_T(""))
	, m_delay_count(0)
	, m_edit_Video_width(_T(""))
	, m_edit_Video_height(_T(""))
	, m_edit_frame_rate(_T(""))
	, m_edit_save_fps(_T(""))
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CVS2022_DefaultDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_STATIC_FRAME_NUM, m_static_frame);
	DDX_Text(pDX, IDC_EDIT_Y_average, m_Y_average);
	DDX_Text(pDX, IDC_EDIT_Repeat_Processing, m_repeat_processing);
	DDX_Text(pDX, IDC_m_delay_count, m_delay_count);
	DDX_Control(pDX, IDC_m_slide_delay_count, m_slide_delay_count);
	DDX_Text(pDX, IDC_EDIT_YUV_WIDTH, m_edit_Video_width);
	DDX_Text(pDX, IDC_EDIT_YUV_HEIGHT, m_edit_Video_height);
	DDX_Text(pDX, IDC_EDIT_YUV_FRAME, m_edit_frame_rate);
	DDX_Text(pDX, IDC_EDIT_SAVE_FPS, m_edit_save_fps);

	DDX_Control(pDX, IDC_SLIDER_MP4_SAVE_COMP_LEVEL, mp4_save_compression_level_slider);
	DDX_Text(pDX, IDC_EDIT_MP4_SAVE_COMP_LEVEL, mp4_save_compression_level);
	DDX_Control(pDX, IDC_COMBO_CAMSEL, mComboBox_CamSel);
	DDX_Control(pDX, IDC_CHECK_SIDEBYSIDE, m_check_sidebysidebutton);
	DDX_Control(pDX, IDC_CHECK_UPANDDOWN, m_check_upanddownbutton);
}

BEGIN_MESSAGE_MAP(CVS2022_DefaultDlg, CDialogEx)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_MESSAGE(UM_UPDATE, OnUpdateData)
	ON_WM_DESTROY()

	//Camera Mode
	ON_BN_CLICKED(IDC_BUTTON_CAM_START, &CVS2022_DefaultDlg::OnButton_CamStart)
	ON_BN_CLICKED(IDC_BUTTON_CAM_STOP, &CVS2022_DefaultDlg::OnButton_CamStop)
	ON_BN_CLICKED(IDC_BUTTON_CAM_CAPTURE, &CVS2022_DefaultDlg::OnButton_CamCapture)
	ON_BN_CLICKED(IDC_BUTTON_CAM_AVISAVE, &CVS2022_DefaultDlg::OnButton_CamMp4save)
	//ON_BN_CLICKED(IDC_BUTTON_CAM_YUVSAVE, &CVS2022_DefaultDlg::OnButton_CamYuvsave)
	//ON_BN_CLICKED(IDC_BUTTON_CAM_YCbCrSAVE, &CVS2022_DefaultDlg::OnButton_CamYcbcrsave)

	//Still Mode
	ON_BN_CLICKED(IDC_BUTTON_FILE_OPEN, &CVS2022_DefaultDlg::OnButton_FileOpen)
	ON_BN_CLICKED(IDC_BUTTON_FILE_RUN, &CVS2022_DefaultDlg::OnButton_FileRun)
	ON_BN_CLICKED(IDC_BUTTON_FILE_CAPTURE, &CVS2022_DefaultDlg::OnButton_FileCapture)

	//AVI Mode
	ON_BN_CLICKED(IDC_BUTTON_AVI_STOP, &CVS2022_DefaultDlg::OnButton_AviStop)
	ON_BN_CLICKED(IDC_BUTTON_AVI_OPEN, &CVS2022_DefaultDlg::OnButton_AviOpen)
	ON_BN_CLICKED(IDC_BUTTON_AVI_RUN, &CVS2022_DefaultDlg::OnButton_AviRun)
	ON_BN_CLICKED(IDC_BUTTON_YUV_OPEN, &CVS2022_DefaultDlg::OnButton_YuvOpen)
	ON_BN_CLICKED(IDC_BUTTON_AVI_PAUSE, &CVS2022_DefaultDlg::OnButton_AviPause)
	ON_BN_CLICKED(IDC_BUTTON_VIDEO_CAPTURE, &CVS2022_DefaultDlg::OnButton_VideoCapture)
	ON_BN_CLICKED(IDC_BUTTON_AVIFORM_SAVE, &CVS2022_DefaultDlg::OnButton_AviSave)
	ON_BN_CLICKED(IDC_BUTTON_YUV_SAVE, &CVS2022_DefaultDlg::OnButton_YuvSave)
	ON_BN_CLICKED(IDC_BUTTON_YCbCr_OPEN, &CVS2022_DefaultDlg::OnButton_YcbcrOpen)

	//Other Control
	ON_NOTIFY(NM_CUSTOMDRAW, IDC_m_slide_delay_count, &CVS2022_DefaultDlg::OnSlide_Delaycount)
	ON_BN_CLICKED(IIDC_BUTTON_default, &CVS2022_DefaultDlg::OnButton_default)
	ON_BN_CLICKED(IDC_CHECK_SIDEBYSIDE, &CVS2022_DefaultDlg::OnCheck_SideBySide)
	ON_BN_CLICKED(IDC_CHECK_UPANDDOWN, &CVS2022_DefaultDlg::OnCheck_UpAndDown)
	ON_BN_CLICKED(IDC_BUTTON_YCbCr_SAVE, &CVS2022_DefaultDlg::OnButton_YcbcrSave)
	ON_BN_CLICKED(IDC_RADIO_YUV444R, &CVS2022_DefaultDlg::OnRadio_Yuv444r)
	ON_BN_CLICKED(IDC_RADIO_YUV422R, &CVS2022_DefaultDlg::OnRadio_Yuv422r)
	ON_BN_CLICKED(IDC_RADIO_YUV420R, &CVS2022_DefaultDlg::OnRadio_Yuv420r)
	ON_BN_CLICKED(IDC_RADIO_YUV444W, &CVS2022_DefaultDlg::OnRadio_Yuv444w)
	ON_BN_CLICKED(IDC_RADIO_YUV422W, &CVS2022_DefaultDlg::OnRadio_Yuv422w)
	ON_BN_CLICKED(IDC_RADIO_YUV420W, &CVS2022_DefaultDlg::OnRadio_Yuv420w)
	ON_EN_CHANGE(IDC_EDIT_YUV_WIDTH, &CVS2022_DefaultDlg::OnEdit_YuvWidth)
	ON_EN_CHANGE(IDC_EDIT_YUV_HEIGHT, &CVS2022_DefaultDlg::OnEdit_YuvHeight)
	ON_EN_CHANGE(IDC_EDIT_YUV_FRAME, &CVS2022_DefaultDlg::OnEdit_YuvFrame)
	ON_EN_CHANGE(IDC_EDIT_SAVE_FPS, &CVS2022_DefaultDlg::OnEdit_SaveFps)
	ON_EN_CHANGE(IDC_EDIT_Repeat_Processing, &CVS2022_DefaultDlg::OnEdit_RepeatProcessing)

	///Scrollbar
	ON_WM_SIZE()
	ON_WM_VSCROLL()
	ON_WM_MOUSEWHEEL()
	//ON_WM_HSCROLL()
	ON_BN_CLICKED(IDC_BUTTON_AVIFORM_SAVE2, &CVS2022_DefaultDlg::OnBnClickedButtonMP4Save)
	ON_NOTIFY(NM_CUSTOMDRAW, IDC_SLIDER_MP4_SAVE_COMP_LEVEL, &CVS2022_DefaultDlg::OnNMCustomdrawSliderMp4SaveCompLevel)
	ON_BN_CLICKED(IDC_BUTTON_CAM_TEST, &CVS2022_DefaultDlg::OnBnClickedButtonCamTest)
	ON_CBN_SELCHANGE(IDC_COMBO_CAMSEL, &CVS2022_DefaultDlg::OnSelchangeComboCamsel)
END_MESSAGE_MAP()

//Init funtion (Run only once for the first time)
BOOL CVS2022_DefaultDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();
	m_pFrame_now = 0;

	/////Scrollbar
	GetWindowRect(m_rect);
	m_nScrollPos = 0;
	m_nHScrollPos = 0;

	// �� ��ȭ ������ �������� �����մϴ�. ���� ���α׷��� �� â�� ��ȭ ���ڰ� �ƴ� ��쿡��
	//  �����ӿ�ũ�� �� �۾��� �ڵ����� �����մϴ�.
	//SetIcon(m_hIcon, TRUE);			// ū �������� �����մϴ�.
	SetIcon(m_hIcon, FALSE);		// ���� �������� �����մϴ�.

	hDlgMain = this->m_hWnd;

	SaveImage = Mat(480, 640, CV_8UC3);

	// Cam
	GetDlgItem(IDC_BUTTON_CAM_START)->EnableWindow(0);
	GetDlgItem(IDC_BUTTON_CAM_STOP)->EnableWindow(0);
	GetDlgItem(IDC_BUTTON_CAM_CAPTURE)->EnableWindow(0);
	//GetDlgItem(IDC_BUTTON_CAM_YUVSAVE)->EnableWindow(0);
	GetDlgItem(IDC_BUTTON_CAM_AVISAVE)->EnableWindow(0);
	//GetDlgItem(IDC_BUTTON_CAM_YCbCrSAVE)->EnableWindow(0);

	// File
	GetDlgItem(IDC_BUTTON_FILE_RUN)->EnableWindow(0);
	GetDlgItem(IDC_BUTTON_FILE_CAPTURE)->EnableWindow(0);

	// Avi
	GetDlgItem(IDC_BUTTON_AVI_RUN)->EnableWindow(0);
	GetDlgItem(IDC_BUTTON_AVI_PAUSE)->EnableWindow(0);
	GetDlgItem(IDC_BUTTON_YUV_SAVE)->EnableWindow(0);
	GetDlgItem(IDC_BUTTON_AVI_STOP)->EnableWindow(0);
	GetDlgItem(IDC_BUTTON_VIDEO_CAPTURE)->EnableWindow(0);
	GetDlgItem(IDC_BUTTON_AVIFORM_SAVE)->EnableWindow(0);
	GetDlgItem(IDC_BUTTON_YCbCr_SAVE)->EnableWindow(0);
	GetDlgItem(IDC_BUTTON_AVIFORM_SAVE2)->EnableWindow(0);

	//Video Format
	GetDlgItem(IDC_EDIT_YUV_HEIGHT)->EnableWindow(1);
	GetDlgItem(IDC_EDIT_YUV_WIDTH)->EnableWindow(1);
	GetDlgItem(IDC_EDIT_YUV_FRAME)->EnableWindow(1);

	GetDlgItem(IDC_RADIO_YUV444R)->EnableWindow(1);
	GetDlgItem(IDC_RADIO_YUV422R)->EnableWindow(1);
	GetDlgItem(IDC_RADIO_YUV420R)->EnableWindow(1);

	GetDlgItem(IDC_RADIO_YUV444W)->EnableWindow(1);
	GetDlgItem(IDC_RADIO_YUV422W)->EnableWindow(1);
	GetDlgItem(IDC_RADIO_YUV420W)->EnableWindow(1);

	//save option
	CheckDlgButton(IDC_CHECK_SIDEBYSIDE, BST_UNCHECKED);
	CheckDlgButton(IDC_CHECK_UPANDDOWN, BST_UNCHECKED);

	GetDlgItem(IDC_CHECK_SIDEBYSIDE)->EnableWindow(1);
	GetDlgItem(IDC_CHECK_UPANDDOWN)->EnableWindow(1);



	/////////////////////////////////////////////////////////////
	GetDlgItem(IDC_EDIT_Repeat_Processing)->EnableWindow(0);
	GetDlgItem(IDC_EDIT_SAVE_FPS)->EnableWindow(0);
	/////////////////////////////////////////////////////////////

	m_edit_Video_height.Format("480");
	m_edit_Video_width.Format("640");
	m_edit_frame_rate.Format("30");

	/////////////////////////////////////////////////////////////
	m_edit_save_fps.Format("30");
	m_repeat_processing.Format("1");
	/////////////////////////////////////////////////////////////
	m_radio_read = 0;
	m_radio_write = 0;
	m_frame_num = 0;
	m_run_mode = 0;
	m_width = 640;
	m_height = 480;
	m_pFrame_now = 0;
	m_pFrame_end = 0;
	m_totalFrame = 0;

	avi_save = FALSE;
	mp4_save = FALSE;
	yuv_save = FALSE;
	ycbcr_save = FALSE;
	save_over = FALSE;
	cam_mp4_save = FALSE;

	m_check_sidebyside = FALSE;
	m_check_upanddown = FALSE;

	m_bAviPause = FALSE;
	m_bAviStop = FALSE;
	m_bYUVSave = FALSE;

	m_bAvi_Save_Stop = FALSE;

	m_bYCbCrSave = FALSE;
	m_capture_flag = FALSE;

	//m_pCapture = NULL;

	CButton* control1 = (CButton*)GetDlgItem(IDC_RADIO_YUV444R);
	control1->SetCheck(1);

	CButton* control2 = (CButton*)GetDlgItem(IDC_RADIO_YUV444W);
	control2->SetCheck(1);

	CWnd* pStatic = GetDlgItem(IDC_STATIC_VIEW);
	pStatic->SetWindowPos(NULL, 0, 0, 640, 480, SWP_SHOWWINDOW); // 왼쪾 영상

	pStatic = GetDlgItem(IDC_STATIC_VIEW2);
	pStatic->SetWindowPos(NULL, 645, 0, 640, 480, SWP_SHOWWINDOW); //오른쪽 영상

	m_static_frame
		.SetBkColor(RGB(100, 200, 100))
		.SetText("frame:")
		.SetTextColor(RGB(255, 255, 255))
		.SetFontBold(TRUE)
		.SetFontName("Book Antiqua")
		.SetFontSize(20)
		.SetSunken(TRUE)
		.SetBorder(TRUE);


	// Get Release File path ====================//
	TCHAR path[_MAX_PATH];
	GetModuleFileName(NULL, path, sizeof(path));

	m_ReleasePath = path;
	int k = m_ReleasePath.ReverseFind('\\');
	m_ReleasePath = m_ReleasePath.Left(k);



	OnButton_default();
	// Color Converting ============================================================
	// RGB2YCbCr Look-up Table
	int i;

	y1_r_lut = new float[256];
	y1_g_lut = new float[256];
	y1_b_lut = new float[256];
	cb_r_lut = new float[256];
	cb_g_lut = new float[256];
	cb_b_lut = new float[256];
	cr_r_lut = new float[256];
	cr_g_lut = new float[256];
	cr_b_lut = new float[256];

	// YCbCr2RGB Look-up Table	
	r_y1_lut = new float[256];
	r_cb_lut = new float[256];
	r_cr_lut = new float[256];
	g_y1_lut = new float[256];
	g_cb_lut = new float[256];
	g_cr_lut = new float[256];
	b_y1_lut = new float[256];
	b_cb_lut = new float[256];

	// RGB2YUV 
	y2_r_lut = new float[256];
	y2_g_lut = new float[256];
	y2_b_lut = new float[256];
	u_r_lut = new float[256];
	u_g_lut = new float[256];
	u_b_lut = new float[256];
	v_r_lut = new float[256];
	v_g_lut = new float[256];
	v_b_lut = new float[256];

	// YUV2RGB
	r_y2_lut = new float[256];
	r_v_lut = new float[256];
	g_y2_lut = new float[256];
	g_u_lut = new float[256];
	g_v_lut = new float[256];
	b_y2_lut = new float[256];
	b_u_lut = new float[256];

	// make lut RGB <-> YCbCr -----------------------------
	for (i = 0; i < 256; i++)
	{	// RGB to YCbCr
		y1_r_lut[i] = float(i) * 0.299f;
		y1_g_lut[i] = float(i) * 0.587f;
		y1_b_lut[i] = float(i) * 0.114f;

		cb_r_lut[i] = float(i) * -0.168736f;
		cb_g_lut[i] = float(i) * -0.331264f;
		cb_b_lut[i] = float(i) * 0.500f;

		cr_r_lut[i] = float(i) * 0.500f;
		cr_g_lut[i] = float(i) * -0.418688f;
		cr_b_lut[i] = float(i) * -0.081312f;

		// YCbCr to RGB
		r_y1_lut[i] = float(i);
		r_cb_lut[i] = float(i) * -0.000001f;
		r_cr_lut[i] = 1.402f * (float(i) - 128.0f);

		g_y1_lut[i] = float(i);
		g_cb_lut[i] = -0.344136f * (float(i) - 128.0f);
		g_cr_lut[i] = -0.714136f * (float(i) - 128.0f);

		b_y1_lut[i] = float(i);
		b_cb_lut[i] = 1.772f * (float(i) - 128.0f);

		// RGB to YUV
		y2_r_lut[i] = float(i) * 0.257f;
		y2_g_lut[i] = float(i) * 0.504f;
		y2_b_lut[i] = float(i) * 0.098f;

		u_r_lut[i] = float(i) * -0.148f;
		u_g_lut[i] = float(i) * -0.291f;
		u_b_lut[i] = float(i) * 0.439f;

		v_r_lut[i] = float(i) * 0.439f;
		v_g_lut[i] = float(i) * -0.368f;
		v_b_lut[i] = float(i) * -0.071f;

		// YUV to RGB
		r_y2_lut[i] = 1.164f * (float(i) - 16.0f);
		r_v_lut[i] = 1.596f * (float(i) - 128.0f);

		g_y2_lut[i] = 1.164f * (float(i) - 16.0f);
		g_u_lut[i] = -0.319f * (float(i) - 128.0f);
		g_v_lut[i] = -0.813f * (float(i) - 128.0f);

		b_y2_lut[i] = 1.164f * (float(i) - 16.0f);
		b_u_lut[i] = 2.018f * (float(i) - 128.0f);
	}

	// FFmpeg initialization
	avcodec_register_all();
	avdevice_register_all(); // for camera mode to find dshow devices
	av_register_all();

	// warning messages
	s.Format("====== Caution on Camera Mode ======");
	Memo_Write(s);
	s.Format("Platform may crash if Visual C++ or Windows");
	Memo_Write(s);
	s.Format("version is not up-to-date.");
	Memo_Write(s);
	Memo_Write("============================");
	UpdateData(FALSE);




	return TRUE;  // ��Ŀ���� ��Ʈ�ѿ� �������� ������ TRUE�� ��ȯ�մϴ�.
}

void CVS2022_DefaultDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // �׸��⸦ ���� ����̽� ���ؽ�Ʈ�Դϴ�.

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Ŭ���̾�Ʈ �簢������ �������� ����� ����ϴ�.
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// �������� �׸��ϴ�.
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

HCURSOR CVS2022_DefaultDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

//Extinction function (when turn off program)
void CVS2022_DefaultDlg::OnDestroy()
{
	CDialogEx::OnDestroy();

	// RGB <-> YCbCr
	delete[] y1_r_lut;
	delete[] y1_g_lut;
	delete[] y1_b_lut;
	delete[] cb_r_lut;
	delete[] cb_g_lut;
	delete[] cb_b_lut;
	delete[] cr_r_lut;
	delete[] cr_g_lut;
	delete[] cr_b_lut;

	delete[] r_y1_lut;
	delete[] r_cb_lut;
	delete[] r_cr_lut;
	delete[] g_y1_lut;
	delete[] g_cb_lut;
	delete[] g_cr_lut;
	delete[] b_y1_lut;
	delete[] b_cb_lut;

	// RGB <-> YUV
	delete[] y2_r_lut;
	delete[] y2_g_lut;
	delete[] y2_b_lut;
	delete[] u_r_lut;
	delete[] u_g_lut;
	delete[] u_b_lut;
	delete[] v_r_lut;
	delete[] v_g_lut;
	delete[] v_b_lut;

	delete[] r_y2_lut;
	delete[] r_v_lut;
	delete[] g_y2_lut;
	delete[] g_u_lut;
	delete[] g_v_lut;
	delete[] b_y2_lut;
	delete[] b_u_lut;

}

//----------------------------------------------------------Basic Funtions Ends//
/////////////////////////////////////////////////////////////////////////////////



/////////////////////////////////////////////////////////////////////////////////
//Funtion related to button for file open, save, start proc, etc.--------------//

//Cam
void CVS2022_DefaultDlg::OnButton_CamStart()
{
	m_bAviStop = FALSE;
	OnModeInit();

	m_check_sidebyside = FALSE;
	m_check_upanddown = FALSE;
	CheckDlgButton(IDC_CHECK_SIDEBYSIDE, BST_UNCHECKED);
	CheckDlgButton(IDC_CHECK_UPANDDOWN, BST_UNCHECKED);

	GetDlgItem(IDC_BUTTON_CAM_START)->EnableWindow(0);
	GetDlgItem(IDC_BUTTON_CAM_STOP)->EnableWindow(1);
	GetDlgItem(IDC_BUTTON_CAM_CAPTURE)->EnableWindow(1);
	GetDlgItem(IDC_BUTTON_CAM_AVISAVE)->EnableWindow(1);
	GetDlgItem(IDC_COMBO_CAMSEL)->EnableWindow(0);

	GetDlgItem(IDC_CHECK_SIDEBYSIDE)->EnableWindow(0);
	GetDlgItem(IDC_CHECK_UPANDDOWN)->EnableWindow(0);
	//GetDlgItem(IDC_BUTTON_AVI_OPEN)->EnableWindow(0);
	//GetDlgItem(IDC_BUTTON_YUV_OPEN)->EnableWindow(0);
	//GetDlgItem(IDC_BUTTON_YCbCr_OPEN)->EnableWindow(0);
	//GetDlgItem(IDC_BUTTON_FILE_OPEN)->EnableWindow(0);
	GetDlgItem(IDC_EDIT_SAVE_FPS)->EnableWindow(1);

	AVInputFormat* fmt = av_find_input_format("dshow");
	if (!fmt) {
		Memo_Write("Could not find DirectShow device!");
		// Cam
		GetDlgItem(IDC_BUTTON_CAM_START)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_CAM_TEST)->EnableWindow(1);
		GetDlgItem(IDC_BUTTON_CAM_STOP)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_CAM_CAPTURE)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_CAM_AVISAVE)->EnableWindow(0);
		return;
	}

	Memo_Write("Camera Start");

	//s.Format("video=HD Pro Webcam C920:audio=마이크 (HD Pro Webcam C920)");
	//s.Format("video=%s", vid_devices[video_id].deviceName);
	//s.Append(":");
	//s.AppendFormat("audio=%s", aud_devices[audio_id].deviceName);
	//Memo_Write(s);
	//ret = avformat_open_input(&ifmt_ctx, (LPCTSTR)s, fmt, NULL);
	std::string cam_name = "video=";
	cam_name.append(vid_devices[video_id].deviceName);
	cam_name.append(":audio=");
	cam_name.append(aud_devices[audio_id].deviceName);
	ret = avformat_open_input(&ifmt_ctx, cam_name.c_str(), fmt, NULL);
	if (ret < 0) {

		s.Format("%s\n", vid_devices[video_id].deviceName.c_str());
		Memo_Write(s);
		//Memo_Write("%s");
		Memo_Write("Could not open camera!");
		OnModeInit();
		GetDlgItem(IDC_BUTTON_CAM_START)->EnableWindow(1);
		GetDlgItem(IDC_BUTTON_AVI_OPEN)->EnableWindow(1);
		GetDlgItem(IDC_BUTTON_YUV_OPEN)->EnableWindow(1);
		GetDlgItem(IDC_BUTTON_FILE_OPEN)->EnableWindow(1);
		GetDlgItem(IDC_BUTTON_YCbCr_OPEN)->EnableWindow(1);
		// Cam
		GetDlgItem(IDC_BUTTON_CAM_STOP)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_CAM_CAPTURE)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_CAM_AVISAVE)->EnableWindow(0); // MP4 �߰�
		GetDlgItem(IDC_BUTTON_CAM_TEST)->EnableWindow(1);
		// File
		GetDlgItem(IDC_BUTTON_FILE_RUN)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_FILE_CAPTURE)->EnableWindow(0);
		// MP4
		GetDlgItem(IDC_BUTTON_AVIFORM_SAVE2)->EnableWindow(0); //MP4 �߰�
		GetDlgItem(IDC_STATIC_BB_BDM_M_P2)->EnableWindow(1);
		GetDlgItem(IDC_SLIDER_MP4_SAVE_COMP_LEVEL)->EnableWindow(1);
		GetDlgItem(IDC_EDIT_MP4_SAVE_COMP_LEVEL)->EnableWindow(1);
		// Avi
		GetDlgItem(IDC_BUTTON_AVI_RUN)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_AVI_PAUSE)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_YUV_SAVE)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_AVI_STOP)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_VIDEO_CAPTURE)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_AVIFORM_SAVE)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_YCbCr_SAVE)->EnableWindow(0);
		GetDlgItem(IDC_CHECK_SIDEBYSIDE)->EnableWindow(1);
		GetDlgItem(IDC_CHECK_UPANDDOWN)->EnableWindow(1);
		//char str[100];
		//av_strerror(ret, str, 100);
		//s.Format("%s", str);
		//Memo_Write(s);
		// Cam
		return;
	}
	vid_devices.clear();
	aud_devices.clear();

	ret = avformat_find_stream_info(ifmt_ctx, 0);
	if (ret < 0) {
		Memo_Write("Failed to retrieve input stream information!");
		avformat_close_input(&ifmt_ctx);
		// Cam
		GetDlgItem(IDC_BUTTON_CAM_START)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_CAM_TEST)->EnableWindow(1);
		GetDlgItem(IDC_BUTTON_CAM_STOP)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_CAM_CAPTURE)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_CAM_AVISAVE)->EnableWindow(0);
		return;
	}

	for (int i = 0; i < ifmt_ctx->nb_streams; i++) {
		AVStream* stream;
		AVCodecContext* codec_ctx;
		stream = ifmt_ctx->streams[i];
		codec_ctx = stream->codec;
		if (codec_ctx->codec_type == AVMEDIA_TYPE_AUDIO || codec_ctx->codec_type == AVMEDIA_TYPE_VIDEO) {
			ret = avcodec_open2(codec_ctx, avcodec_find_decoder(codec_ctx->codec_id), NULL);
			if (ret < 0) {
				Memo_Write("Failed to open decoder for input stream!");
				// Cam
				GetDlgItem(IDC_BUTTON_CAM_START)->EnableWindow(0);
				GetDlgItem(IDC_BUTTON_CAM_TEST)->EnableWindow(1);
				GetDlgItem(IDC_BUTTON_CAM_STOP)->EnableWindow(0);
				GetDlgItem(IDC_BUTTON_CAM_CAPTURE)->EnableWindow(0);
				GetDlgItem(IDC_BUTTON_CAM_AVISAVE)->EnableWindow(0);
				return;
			}
		}
		if (codec_ctx->codec_type == AVMEDIA_TYPE_VIDEO)
			video_index = i;
		else if (codec_ctx->codec_type == AVMEDIA_TYPE_AUDIO)
			audio_index = i;
		else;
	}

	sws_ctx = sws_getContext(ifmt_ctx->streams[video_index]->codec->width,
		ifmt_ctx->streams[video_index]->codec->height,
		ifmt_ctx->streams[video_index]->codec->pix_fmt,
		ifmt_ctx->streams[video_index]->codec->width,
		ifmt_ctx->streams[video_index]->codec->height,
		AV_PIX_FMT_BGR24,
		SWS_BICUBIC,
		NULL, NULL, NULL);

	m_frame_num = 0;
	m_run_mode = 1;

	pFrameRGB = av_frame_alloc();
	if (!pFrameRGB) {
		Memo_Write("Failed to allocate frame holder!");
		// Cam
		GetDlgItem(IDC_BUTTON_CAM_START)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_CAM_TEST)->EnableWindow(1);
		GetDlgItem(IDC_BUTTON_CAM_STOP)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_CAM_CAPTURE)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_CAM_AVISAVE)->EnableWindow(0);
		return;
	}

	int numBytes;
	uint8_t* buffer = NULL;
	numBytes = avpicture_get_size(AV_PIX_FMT_BGR24, ifmt_ctx->streams[video_index]->codec->width, ifmt_ctx->streams[video_index]->codec->height);
	buffer = (uint8_t*)av_malloc(numBytes * sizeof(uint8_t));
	avpicture_fill((AVPicture*)pFrameRGB, buffer, AV_PIX_FMT_BGR24, ifmt_ctx->streams[video_index]->codec->width, ifmt_ctx->streams[video_index]->codec->height);

	video_st.cam_result_y = (int*)calloc(ifmt_ctx->streams[video_index]->codec->height * ifmt_ctx->streams[video_index]->codec->width, sizeof(int));
	video_st.cam_result_u = (int*)calloc(ifmt_ctx->streams[video_index]->codec->height * ifmt_ctx->streams[video_index]->codec->width / 4, sizeof(int));
	video_st.cam_result_v = (int*)calloc(ifmt_ctx->streams[video_index]->codec->height * ifmt_ctx->streams[video_index]->codec->width / 4, sizeof(int));

	audio_st.cam_result_y = NULL;
	audio_st.cam_result_u = NULL;
	audio_st.cam_result_v = NULL;

	m_pthread = AfxBeginThread(ThreadProcessingAVI, (LPVOID)this, 0);
}

void CVS2022_DefaultDlg::OnButton_CamStop()
{
	/*
	Memo_Write("Camera Stop");

	if (m_bYUVSave == TRUE) {
		fclose(m_fpAviSave);
		Memo_Write("Camera Save End");
		//GetDlgItem(IDC_BUTTON_CAM_YUVSAVE)->SetWindowText(".yuv Save");
	}
	else;

	if (m_bYCbCrSave == TRUE) {
		fclose(m_fpAviSave);
		Memo_Write("Camera Save End");
		//GetDlgItem(IDC_BUTTON_CAM_YCbCrSAVE)->SetWindowText(".ycbcr Save");
	}
	else;

	if (VideoOut != NULL) {

		cvReleaseVideoWriter(&VideoOut);
		cvReleaseVideoWriter(&VideoOutPro);

		CFileDialog fileSave(FALSE, NULL, NULL, OFN_FILEMUSTEXIST |
			OFN_PATHMUSTEXIST | OFN_EXPLORER,
			"AVI File(*.avi)", NULL);

		char szFilter[] = "AVI Files(*.avi)|*.avi";

		CString strSaveFileName;
		CString strSaveFileNamePro;
		fileSave.m_ofn.lpstrFilter = szFilter;
		if (IDOK == fileSave.DoModal())
		{
			strSaveFileName = fileSave.GetPathName();
			strSaveFileName.Format(strSaveFileName + "_org.avi");
			MoveFile("avitmp.avi", strSaveFileName);

			strSaveFileNamePro = fileSave.GetPathName();
			strSaveFileNamePro.Format(strSaveFileNamePro + "_process.avi");
			MoveFile("avitmp2.avi", strSaveFileNamePro);

		}
		else;
		GetDlgItem(IDC_BUTTON_CAM_AVISAVE)->SetWindowText(".avi Save");
	}
	else;

	GetDlgItem(IDC_BUTTON_CAM_START)->EnableWindow(1);
	GetDlgItem(IDC_BUTTON_AVI_OPEN)->EnableWindow(1);
	GetDlgItem(IDC_BUTTON_FILE_OPEN)->EnableWindow(1);
	GetDlgItem(IDC_BUTTON_YUV_OPEN)->EnableWindow(1);
	GetDlgItem(IDC_BUTTON_YCbCr_OPEN)->EnableWindow(1);

	m_bCamStop = TRUE;    //Therad�� ���� ������ ���� ����
	*/
	camstopflag = 1;
	/*
	Memo_Write("Camera Stop");
	m_bCamStop = TRUE;    //Therad�� ���� ������ ���� ����

	if (cam_mp4_save == TRUE) {
		GetDlgItem(IDC_BUTTON_CAM_AVISAVE)->SetWindowText(".mp4 Save");
		cam_mp4_save = FALSE;

		if (have_video) {
			ret = flush_stream(oc, &video_st);
			if (ret < 0)
				Memo_Write("Failed to flush video stream!");
		}

		if (have_audio) {
			ret = flush_stream(oc, &audio_st);
			if (ret < 0)
				Memo_Write("Failed to flush audio stream!");
		}

		av_write_trailer(oc);
		if (have_video)
			close_stream(oc, &video_st);
		if (have_audio)
			close_stream(oc, &audio_st);
		if (!(fmt->flags & AVFMT_NOFILE))
			avio_closep(&oc->pb);
		avformat_free_context(oc);
		av_frame_free(&pFrameRGB);
		av_frame_free(&avframe);
		av_packet_free(&pkt);
		sws_freeContext(sws_ctx);

		// ask user to enter the file name and move the temporary file
		CFileDialog fileSave(FALSE, "MP4", NULL, OFN_FILEMUSTEXIST |
			OFN_PATHMUSTEXIST | OFN_EXPLORER,
			"MP4 File(*.mp4)", NULL);

		char szFilter[] = "MP4 Files(*mp4)|*.mp4";

		CString strSaveFileName;
		fileSave.m_ofn.lpstrFilter = szFilter;
		int nRet = fileSave.DoModal();
		if (nRet == IDOK) {
			strSaveFileName = fileSave.GetPathName();
			MoveFile(sfilename, strSaveFileName);
		}
		else {
			DeleteFile(sfilename);
		}
	}
	else {
		// free memories
		if (pkt)
			av_packet_free(&pkt);
		if (avframe)
			av_frame_free(&avframe);
		if (pFrameRGB)
			av_frame_free(&pFrameRGB);
		sws_freeContext(sws_ctx);
		free(video_st.cam_result_y);
		free(video_st.cam_result_u);
		free(video_st.cam_result_v);
		free(audio_st.cam_result_y);
		free(audio_st.cam_result_u);
		free(audio_st.cam_result_v);
	}

	GetDlgItem(IDC_BUTTON_CAM_START)->EnableWindow(0);
	GetDlgItem(IDC_BUTTON_CAM_TEST)->EnableWindow(1);
	GetDlgItem(IDC_BUTTON_AVI_OPEN)->EnableWindow(1);
	GetDlgItem(IDC_BUTTON_FILE_OPEN)->EnableWindow(1);
	GetDlgItem(IDC_BUTTON_YUV_OPEN)->EnableWindow(1);
	GetDlgItem(IDC_BUTTON_YCbCr_OPEN)->EnableWindow(1);
	GetDlgItem(IDC_CHECK_SIDEBYSIDE)->EnableWindow(1);
	GetDlgItem(IDC_CHECK_UPANDDOWN)->EnableWindow(1);
	GetDlgItem(IDC_STATIC_BB_BDM_M_P2)->EnableWindow(1);
	GetDlgItem(IDC_SLIDER_MP4_SAVE_COMP_LEVEL)->EnableWindow(1);
	GetDlgItem(IDC_EDIT_MP4_SAVE_COMP_LEVEL)->EnableWindow(1);

	// clean ifmt_ctx for a new run
	if (ifmt_ctx) {
		for (int i = 0; i < ifmt_ctx->nb_streams; i++)
			avcodec_close(ifmt_ctx->streams[i]->codec);
		avformat_close_input(&ifmt_ctx);
	}

	// clear combobox
	mComboBox_CamSel.ResetContent();
	*/
}

void CVS2022_DefaultDlg::CamStopProc()
{
	Memo_Write("Camera Stop");
	m_bCamStop = TRUE;    //Therad�� ���� ������ ���� ����

	if (cam_mp4_save == TRUE) {
		GetDlgItem(IDC_BUTTON_CAM_AVISAVE)->SetWindowText(".mp4 Save");
		cam_mp4_save = FALSE;

		if (have_video) {
			ret = flush_stream(oc, &video_st);
			if (ret < 0)
				Memo_Write("Failed to flush video stream!");
		}

		if (have_audio) {
			ret = flush_stream(oc, &audio_st);
			if (ret < 0)
				Memo_Write("Failed to flush audio stream!");
		}

		av_write_trailer(oc);
		if (have_video)
			close_stream(oc, &video_st);
		if (have_audio)
			close_stream(oc, &audio_st);
		if (!(fmt->flags & AVFMT_NOFILE))
			avio_closep(&oc->pb);
		avformat_free_context(oc);
		av_frame_free(&pFrameRGB);
		av_frame_free(&avframe);
		av_packet_free(&pkt);
		sws_freeContext(sws_ctx);

		// ask user to enter the file name and move the temporary file
		CFileDialog fileSave(FALSE, "MP4", NULL, OFN_FILEMUSTEXIST |
			OFN_PATHMUSTEXIST | OFN_EXPLORER,
			"MP4 File(*.mp4)", NULL);

		char szFilter[] = "MP4 Files(*mp4)|*.mp4";

		CString strSaveFileName;
		fileSave.m_ofn.lpstrFilter = szFilter;
		int nRet = fileSave.DoModal();
		if (nRet == IDOK) {
			strSaveFileName = fileSave.GetPathName();
			MoveFile(sfilename, strSaveFileName);
		}
		else {
			DeleteFile(sfilename);
		}
	}
	else {
		// free memories
		if (pkt)
			av_packet_free(&pkt);
		if (avframe)
			av_frame_free(&avframe);
		if (pFrameRGB)
			av_frame_free(&pFrameRGB);
		sws_freeContext(sws_ctx);
		free(video_st.cam_result_y);
		free(video_st.cam_result_u);
		free(video_st.cam_result_v);
		free(audio_st.cam_result_y);
		free(audio_st.cam_result_u);
		free(audio_st.cam_result_v);
	}

	GetDlgItem(IDC_BUTTON_CAM_START)->EnableWindow(0);
	GetDlgItem(IDC_BUTTON_CAM_TEST)->EnableWindow(1);
	GetDlgItem(IDC_BUTTON_AVI_OPEN)->EnableWindow(1);
	GetDlgItem(IDC_BUTTON_FILE_OPEN)->EnableWindow(1);
	GetDlgItem(IDC_BUTTON_YUV_OPEN)->EnableWindow(1);
	GetDlgItem(IDC_BUTTON_YCbCr_OPEN)->EnableWindow(1);
	GetDlgItem(IDC_CHECK_SIDEBYSIDE)->EnableWindow(1);
	GetDlgItem(IDC_CHECK_UPANDDOWN)->EnableWindow(1);
	GetDlgItem(IDC_STATIC_BB_BDM_M_P2)->EnableWindow(1);
	GetDlgItem(IDC_SLIDER_MP4_SAVE_COMP_LEVEL)->EnableWindow(1);
	GetDlgItem(IDC_EDIT_MP4_SAVE_COMP_LEVEL)->EnableWindow(1);

	// clean ifmt_ctx for a new run
	if (ifmt_ctx) {
		for (int i = 0; i < ifmt_ctx->nb_streams; i++)
			avcodec_close(ifmt_ctx->streams[i]->codec);
		avformat_close_input(&ifmt_ctx);
	}

	// clear combobox
	mComboBox_CamSel.ResetContent();
	camstopflag = 0;
}

void CVS2022_DefaultDlg::OnButton_CamCapture()
{
	m_capture_flag = TRUE;
}

void CVS2022_DefaultDlg::OnButton_CamMp4save()
{
	cammp4flag = 1;
}

void CVS2022_DefaultDlg::CamMp4SaveProc()
{
	m_bCamStop = FALSE;

	if (cam_mp4_save == FALSE) {
		cam_mp4_save = TRUE;

		// FFMPEG: save audio and video (added 2022.07.22)
		avformat_alloc_output_context2(&oc, NULL, NULL, sfilename);
		if (!oc) {
			Memo_Write("Could not allocate output context!");
			return;
		}

		fmt = oc->oformat;
		if (fmt->video_codec != AV_CODEC_ID_NONE) {
			ret = add_stream(&video_st, oc, &video_codec, fmt->video_codec, mp4_save_compression_level);
			if (ret < 0) {
				Memo_Write("Could not allocate video stream!");
				return;
			}
			have_video = 1;
			encode_video = 1;
		}
		if (fmt->audio_codec != AV_CODEC_ID_NONE) {
			ret = add_stream(&audio_st, oc, &audio_codec, fmt->audio_codec, mp4_save_compression_level);
			if (ret < 0) {
				Memo_Write("Could not allocate audio stream!");
				return;
			}
			have_audio = 1;
			encode_audio = 1;
		}

		if (have_video) {
			ret = open_video(oc, video_codec, &video_st, opt);
			if (ret < 0) {
				Memo_Write("Could not open video stream!");
				return;
			}
		}
		if (have_audio) {
			ret = open_audio(oc, audio_codec, &audio_st, opt);
			if (ret < 0) {
				Memo_Write("Could not open audio stream!");
				return;
			}
		}

		av_dump_format(oc, 0, sfilename, 1);

		if (!(fmt->flags & AVFMT_NOFILE)) {
			ret = avio_open(&oc->pb, sfilename, AVIO_FLAG_WRITE);
			if (ret < 0) {
				Memo_Write("Could not open output file!");
				return;
			}
		}

		ret = avformat_write_header(oc, &opt);
		if (ret < 0) {
			Memo_Write("Error occurred when opening output file!");
			return;
		}

		GetDlgItem(IDC_BUTTON_CAM_AVISAVE)->SetWindowText("Save Stop");
		Memo_Write("Camera Save Start");

		GetDlgItem(IDC_CHECK_SIDEBYSIDE)->EnableWindow(0);
		GetDlgItem(IDC_CHECK_UPANDDOWN)->EnableWindow(0);
		GetDlgItem(IDC_EDIT_SAVE_FPS)->EnableWindow(0);
		GetDlgItem(IDC_EDIT_YUV_FRAME)->EnableWindow(0);
		GetDlgItem(IDC_STATIC_BB_BDM_M_P2)->EnableWindow(0);
		GetDlgItem(IDC_SLIDER_MP4_SAVE_COMP_LEVEL)->EnableWindow(0);
		GetDlgItem(IDC_EDIT_MP4_SAVE_COMP_LEVEL)->EnableWindow(0);
	}
	else {
		cam_mp4_save = FALSE;
		m_bCamStop = TRUE;

		// FFMPEG save video and audio, added 2022.07.22
		if (have_video) {
			ret = flush_stream(oc, &video_st);
			if (ret < 0)
				Memo_Write("Failed to flush video stream!");
		}

		if (have_audio) {
			ret = flush_stream(oc, &audio_st);
			if (ret < 0)
				Memo_Write("Failed to flush audio stream!");
		}

		av_write_trailer(oc);
		if (have_video)
			close_stream(oc, &video_st);
		if (have_audio)
			close_stream(oc, &audio_st);
		if (!(fmt->flags & AVFMT_NOFILE))
			avio_closep(&oc->pb);
		avformat_free_context(oc);
		av_frame_free(&pFrameRGB);
		av_frame_free(&avframe);
		av_packet_free(&pkt);
		sws_freeContext(sws_ctx);

		// clean ifmt_ctx for a new run
		if (ifmt_ctx) {
			for (int i = 0; i < ifmt_ctx->nb_streams; i++)
				avcodec_close(ifmt_ctx->streams[i]->codec);
			avformat_close_input(&ifmt_ctx);
		}

		// clear combobox
		mComboBox_CamSel.ResetContent();

		// ask user to enter the file name and move the temporary file
		CFileDialog fileSave(FALSE, "MP4", NULL, OFN_FILEMUSTEXIST |
			OFN_PATHMUSTEXIST | OFN_EXPLORER,
			"MP4 File(*.mp4)", NULL);

		char szFilter[] = "MP4 Files(*mp4)|*.mp4";

		CString strSaveFileName;
		fileSave.m_ofn.lpstrFilter = szFilter;
		int nRet = fileSave.DoModal();
		if (nRet == IDOK) {
			strSaveFileName = fileSave.GetPathName();
			MoveFile(sfilename, strSaveFileName);
		}
		else {
			DeleteFile(sfilename);
		}

		GetDlgItem(IDC_BUTTON_CAM_AVISAVE)->SetWindowText(".mp4 Save");

		Memo_Write("Camera Save end");

		GetDlgItem(IDC_CHECK_SIDEBYSIDE)->EnableWindow(1);
		GetDlgItem(IDC_CHECK_UPANDDOWN)->EnableWindow(1);
		GetDlgItem(IDC_EDIT_SAVE_FPS)->EnableWindow(1);
		GetDlgItem(IDC_EDIT_YUV_FRAME)->EnableWindow(1);
		GetDlgItem(IDC_STATIC_BB_BDM_M_P2)->EnableWindow(1);
		GetDlgItem(IDC_SLIDER_MP4_SAVE_COMP_LEVEL)->EnableWindow(1);
		GetDlgItem(IDC_EDIT_MP4_SAVE_COMP_LEVEL)->EnableWindow(1);
	}
	cammp4flag = 0;
}

void CVS2022_DefaultDlg::OnButton_CamYuvsave()
{
	if (!m_bYUVSave) {

		CFileDialog fileOpen(FALSE, NULL, NULL, OFN_FILEMUSTEXIST |
			OFN_PATHMUSTEXIST | OFN_EXPLORER,
			"YUV File(*.yuv)|*.yuv;|All Files(*.*)|*.*||", NULL);  // ����������ġ ��ȭ����

		if (fileOpen.DoModal() != IDOK) return;
		else;

		VideoSave = fileOpen.GetPathName();
		m_bYUVSave = TRUE;
		VideoSave.Format(VideoSave + "_org.YUV");// Ȯ����
		//fopen wb+�ɼ� = �б�, ���� ������ ���̳ʸ�Ÿ������ open (������, �̹� �����ϸ� �����)
		fopen_s(&m_fpAviSave, VideoSave, "wb+"); // file open
		if (m_fpAviSave == NULL) AfxMessageBox("m_fpAviSave : file open failed");
		else;

		VideoSavePRO = fileOpen.GetPathName();
		VideoSavePRO.Format(VideoSavePRO + "_process.YUV");// Ȯ����
		fopen_s(&m_fpAviSavePro, VideoSavePRO, "wb+"); // file open
		if (m_fpAviSavePro == NULL) AfxMessageBox("m_fpAviSavePro : file open failed");
		else;

		//GetDlgItem(IDC_BUTTON_CAM_YUVSAVE)->SetWindowText("Save Stop");
		Memo_Write("Camera Save Start");

		GetDlgItem(IDC_BUTTON_CAM_AVISAVE)->EnableWindow(0);
		//GetDlgItem(IDC_BUTTON_CAM_YCbCrSAVE)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_AVIFORM_SAVE2)->EnableWindow(0);
		GetDlgItem(IDC_CHECK_SIDEBYSIDE)->EnableWindow(0);
		GetDlgItem(IDC_CHECK_UPANDDOWN)->EnableWindow(0);
		GetDlgItem(IDC_EDIT_SAVE_FPS)->EnableWindow(0);
		GetDlgItem(IDC_EDIT_YUV_FRAME)->EnableWindow(0);

	}
	else {
		fclose(m_fpAviSave);
		//GetDlgItem(IDC_BUTTON_CAM_YUVSAVE)->SetWindowText(".yuv Save");
		m_bYUVSave = FALSE;

		Memo_Write("Camera Save End");

		GetDlgItem(IDC_BUTTON_CAM_AVISAVE)->EnableWindow(1);
		//GetDlgItem(IDC_BUTTON_CAM_YCbCrSAVE)->EnableWindow(1);
		GetDlgItem(IDC_BUTTON_AVIFORM_SAVE2)->EnableWindow(1);
		GetDlgItem(IDC_CHECK_SIDEBYSIDE)->EnableWindow(1);
		GetDlgItem(IDC_CHECK_UPANDDOWN)->EnableWindow(1);
		GetDlgItem(IDC_EDIT_SAVE_FPS)->EnableWindow(1);
		GetDlgItem(IDC_EDIT_YUV_FRAME)->EnableWindow(1);
	}
}

void CVS2022_DefaultDlg::OnButton_CamYcbcrsave()
{
	if (!m_bYCbCrSave) {
		CFileDialog fileOpen(FALSE, NULL, NULL, OFN_FILEMUSTEXIST |
			OFN_PATHMUSTEXIST | OFN_EXPLORER,
			"YCbCr File(*.ycbcr)|*.ycbcr;|All Files(*.*)|*.*||", NULL);  // ����������ġ ��ȭ����

		if (fileOpen.DoModal() != IDOK) return;
		else;

		VideoSave = fileOpen.GetPathName();
		m_bYCbCrSave = TRUE;
		VideoSave.Format(VideoSave + "_org.YCbCr");// Ȯ����
		fopen_s(&m_fpAviSave, VideoSave, "wb+"); // file open
		if (m_fpAviSave == NULL) AfxMessageBox("m_fpAviSave : file open failed");
		else;

		VideoSavePRO = fileOpen.GetPathName();
		VideoSavePRO.Format(VideoSavePRO + "_process.YCbCr");// Ȯ����
		fopen_s(&m_fpAviSavePro, VideoSavePRO, "wb+"); // file open
		if (m_fpAviSavePro == NULL) AfxMessageBox("m_fpAviSavePro : file open failed");
		else;


		//GetDlgItem(IDC_BUTTON_CAM_YCbCrSAVE)->SetWindowText("Save Stop");
		Memo_Write("Camera Save Start");

		GetDlgItem(IDC_BUTTON_CAM_AVISAVE)->EnableWindow(0);
		//GetDlgItem(IDC_BUTTON_CAM_YUVSAVE)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_AVIFORM_SAVE2)->EnableWindow(0);
		GetDlgItem(IDC_CHECK_SIDEBYSIDE)->EnableWindow(0);
		GetDlgItem(IDC_CHECK_UPANDDOWN)->EnableWindow(0);
		GetDlgItem(IDC_EDIT_SAVE_FPS)->EnableWindow(0);
		GetDlgItem(IDC_EDIT_YUV_FRAME)->EnableWindow(0);
	}
	else {
		fclose(m_fpAviSave);
		//GetDlgItem(IDC_BUTTON_CAM_YCbCrSAVE)->SetWindowText(".ycbcr Save");
		m_bYCbCrSave = FALSE;

		Memo_Write("Camera Save End");

		GetDlgItem(IDC_BUTTON_CAM_AVISAVE)->EnableWindow(1);
		//GetDlgItem(IDC_BUTTON_CAM_YUVSAVE)->EnableWindow(1);
		GetDlgItem(IDC_BUTTON_AVIFORM_SAVE2)->EnableWindow(1);
		GetDlgItem(IDC_CHECK_SIDEBYSIDE)->EnableWindow(1);
		GetDlgItem(IDC_CHECK_UPANDDOWN)->EnableWindow(1);
		GetDlgItem(IDC_EDIT_SAVE_FPS)->EnableWindow(1);
		GetDlgItem(IDC_EDIT_YUV_FRAME)->EnableWindow(1);
	}
}

void CVS2022_DefaultDlg::OnBnClickedButtonCamTest()
{
	// TODO: Add your control notification handler code here
	GetDlgItem(IDC_BUTTON_AVI_OPEN)->EnableWindow(0);
	GetDlgItem(IDC_BUTTON_YUV_OPEN)->EnableWindow(0);
	GetDlgItem(IDC_BUTTON_YCbCr_OPEN)->EnableWindow(0);
	GetDlgItem(IDC_BUTTON_FILE_OPEN)->EnableWindow(0);

	m_check_sidebyside = FALSE;
	m_check_upanddown = FALSE;
	CheckDlgButton(IDC_CHECK_SIDEBYSIDE, BST_UNCHECKED);
	CheckDlgButton(IDC_CHECK_UPANDDOWN, BST_UNCHECKED);
	GetDlgItem(IDC_CHECK_SIDEBYSIDE)->EnableWindow(0);
	GetDlgItem(IDC_CHECK_UPANDDOWN)->EnableWindow(0);
	Memo_Write("Two or more same model cams can't get info.");
	Memo_Write("Getting camera information ...");


	AVInputFormat* fmt = av_find_input_format("dshow");
	if (!fmt) {
		Memo_Write("Could not find any DirectShow devices!");
		// Cam
		GetDlgItem(IDC_BUTTON_CAM_START)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_CAM_TEST)->EnableWindow(1);
		GetDlgItem(IDC_BUTTON_CAM_STOP)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_CAM_CAPTURE)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_CAM_AVISAVE)->EnableWindow(0);
		return;
	}
	CString js;


	vid_devices = getVideoDevicesMap();

	/*
	//* 24.02.02 중복 캠 detect & 레지스트리 수정 파일 실행
	TCHAR exePath[MAX_PATH];
	GetModuleFileName(NULL, exePath, MAX_PATH); // dialog 실행파일 경로를 얻음.
	CString folderPath(exePath);
	folderPath = folderPath.Left(folderPath.ReverseFind('\\')); // dialog 실행파일 상위의 Release 폴더의 경로를 얻음.
	folderPath = folderPath + "\\name.exe"; // Release 폴더 내의 name.exe 실행파일을 경로를 얻음.
	for (int i = 0; i < vid_devices.size(); i++) {
		if (vid_devices[i].deviceName == "Logitech QuickCam Pro 9000" ||
			vid_devices[i].deviceName == "Logitech Webcam Pro 9000") { // 비디오 맵의 중복캠 이름
			int temp = system(folderPath);
			if (temp == 1) {
				Memo_Write("system failed");
				//success
			}
			// .exe 파일 실행
			vid_devices = getVideoDevicesMap(); // 수정된 이름으로 다시 비디오 맵 생성
			break;
		}
	}
	*/
	//*

	//if (!vid_devices.empty()) {
	//	s.Format("======= %d VIDEO DEVICE(S) ========\n", vid_devices.size());
	//	Memo_Write(s);
	//	std::map<int, Device>::iterator it;
	//	for (it = vid_devices.begin(); it != vid_devices.end(); it++) {
	//		std::string vid_devname(it->second.deviceName);
	//		removeNonLatinCharacter(vid_devname);
	//		s.Format("%d -- %s\n", it->first, vid_devname.c_str());
	//		Memo_Write(s);
	//	}
	//}
	//else {
	//	Memo_Write("Could not detect any cameras!");
	//	// Cam
	//	GetDlgItem(IDC_BUTTON_CAM_START)->EnableWindow(0);
	//	GetDlgItem(IDC_BUTTON_CAM_TEST)->EnableWindow(1);
	//	GetDlgItem(IDC_BUTTON_CAM_STOP)->EnableWindow(0);
	//	GetDlgItem(IDC_BUTTON_CAM_CAPTURE)->EnableWindow(0);
	//	GetDlgItem(IDC_BUTTON_CAM_MP4SAVE)->EnableWindow(0);
	//	return;
	//}

	aud_devices = getAudioDevicesMap();
	//if (!aud_devices.empty()) {
	//	s.Format("======= %d AUDIO DEVICE(S) ========\n", aud_devices.size());
	//	Memo_Write(s);
	//	std::map<int, Device>::iterator it;
	//	for (it = aud_devices.begin(); it != aud_devices.end(); it++) {
	//		std::string aud_devname(it->second.deviceName);
	//		removeNonLatinCharacter(aud_devname);
	//		s.Format("%d -- %s\n", it->first, aud_devname.c_str());
	//		Memo_Write(s);
	//	}
	//}
	//else {
	//	Memo_Write("Could not detect any microphones!");
	//	// Cam
	//	GetDlgItem(IDC_BUTTON_CAM_START)->EnableWindow(0);
	//	GetDlgItem(IDC_BUTTON_CAM_TEST)->EnableWindow(1);
	//	GetDlgItem(IDC_BUTTON_CAM_STOP)->EnableWindow(0);
	//	GetDlgItem(IDC_BUTTON_CAM_CAPTURE)->EnableWindow(0);
	//	GetDlgItem(IDC_BUTTON_CAM_MP4SAVE)->EnableWindow(0);
	//	return;
	//}

	GetDlgItem(IDC_BUTTON_CAM_START)->EnableWindow(0);
	GetDlgItem(IDC_BUTTON_CAM_TEST)->EnableWindow(0);
	GetDlgItem(IDC_COMBO_CAMSEL)->EnableWindow(1);



	if (!vid_devices.empty() && !aud_devices.empty()) {
		int devNum = (aud_devices.size() > vid_devices.size()) ? vid_devices.size() : aud_devices.size();
		s.Format("======= %d DEVICE(S) ========\n", devNum);
		Memo_Write(s);
		int k = 0;
		for (int i = 0; i < devNum; i++) {
			std::string aud_name = aud_devices[i].deviceName;
			removeNonLatinCharacter(aud_name);
			/*
			//* 24.01.22 aud_name이 Pro9000일 때 found에서 2Pro9000, 3Pro9000 등에도 다 속하기 때문에 모두 구분 가능하게 수정
			if (aud_name == "Pro9000") aud_name = "1Q";
			if (aud_name == "Pro9000") aud_name = "2Q";
			if (aud_name == "Pro9000") aud_name = "3Q";
			if (aud_name == "Pro9000") aud_name = "4Q";
			if (aud_name == "WebcamPro9000") aud_name = "5W";
			if (aud_name == "WebcamPro9000") aud_name = "6W";
			*/
			//*

			for (int j = 0; j < vid_devices.size(); j++) {
				std::string vid_name = vid_devices[j].deviceName;
				removeNonLatinCharacter(vid_name);
				/*
				//* 24.01.24 장치레지스트리에서 수정한 비디오 friendlyName을 각 aud_name과 연결시켜 줌
				if (vid_name == "LogitechQuickCamPro9000") vid_name = "1Q";
				if (vid_name == "LogitechQuickCamPro9000") vid_name = "2Q";
				if (vid_name == "LogitechQuickCamPro9000") vid_name = "3Q";
				if (vid_name == "LogitechQuickCamPro9000") vid_name = "4Q";
				if (vid_name == "LogitechWebcamPro9000") vid_name = "5W";
				if (vid_name == "LogitechWebcamPro9000") vid_name = "6W";
				*/
				//*

				std::size_t found = vid_name.find(aud_name);
				if (found != std::string::npos) {
					s.Format("%d -- %s\n", i, vid_devices[j].deviceName.c_str());
					Memo_Write(s);
					//s.Format("test");
					//Memo_Write(s);
					break; //* 24.01.24 추가

				}

			}
		}
		Memo_Write("Please select the camera!");
		CString devName;
		for (int i = 0; i < devNum; i++) {
			devName.Format("Cam%d", i);
			mComboBox_CamSel.AddString(_T(devName));
		}

	}
	else {
		Memo_Write("Could not detect any devices!");
		// Cam
		GetDlgItem(IDC_BUTTON_CAM_START)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_CAM_TEST)->EnableWindow(1);
		GetDlgItem(IDC_COMBO_CAMSEL)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_CAM_STOP)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_CAM_CAPTURE)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_CAM_AVISAVE)->EnableWindow(0);
		return;
	}
}

void CVS2022_DefaultDlg::OnSelchangeComboCamsel()
{
	GetDlgItem(IDC_BUTTON_CAM_START)->EnableWindow(1);
	CString js;
	// TODO: Add your control notification handler code here
	int selItem = mComboBox_CamSel.GetCurSel();
	if (selItem != LB_ERR) {
		std::string aud_name = aud_devices[selItem].deviceName;
		removeNonLatinCharacter(aud_name);
		/*
		//* 24.01.24 수정
		if (aud_name == "Pro9000") aud_name = "A";
		if (aud_name == "2Pro9000") aud_name = "B";
		if (aud_name == "3Pro9000") aud_name = "C";
		if (aud_name == "4Pro9000") aud_name = "D";
		if (aud_name == "WebcamPro9000") aud_name = "E";
		if (aud_name == "2WebcamPro9000") aud_name = "F";
		//*
		*/
		audio_id = aud_devices[selItem].id;


		for (int i = 0; i < vid_devices.size(); i++) {
			std::string vid_name = vid_devices[i].deviceName;
			removeNonLatinCharacter(vid_name);
			/*
			//* 24.01.24 수정
			if (vid_name == "LogitechQuickCamPro9000") vid_name = "A";
			if (vid_name == "LogitechQuickCamPro9000") vid_name = "B";
			if (vid_name == "LogitechQuickCamPro9000") vid_name = "C";
			if (vid_name == "LogitechQuickCamPro9000") vid_name = "D";
			if (vid_name == "LogitechWebcamPro9000") vid_name = "E";
			if (vid_name == "LogitechWebcamPro9000") vid_name = "F";
			//*
			*/
			std::size_t found = vid_name.find(aud_name);
			if (found != std::string::npos) {
				video_id = i;
				break;
			}

		}
		UpdateData(FALSE);
	}
}


//Image
void CVS2022_DefaultDlg::OnButton_FileOpen()
{
	m_bAviStop = FALSE;
	OnModeInit(); //Mode �ʱ�ȭ
	if (!SaveImage.empty())
	{
		SaveImage.release();
	}

	Memo_Write("Still Image Open");

	CFileDialog fileOpen(TRUE, "Open Image", NULL, OFN_FILEMUSTEXIST |
		OFN_PATHMUSTEXIST | OFN_EXPLORER,
		"BMP Image(*.bmp)|*.bmp|JPG Image(*.jpg)|*.jpg|All Files(*.*)|*.*||", NULL);

	char szFilter[] = "Image Files(*.bmp)|*.bmp;|Image Files(*.jpg)|*.jpg;|All Files(*.*)|*.*|";

	CFileDialog fileDlg(TRUE, NULL, NULL, OFN_HIDEREADONLY, szFilter);


	if (IDOK == fileDlg.DoModal())
	{
		cv::String strFileName = fileDlg.GetPathName();
		//temp_SaveImage = imread(strFileName, 1);
		int temp = 0;
		temp += strFileName.find(".mp4") != string::npos;
		temp += strFileName.find(".MP4") != string::npos;
		temp += strFileName.find(".avi") != string::npos;
		temp += strFileName.find(".AVI") != string::npos;
		temp += strFileName.find(".yuv") != string::npos;
		temp += strFileName.find(".YUV") != string::npos;
		temp += strFileName.find(".ycbcr") != string::npos;
		temp += strFileName.find(".YCbCr") != string::npos;

		if (temp > 0)
		{
			OnModeInit();
			Memo_Write("please select image format!");
			return;
		}
		SaveImage = imread(strFileName, 1); //&temp_SaveImage;//1:color

		GetDlgItem(IDC_BUTTON_FILE_RUN)->EnableWindow(1);
		GetDlgItem(IDC_EDIT_Repeat_Processing)->EnableWindow(1);

		m_frame_num = 0;
		m_run_mode = 2;
	}
	else
	{
		if (SaveImage.empty())
		{
			SaveImage.release();
		}

		delete[] fileDlg;
	}
}

void CVS2022_DefaultDlg::OnButton_FileRun()
{
	UpdateData(TRUE);

	Memo_Write("Still Image Processing");

	repeat_proc = atoi(m_repeat_processing);

	fps = atoi(m_edit_frame_rate);
	if ((repeat_proc >= 1) & (repeat_proc <= 1000)) {
		// ThreadProcessingAVI�� ȣ���Ѵ�.
		m_pthread = AfxBeginThread(ThreadProcessingAVI, (LPVOID)this, 0);


		GetDlgItem(IDC_BUTTON_FILE_RUN)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_FILE_CAPTURE)->EnableWindow(1);

		GetDlgItem(IDC_RADIO_YUV444R)->EnableWindow(0);
		GetDlgItem(IDC_RADIO_YUV422R)->EnableWindow(0);
		GetDlgItem(IDC_RADIO_YUV420R)->EnableWindow(0);

		GetDlgItem(IDC_RADIO_YUV444W)->EnableWindow(0);
		GetDlgItem(IDC_RADIO_YUV422W)->EnableWindow(0);
		GetDlgItem(IDC_RADIO_YUV420W)->EnableWindow(0);

		GetDlgItem(IDC_EDIT_YUV_FRAME)->EnableWindow(0);

		GetDlgItem(IDC_CHECK_SIDEBYSIDE)->EnableWindow(0);
		GetDlgItem(IDC_CHECK_UPANDDOWN)->EnableWindow(0);
	}
	else {
		AfxMessageBox("The repeat processing number must be in the range of 1 to 1000. ");
		m_repeat_processing.Format("1");
		repeat_proc = atoi(m_repeat_processing);
		GetDlgItem(IDC_BUTTON_FILE_RUN)->EnableWindow(1);

		GetDlgItem(IDC_RADIO_YUV444R)->EnableWindow(1);
		GetDlgItem(IDC_RADIO_YUV422R)->EnableWindow(1);
		GetDlgItem(IDC_RADIO_YUV420R)->EnableWindow(1);

		GetDlgItem(IDC_RADIO_YUV444W)->EnableWindow(1);
		GetDlgItem(IDC_RADIO_YUV422W)->EnableWindow(1);
		GetDlgItem(IDC_RADIO_YUV420W)->EnableWindow(1);

		GetDlgItem(IDC_EDIT_YUV_FRAME)->EnableWindow(1);

		UpdateData(FALSE);
	}
}

void CVS2022_DefaultDlg::OnButton_FileCapture()
{

	m_capture_flag = TRUE;
	if (repeatprocendflag == TRUE)
	{
		/*
		CFileDialog fileOpen(FALSE, NULL, NULL, OFN_FILEMUSTEXIST |
			OFN_PATHMUSTEXIST | OFN_EXPLORER,
			"BMP Image(*.bmp)|*.bmp|JPG Image(*.jpg)|*.jpg|All Files(*.*)|*.*||", NULL);

		if (fileOpen.DoModal() != IDOK) return;
		else;

		if (m_check_sidebyside == FALSE && m_check_upanddown == FALSE)
		{
			StillSave = fileOpen.GetPathName();
			StillSavePRO = fileOpen.GetPathName();
		}
		else
		{
			StillSave = fileOpen.GetPathName();
		}
		*/
		//ThreadProcessingAVI�� ȣ���Ѵ�.
		m_pthread = AfxBeginThread(ThreadProcessingAVI, (LPVOID)this, 0);
	}



}

//Video
void CVS2022_DefaultDlg::OnButton_AviOpen()
{
	OnModeInit();//open 버튼 클릭 시 모드설정 초기화
	m_bAviStop = FALSE;
	dialogInit = FALSE;


	CFileDialog fileOpen(TRUE, "Open Image", NULL, OFN_FILEMUSTEXIST |
		OFN_PATHMUSTEXIST | OFN_EXPLORER, "MP4/AVI File(*.mp4,*.avi)|*.avi;*.mp4|All Files(*.*)|*.*||", NULL);

	if (fileOpen.DoModal() != IDOK) return;
	else;
	cv::String strFileName = fileOpen.GetPathName();

	// process according to extension
	mp4_found1 = strFileName.find(".mp4") != string::npos;
	mp4_found2 = strFileName.find(".MP4") != string::npos;
	avi_found1 = strFileName.find(".avi") != string::npos;
	avi_found2 = strFileName.find(".AVI") != string::npos;
	yuv_found1 = strFileName.find(".yuv") != string::npos;
	yuv_found2 = strFileName.find(".YUV") != string::npos;
	ycbcr_found1 = strFileName.find(".ycbcr") != string::npos;
	ycbcr_found2 = strFileName.find(".YCbCr") != string::npos;

	if (mp4_found1 || mp4_found2) {
		Memo_Write("MP4 input detected --> MP4 processing mode");

		char* chFilename = const_cast<char*>(strFileName.c_str());
		capture = VideoCapture(chFilename);

		//capture = &temp_capture;   // open avi file
		if (!capture.isOpened()) {
			Memo_Write("Could not open input video!");
			return;
		}
		else;

		// get fps, needed to set the delay  
		fps = (int)capture.get(CAP_PROP_FPS);

		GetDlgItem(IDC_BUTTON_AVI_RUN)->EnableWindow(1);
		GetDlgItem(IDC_BUTTON_AVI_STOP)->EnableWindow(0);

		GetDlgItem(IDC_RADIO_YUV444R)->EnableWindow(1);
		GetDlgItem(IDC_RADIO_YUV422R)->EnableWindow(1);
		GetDlgItem(IDC_RADIO_YUV420R)->EnableWindow(1);

		GetDlgItem(IDC_RADIO_YUV444W)->EnableWindow(1);
		GetDlgItem(IDC_RADIO_YUV422W)->EnableWindow(1);
		GetDlgItem(IDC_RADIO_YUV420W)->EnableWindow(1);

		GetDlgItem(IDC_BUTTON_AVI_OPEN)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_YUV_OPEN)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_YCbCr_OPEN)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_CAM_START)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_FILE_OPEN)->EnableWindow(0);

		GetDlgItem(IDC_BUTTON_AVIFORM_SAVE)->EnableWindow(1);
		GetDlgItem(IDC_BUTTON_YUV_SAVE)->EnableWindow(1);
		GetDlgItem(IDC_BUTTON_YCbCr_SAVE)->EnableWindow(1);
		GetDlgItem(IDC_CHECK_SIDEBYSIDE)->EnableWindow(0);
		GetDlgItem(IDC_CHECK_UPANDDOWN)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_AVIFORM_SAVE2)->EnableWindow(1);
		GetDlgItem(IDC_STATIC_BB_BDM_M_P2)->EnableWindow(1);
		GetDlgItem(IDC_SLIDER_MP4_SAVE_COMP_LEVEL)->EnableWindow(1);
		GetDlgItem(IDC_EDIT_MP4_SAVE_COMP_LEVEL)->EnableWindow(1);

		//AVI ó����,�� ���� ���Ͽ� ���� checkbox�� üũ �Ǿ������� �ٸ� Control���� ���� ���� ����.


		GetDlgItem(IDC_EDIT_SAVE_FPS)->EnableWindow(1);

		m_run_mode = 6;

		// FFMPEG, save video and audio, addded 2022.07.22
		ret = avformat_open_input(&ifmt_ctx, chFilename, 0, 0);
		if (ret < 0) {
			Memo_Write("Could not open input video!");
			avformat_close_input(&ifmt_ctx);
			return;
		}

		ret = avformat_find_stream_info(ifmt_ctx, 0);
		if (ret < 0) {
			Memo_Write("Failed to retrieve input stream information!");
			avformat_close_input(&ifmt_ctx);
			return;
		}

		for (int i = 0; i < ifmt_ctx->nb_streams; i++) {
			AVStream* stream;
			AVCodecContext* codec_ctx;
			stream = ifmt_ctx->streams[i];
			codec_ctx = stream->codec;
			if (codec_ctx->codec_type == AVMEDIA_TYPE_AUDIO ||
				codec_ctx->codec_type == AVMEDIA_TYPE_VIDEO) {
				ret = avcodec_open2(codec_ctx, avcodec_find_decoder(codec_ctx->codec_id), NULL);
				if (ret < 0) {
					Memo_Write("Failed to open decoder for input stream!");
					return;
				}
			}
			if (codec_ctx->codec_type == AVMEDIA_TYPE_VIDEO)
				video_index = i;
			else if (codec_ctx->codec_type == AVMEDIA_TYPE_AUDIO)
				audio_index = i;
			else;
		}

		av_dump_format(ifmt_ctx, 0, chFilename, 0);
		if (m_check_sidebyside == FALSE && m_check_upanddown == FALSE) {
			sws_ctx_bgr_yuv = sws_getContext(ifmt_ctx->streams[video_index]->codec->width,
				ifmt_ctx->streams[video_index]->codec->height,
				AV_PIX_FMT_BGR24,
				ifmt_ctx->streams[video_index]->codec->width,
				ifmt_ctx->streams[video_index]->codec->height,
				ifmt_ctx->streams[video_index]->codec->pix_fmt,
				0, 0, NULL, NULL);
		}
		else if (m_check_sidebyside == TRUE) {
			sws_ctx_bgr_yuv = sws_getContext(ifmt_ctx->streams[video_index]->codec->width * 2,
				ifmt_ctx->streams[video_index]->codec->height,
				AV_PIX_FMT_BGR24,
				ifmt_ctx->streams[video_index]->codec->width * 2,
				ifmt_ctx->streams[video_index]->codec->height,
				ifmt_ctx->streams[video_index]->codec->pix_fmt,
				0, 0, NULL, NULL);
		}
		else {
			sws_ctx_bgr_yuv = sws_getContext(ifmt_ctx->streams[video_index]->codec->width,
				ifmt_ctx->streams[video_index]->codec->height * 2,
				AV_PIX_FMT_BGR24,
				ifmt_ctx->streams[video_index]->codec->width,
				ifmt_ctx->streams[video_index]->codec->height * 2,
				ifmt_ctx->streams[video_index]->codec->pix_fmt,
				0, 0, NULL, NULL);
		}

		total_frame_count = ifmt_ctx->streams[video_index]->nb_frames;
	}
	else if (avi_found1 || avi_found2) {
		Memo_Write("AVI input detected --> AVI processing mode");
		capture = VideoCapture(strFileName);
		//capture = &temp_capture;
		if (!capture.isOpened()) {
			Memo_Write("Could not open input video!");
			return;
		}
		else;

		// get fps, needed to set the delay
		fps = (int)capture.get(CAP_PROP_FPS);

		GetDlgItem(IDC_BUTTON_AVI_RUN)->EnableWindow(1);
		GetDlgItem(IDC_BUTTON_AVI_STOP)->EnableWindow(0);

		GetDlgItem(IDC_RADIO_YUV444R)->EnableWindow(1);
		GetDlgItem(IDC_RADIO_YUV422R)->EnableWindow(1);
		GetDlgItem(IDC_RADIO_YUV420R)->EnableWindow(1);

		GetDlgItem(IDC_RADIO_YUV444W)->EnableWindow(1);
		GetDlgItem(IDC_RADIO_YUV422W)->EnableWindow(1);
		GetDlgItem(IDC_RADIO_YUV420W)->EnableWindow(1);

		GetDlgItem(IDC_BUTTON_AVI_OPEN)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_YUV_OPEN)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_YCbCr_OPEN)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_CAM_START)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_FILE_OPEN)->EnableWindow(0);

		GetDlgItem(IDC_BUTTON_AVIFORM_SAVE)->EnableWindow(1);
		GetDlgItem(IDC_BUTTON_YUV_SAVE)->EnableWindow(1);
		GetDlgItem(IDC_BUTTON_YCbCr_SAVE)->EnableWindow(1);
		GetDlgItem(IDC_CHECK_SIDEBYSIDE)->EnableWindow(0);
		GetDlgItem(IDC_CHECK_UPANDDOWN)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_AVIFORM_SAVE2)->EnableWindow(0);
		GetDlgItem(IDC_STATIC_BB_BDM_M_P2)->EnableWindow(0);
		GetDlgItem(IDC_SLIDER_MP4_SAVE_COMP_LEVEL)->EnableWindow(0);
		GetDlgItem(IDC_EDIT_MP4_SAVE_COMP_LEVEL)->EnableWindow(0);



		GetDlgItem(IDC_EDIT_SAVE_FPS)->EnableWindow(1);

		m_run_mode = 3;

		total_frame_count = (int)capture.get(CAP_PROP_FRAME_COUNT);
	}
	else if (yuv_found1 || yuv_found2) {
		OnModeInit();
		m_bAviStop = FALSE;
		dialogInit = FALSE;

		Memo_Write("YUV input detected --> YUV processing mode");

		fopen_s(&m_fpYUV, const_cast<char*>(strFileName.c_str()), "rb");
		if (m_fpYUV == NULL) {
			//AfxMessageBox("m_fpYUV : file open failed");
			Memo_Write("m_fpYUV : failed to open file!");
		}
		else;

		_fseeki64(m_fpYUV, 0, SEEK_END); // �� ���������� ã��
		m_pFrame_end = _ftelli64(m_fpYUV);

		GetDlgItem(IDC_BUTTON_AVI_RUN)->EnableWindow(1);
		GetDlgItem(IDC_BUTTON_AVI_STOP)->EnableWindow(0);

		GetDlgItem(IDC_BUTTON_AVI_OPEN)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_YUV_OPEN)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_YCbCr_OPEN)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_CAM_START)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_FILE_OPEN)->EnableWindow(0);

		GetDlgItem(IDC_BUTTON_AVIFORM_SAVE)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_AVIFORM_SAVE2)->EnableWindow(0);// MP4
		GetDlgItem(IDC_STATIC_BB_BDM_M_P2)->EnableWindow(0);
		GetDlgItem(IDC_SLIDER_MP4_SAVE_COMP_LEVEL)->EnableWindow(0);
		GetDlgItem(IDC_EDIT_MP4_SAVE_COMP_LEVEL)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_YUV_SAVE)->EnableWindow(1);
		GetDlgItem(IDC_BUTTON_YCbCr_SAVE)->EnableWindow(1);

		GetDlgItem(IDC_CHECK_SIDEBYSIDE)->EnableWindow(0);
		GetDlgItem(IDC_CHECK_UPANDDOWN)->EnableWindow(0);



		GetDlgItem(IDC_EDIT_SAVE_FPS)->EnableWindow(1);

		m_run_mode = 4;
	}
	else if (ycbcr_found1 || ycbcr_found2) {
		OnModeInit();
		m_bAviStop = FALSE;
		dialogInit = FALSE;

		Memo_Write("YCbCr input detected --> YCbCr processing mode");

		fopen_s(&m_fpYCbCr, const_cast<char*>(strFileName.c_str()), "rb");
		if (m_fpYCbCr == NULL) {
			//AfxMessageBox("m_fpYCbCr : file open failed");
			Memo_Write("m_fpYCbCr : failed to open file!");
		}
		else;

		_fseeki64(m_fpYCbCr, 0, SEEK_END);
		m_pFrame_end = _ftelli64(m_fpYCbCr);

		GetDlgItem(IDC_BUTTON_AVI_RUN)->EnableWindow(1);
		GetDlgItem(IDC_BUTTON_AVI_STOP)->EnableWindow(0);

		GetDlgItem(IDC_BUTTON_AVI_OPEN)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_YUV_OPEN)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_YCbCr_OPEN)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_CAM_START)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_FILE_OPEN)->EnableWindow(0);

		GetDlgItem(IDC_BUTTON_AVIFORM_SAVE)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_AVIFORM_SAVE2)->EnableWindow(0);// MP4
		GetDlgItem(IDC_STATIC_BB_BDM_M_P2)->EnableWindow(0);
		GetDlgItem(IDC_SLIDER_MP4_SAVE_COMP_LEVEL)->EnableWindow(0);
		GetDlgItem(IDC_EDIT_MP4_SAVE_COMP_LEVEL)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_YUV_SAVE)->EnableWindow(1);
		GetDlgItem(IDC_BUTTON_YCbCr_SAVE)->EnableWindow(1);



		GetDlgItem(IDC_EDIT_SAVE_FPS)->EnableWindow(1);

		m_run_mode = 5;
	}
	else
	{
		OnModeInit();
		Memo_Write("please select video format!");
	};

	m_frame_num = 0;
}

void CVS2022_DefaultDlg::OnButton_YuvOpen()
{


	OnModeInit();  //Mode �ʱ�ȭ
	m_bAviStop = FALSE;
	dialogInit = FALSE;

	//Memo_Write("YUV Video File Open");

	//���ϼ��� ��ȭ���� 
	CFileDialog fileOpen(TRUE, "Open Image", NULL, OFN_FILEMUSTEXIST |
		OFN_PATHMUSTEXIST | OFN_EXPLORER, "YUV File(*.yuv)|*.yuv;|All Files(*.*)|*.*||", NULL);

	if (fileOpen.DoModal() != IDOK) return;
	else;

	cv::String strFileName = fileOpen.GetPathName();

	// process according to extension
	mp4_found1 = strFileName.find(".mp4") != string::npos;
	mp4_found2 = strFileName.find(".MP4") != string::npos;
	avi_found1 = strFileName.find(".avi") != string::npos;
	avi_found2 = strFileName.find(".AVI") != string::npos;
	yuv_found1 = strFileName.find(".yuv") != string::npos;
	yuv_found2 = strFileName.find(".YUV") != string::npos;
	ycbcr_found1 = strFileName.find(".ycbcr") != string::npos;
	ycbcr_found2 = strFileName.find(".YCbCr") != string::npos;

	if (mp4_found1 || mp4_found2) {
		OnModeInit();
		m_bAviStop = FALSE;
		dialogInit = FALSE;

		Memo_Write("MP4 input detected --> MP4 processing mode");
		capture = VideoCapture(strFileName);
		//capture = &temp_capture;
		if (!capture.isOpened()) {
			Memo_Write("Could not open input video!");
			return;
		}
		else;

		// get fps, needed to set the delay  
		fps = (int)capture.get(CAP_PROP_FPS);

		GetDlgItem(IDC_BUTTON_AVI_RUN)->EnableWindow(1);
		GetDlgItem(IDC_BUTTON_AVI_STOP)->EnableWindow(0);

		GetDlgItem(IDC_RADIO_YUV444R)->EnableWindow(1);
		GetDlgItem(IDC_RADIO_YUV422R)->EnableWindow(1);
		GetDlgItem(IDC_RADIO_YUV420R)->EnableWindow(1);

		GetDlgItem(IDC_RADIO_YUV444W)->EnableWindow(1);
		GetDlgItem(IDC_RADIO_YUV422W)->EnableWindow(1);
		GetDlgItem(IDC_RADIO_YUV420W)->EnableWindow(1);

		GetDlgItem(IDC_BUTTON_AVI_OPEN)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_YUV_OPEN)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_YCbCr_OPEN)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_CAM_START)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_FILE_OPEN)->EnableWindow(0);

		GetDlgItem(IDC_BUTTON_AVIFORM_SAVE)->EnableWindow(1);
		GetDlgItem(IDC_BUTTON_YUV_SAVE)->EnableWindow(1);
		GetDlgItem(IDC_BUTTON_YCbCr_SAVE)->EnableWindow(1);
		GetDlgItem(IDC_CHECK_SIDEBYSIDE)->EnableWindow(0);
		GetDlgItem(IDC_CHECK_UPANDDOWN)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_AVIFORM_SAVE2)->EnableWindow(1);
		GetDlgItem(IDC_STATIC_BB_BDM_M_P2)->EnableWindow(1);
		GetDlgItem(IDC_SLIDER_MP4_SAVE_COMP_LEVEL)->EnableWindow(1);
		GetDlgItem(IDC_EDIT_MP4_SAVE_COMP_LEVEL)->EnableWindow(1);



		GetDlgItem(IDC_EDIT_SAVE_FPS)->EnableWindow(1);

		m_run_mode = 6;

		// FFMPEG, save video and audio, addded 2022.07.22
		ret = avformat_open_input(&ifmt_ctx, const_cast<char*>(strFileName.c_str()), 0, 0);
		if (ret < 0) {
			Memo_Write("Could not open input video!");
			avformat_close_input(&ifmt_ctx);
			return;
		}

		ret = avformat_find_stream_info(ifmt_ctx, 0);
		if (ret < 0) {
			Memo_Write("Failed to retrieve input stream information!");
			avformat_close_input(&ifmt_ctx);
			return;
		}

		for (int i = 0; i < ifmt_ctx->nb_streams; i++) {
			AVStream* stream;
			AVCodecContext* codec_ctx;
			stream = ifmt_ctx->streams[i];
			codec_ctx = stream->codec;
			if (codec_ctx->codec_type == AVMEDIA_TYPE_AUDIO ||
				codec_ctx->codec_type == AVMEDIA_TYPE_VIDEO) {
				ret = avcodec_open2(codec_ctx, avcodec_find_decoder(codec_ctx->codec_id), NULL);
				if (ret < 0) {
					Memo_Write("Failed to open decoder for input stream!");
					return;
				}
			}
			if (codec_ctx->codec_type == AVMEDIA_TYPE_VIDEO)
				video_index = i;
			else if (codec_ctx->codec_type == AVMEDIA_TYPE_AUDIO)
				audio_index = i;
			else;
		}

		av_dump_format(ifmt_ctx, 0, const_cast<char*>(strFileName.c_str()), 0);
		if (m_check_sidebyside == FALSE && m_check_upanddown == FALSE) {
			sws_ctx_bgr_yuv = sws_getContext(ifmt_ctx->streams[video_index]->codec->width,
				ifmt_ctx->streams[video_index]->codec->height,
				AV_PIX_FMT_BGR24,
				ifmt_ctx->streams[video_index]->codec->width,
				ifmt_ctx->streams[video_index]->codec->height,
				ifmt_ctx->streams[video_index]->codec->pix_fmt,
				0, 0, NULL, NULL);
		}
		else if (m_check_sidebyside == TRUE) {
			sws_ctx_bgr_yuv = sws_getContext(ifmt_ctx->streams[video_index]->codec->width * 2,
				ifmt_ctx->streams[video_index]->codec->height,
				AV_PIX_FMT_BGR24,
				ifmt_ctx->streams[video_index]->codec->width * 2,
				ifmt_ctx->streams[video_index]->codec->height,
				ifmt_ctx->streams[video_index]->codec->pix_fmt,
				0, 0, NULL, NULL);
		}
		else {
			sws_ctx_bgr_yuv = sws_getContext(ifmt_ctx->streams[video_index]->codec->width,
				ifmt_ctx->streams[video_index]->codec->height * 2,
				AV_PIX_FMT_BGR24,
				ifmt_ctx->streams[video_index]->codec->width,
				ifmt_ctx->streams[video_index]->codec->height * 2,
				ifmt_ctx->streams[video_index]->codec->pix_fmt,
				0, 0, NULL, NULL);
		}

		total_frame_count = ifmt_ctx->streams[video_index]->nb_frames;
	}
	else if (avi_found1 || avi_found2) {
		OnModeInit();
		m_bAviStop = FALSE;
		dialogInit = FALSE;

		Memo_Write("AVI input detected --> AVI processing mode");
		capture = VideoCapture(strFileName);
		//capture = &temp_capture;
		if (!capture.isOpened()) {
			Memo_Write("Could not open input video!");
			return;
		}
		else;

		// get fps, needed to set the delay  
		fps = (int)capture.get(CAP_PROP_FPS);

		GetDlgItem(IDC_BUTTON_AVI_RUN)->EnableWindow(1);
		GetDlgItem(IDC_BUTTON_AVI_STOP)->EnableWindow(0);

		GetDlgItem(IDC_RADIO_YUV444R)->EnableWindow(1);
		GetDlgItem(IDC_RADIO_YUV422R)->EnableWindow(1);
		GetDlgItem(IDC_RADIO_YUV420R)->EnableWindow(1);

		GetDlgItem(IDC_RADIO_YUV444W)->EnableWindow(1);
		GetDlgItem(IDC_RADIO_YUV422W)->EnableWindow(1);
		GetDlgItem(IDC_RADIO_YUV420W)->EnableWindow(1);

		GetDlgItem(IDC_BUTTON_AVI_OPEN)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_YUV_OPEN)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_YCbCr_OPEN)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_CAM_START)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_FILE_OPEN)->EnableWindow(0);

		GetDlgItem(IDC_BUTTON_AVIFORM_SAVE)->EnableWindow(1);
		GetDlgItem(IDC_BUTTON_YUV_SAVE)->EnableWindow(1);
		GetDlgItem(IDC_BUTTON_YCbCr_SAVE)->EnableWindow(1);
		GetDlgItem(IDC_CHECK_SIDEBYSIDE)->EnableWindow(0);
		GetDlgItem(IDC_CHECK_UPANDDOWN)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_AVIFORM_SAVE2)->EnableWindow(0);
		GetDlgItem(IDC_STATIC_BB_BDM_M_P2)->EnableWindow(0);
		GetDlgItem(IDC_SLIDER_MP4_SAVE_COMP_LEVEL)->EnableWindow(0);
		GetDlgItem(IDC_EDIT_MP4_SAVE_COMP_LEVEL)->EnableWindow(0);



		GetDlgItem(IDC_EDIT_SAVE_FPS)->EnableWindow(1);

		m_run_mode = 3;

		total_frame_count = (int)capture.get(CAP_PROP_FRAME_COUNT);
	}
	else if (yuv_found1 || yuv_found2) {
		fopen_s(&m_fpYUV, const_cast<char*>(strFileName.c_str()), "rb");
		if (m_fpYUV == NULL) {
			//AfxMessageBox("m_fpYUV : file open failed");
			Memo_Write("m_fpYUV : failed to open file!");
		}
		else;

		_fseeki64(m_fpYUV, 0, SEEK_END); // �� ���������� ã��
		m_pFrame_end = _ftelli64(m_fpYUV);

		GetDlgItem(IDC_BUTTON_AVI_RUN)->EnableWindow(1);
		GetDlgItem(IDC_BUTTON_AVI_STOP)->EnableWindow(0);

		GetDlgItem(IDC_BUTTON_AVI_OPEN)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_YUV_OPEN)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_YCbCr_OPEN)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_CAM_START)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_FILE_OPEN)->EnableWindow(0);

		GetDlgItem(IDC_BUTTON_AVIFORM_SAVE)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_AVIFORM_SAVE2)->EnableWindow(0);// MP4
		GetDlgItem(IDC_STATIC_BB_BDM_M_P2)->EnableWindow(0);
		GetDlgItem(IDC_SLIDER_MP4_SAVE_COMP_LEVEL)->EnableWindow(0);
		GetDlgItem(IDC_EDIT_MP4_SAVE_COMP_LEVEL)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_YUV_SAVE)->EnableWindow(1);
		GetDlgItem(IDC_BUTTON_YCbCr_SAVE)->EnableWindow(1);

		GetDlgItem(IDC_CHECK_SIDEBYSIDE)->EnableWindow(0);
		GetDlgItem(IDC_CHECK_UPANDDOWN)->EnableWindow(0);



		GetDlgItem(IDC_EDIT_SAVE_FPS)->EnableWindow(1);

		m_run_mode = 4;
	}
	else if (ycbcr_found1 || ycbcr_found2) {
		OnModeInit();
		m_bAviStop = FALSE;
		dialogInit = FALSE;

		Memo_Write("YCbCr input detected --> YCbCr processing mode");

		fopen_s(&m_fpYCbCr, const_cast<char*>(strFileName.c_str()), "rb");
		if (m_fpYCbCr == NULL) {
			//AfxMessageBox("m_fpYCbCr : file open failed");
			Memo_Write("m_fpYCbCr : failed to open file!");
		}
		else;

		_fseeki64(m_fpYCbCr, 0, SEEK_END);
		m_pFrame_end = _ftelli64(m_fpYCbCr);

		GetDlgItem(IDC_BUTTON_AVI_RUN)->EnableWindow(1);
		GetDlgItem(IDC_BUTTON_AVI_STOP)->EnableWindow(0);

		GetDlgItem(IDC_BUTTON_AVI_OPEN)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_YUV_OPEN)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_YCbCr_OPEN)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_CAM_START)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_FILE_OPEN)->EnableWindow(0);

		GetDlgItem(IDC_BUTTON_AVIFORM_SAVE)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_AVIFORM_SAVE2)->EnableWindow(0);// MP4
		GetDlgItem(IDC_STATIC_BB_BDM_M_P2)->EnableWindow(0);
		GetDlgItem(IDC_SLIDER_MP4_SAVE_COMP_LEVEL)->EnableWindow(0);
		GetDlgItem(IDC_EDIT_MP4_SAVE_COMP_LEVEL)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_YUV_SAVE)->EnableWindow(1);
		GetDlgItem(IDC_BUTTON_YCbCr_SAVE)->EnableWindow(1);


		GetDlgItem(IDC_EDIT_SAVE_FPS)->EnableWindow(1);

		m_run_mode = 5;
	}
	else
	{
		OnModeInit();
		Memo_Write("please select video format!");
	};
	m_frame_num = 0;
}

void CVS2022_DefaultDlg::OnButton_YcbcrOpen()
{
	OnModeInit();
	m_bAviStop = FALSE;
	dialogInit = FALSE;

	CFileDialog fileOpen(TRUE, "Open Image", NULL, OFN_FILEMUSTEXIST |
		OFN_PATHMUSTEXIST | OFN_EXPLORER, "YCbCr File(*.ycbcr)|*.ycbcr;|All Files(*.*)|*.*||", NULL);

	if (fileOpen.DoModal() != IDOK) return;
	else;

	cv::String strFileName = fileOpen.GetPathName();

	// process according to extension
	mp4_found1 = strFileName.find(".mp4") != string::npos;
	mp4_found2 = strFileName.find(".MP4") != string::npos;
	avi_found1 = strFileName.find(".avi") != string::npos;
	avi_found2 = strFileName.find(".AVI") != string::npos;
	yuv_found1 = strFileName.find(".yuv") != string::npos;
	yuv_found2 = strFileName.find(".YUV") != string::npos;
	ycbcr_found1 = strFileName.find(".ycbcr") != string::npos;
	ycbcr_found2 = strFileName.find(".YCbCr") != string::npos;

	if (mp4_found1 || mp4_found2) {
		OnModeInit();
		m_bAviStop = FALSE;
		dialogInit = FALSE;

		Memo_Write("MP4 input detected --> MP4 processing mode");
		capture = VideoCapture(strFileName);
		//capture = &temp_capture;
		if (!capture.isOpened()) {
			Memo_Write("Could not open input video!");
			return;
		}
		else;

		// get fps, needed to set the delay  
		fps = (int)capture.get(CAP_PROP_FPS);

		GetDlgItem(IDC_BUTTON_AVI_RUN)->EnableWindow(1);
		GetDlgItem(IDC_BUTTON_AVI_STOP)->EnableWindow(0);

		GetDlgItem(IDC_RADIO_YUV444R)->EnableWindow(1);
		GetDlgItem(IDC_RADIO_YUV422R)->EnableWindow(1);
		GetDlgItem(IDC_RADIO_YUV420R)->EnableWindow(1);

		GetDlgItem(IDC_RADIO_YUV444W)->EnableWindow(1);
		GetDlgItem(IDC_RADIO_YUV422W)->EnableWindow(1);
		GetDlgItem(IDC_RADIO_YUV420W)->EnableWindow(1);

		GetDlgItem(IDC_BUTTON_AVI_OPEN)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_YUV_OPEN)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_YCbCr_OPEN)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_CAM_START)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_FILE_OPEN)->EnableWindow(0);

		GetDlgItem(IDC_BUTTON_AVIFORM_SAVE)->EnableWindow(1);
		GetDlgItem(IDC_BUTTON_YUV_SAVE)->EnableWindow(1);
		GetDlgItem(IDC_BUTTON_YCbCr_SAVE)->EnableWindow(1);
		GetDlgItem(IDC_CHECK_SIDEBYSIDE)->EnableWindow(0);
		GetDlgItem(IDC_CHECK_UPANDDOWN)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_AVIFORM_SAVE2)->EnableWindow(1);
		GetDlgItem(IDC_STATIC_BB_BDM_M_P2)->EnableWindow(1);
		GetDlgItem(IDC_SLIDER_MP4_SAVE_COMP_LEVEL)->EnableWindow(1);
		GetDlgItem(IDC_EDIT_MP4_SAVE_COMP_LEVEL)->EnableWindow(1);


		GetDlgItem(IDC_EDIT_SAVE_FPS)->EnableWindow(1);

		m_run_mode = 6;

		// FFMPEG, save video and audio, addded 2022.07.22
		ret = avformat_open_input(&ifmt_ctx, const_cast<char*>(strFileName.c_str()), 0, 0);
		if (ret < 0) {
			Memo_Write("Could not open input video!");
			avformat_close_input(&ifmt_ctx);
			return;
		}

		ret = avformat_find_stream_info(ifmt_ctx, 0);
		if (ret < 0) {
			Memo_Write("Failed to retrieve input stream information!");
			avformat_close_input(&ifmt_ctx);
			return;
		}

		for (int i = 0; i < ifmt_ctx->nb_streams; i++) {
			AVStream* stream;
			AVCodecContext* codec_ctx;
			stream = ifmt_ctx->streams[i];
			codec_ctx = stream->codec;
			if (codec_ctx->codec_type == AVMEDIA_TYPE_AUDIO ||
				codec_ctx->codec_type == AVMEDIA_TYPE_VIDEO) {
				ret = avcodec_open2(codec_ctx, avcodec_find_decoder(codec_ctx->codec_id), NULL);
				if (ret < 0) {
					Memo_Write("Failed to open decoder for input stream!");
					return;
				}
			}
			if (codec_ctx->codec_type == AVMEDIA_TYPE_VIDEO)
				video_index = i;
			else if (codec_ctx->codec_type == AVMEDIA_TYPE_AUDIO)
				audio_index = i;
			else;
		}

		av_dump_format(ifmt_ctx, 0, const_cast<char*>(strFileName.c_str()), 0);
		if (m_check_sidebyside == FALSE && m_check_upanddown == FALSE) {
			sws_ctx_bgr_yuv = sws_getContext(ifmt_ctx->streams[video_index]->codec->width,
				ifmt_ctx->streams[video_index]->codec->height,
				AV_PIX_FMT_BGR24,
				ifmt_ctx->streams[video_index]->codec->width,
				ifmt_ctx->streams[video_index]->codec->height,
				ifmt_ctx->streams[video_index]->codec->pix_fmt,
				0, 0, NULL, NULL);
		}
		else if (m_check_sidebyside == TRUE) {
			sws_ctx_bgr_yuv = sws_getContext(ifmt_ctx->streams[video_index]->codec->width * 2,
				ifmt_ctx->streams[video_index]->codec->height,
				AV_PIX_FMT_BGR24,
				ifmt_ctx->streams[video_index]->codec->width * 2,
				ifmt_ctx->streams[video_index]->codec->height,
				ifmt_ctx->streams[video_index]->codec->pix_fmt,
				0, 0, NULL, NULL);
		}
		else {
			sws_ctx_bgr_yuv = sws_getContext(ifmt_ctx->streams[video_index]->codec->width,
				ifmt_ctx->streams[video_index]->codec->height * 2,
				AV_PIX_FMT_BGR24,
				ifmt_ctx->streams[video_index]->codec->width,
				ifmt_ctx->streams[video_index]->codec->height * 2,
				ifmt_ctx->streams[video_index]->codec->pix_fmt,
				0, 0, NULL, NULL);
		}

		total_frame_count = ifmt_ctx->streams[video_index]->nb_frames;
	}
	else if (avi_found1 || avi_found2) {
		OnModeInit();
		m_bAviStop = FALSE;
		dialogInit = FALSE;

		Memo_Write("AVI input detected --> AVI processing mode");
		capture = VideoCapture(strFileName);
		//capture = &temp_capture;
		if (!capture.isOpened()) {
			Memo_Write("Could not open input video!");
			return;
		}
		else;

		// get fps, needed to set the delay  
		fps = (int)capture.get(CAP_PROP_FPS);

		GetDlgItem(IDC_BUTTON_AVI_RUN)->EnableWindow(1);
		GetDlgItem(IDC_BUTTON_AVI_STOP)->EnableWindow(0);

		GetDlgItem(IDC_RADIO_YUV444R)->EnableWindow(1);
		GetDlgItem(IDC_RADIO_YUV422R)->EnableWindow(1);
		GetDlgItem(IDC_RADIO_YUV420R)->EnableWindow(1);

		GetDlgItem(IDC_RADIO_YUV444W)->EnableWindow(1);
		GetDlgItem(IDC_RADIO_YUV422W)->EnableWindow(1);
		GetDlgItem(IDC_RADIO_YUV420W)->EnableWindow(1);

		GetDlgItem(IDC_BUTTON_AVI_OPEN)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_YUV_OPEN)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_YCbCr_OPEN)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_CAM_START)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_FILE_OPEN)->EnableWindow(0);

		GetDlgItem(IDC_BUTTON_AVIFORM_SAVE)->EnableWindow(1);
		GetDlgItem(IDC_BUTTON_YUV_SAVE)->EnableWindow(1);
		GetDlgItem(IDC_BUTTON_YCbCr_SAVE)->EnableWindow(1);
		GetDlgItem(IDC_CHECK_SIDEBYSIDE)->EnableWindow(0);
		GetDlgItem(IDC_CHECK_UPANDDOWN)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_AVIFORM_SAVE2)->EnableWindow(0);
		GetDlgItem(IDC_STATIC_BB_BDM_M_P2)->EnableWindow(0);
		GetDlgItem(IDC_SLIDER_MP4_SAVE_COMP_LEVEL)->EnableWindow(0);
		GetDlgItem(IDC_EDIT_MP4_SAVE_COMP_LEVEL)->EnableWindow(0);


		GetDlgItem(IDC_EDIT_SAVE_FPS)->EnableWindow(1);

		m_run_mode = 3;

		total_frame_count = (int)capture.get(CAP_PROP_FRAME_COUNT);
	}
	else if (yuv_found1 || yuv_found2) {
		OnModeInit();
		m_bAviStop = FALSE;
		dialogInit = FALSE;

		Memo_Write("YUV input detected --> YUV processing mode");

		fopen_s(&m_fpYUV, const_cast<char*>(strFileName.c_str()), "rb");
		if (m_fpYUV == NULL) {
			//AfxMessageBox("m_fpYUV : file open failed");
			Memo_Write("m_fpYUV : failed to open file!");
		}
		else;

		_fseeki64(m_fpYUV, 0, SEEK_END); // �� ���������� ã��
		m_pFrame_end = _ftelli64(m_fpYUV);

		GetDlgItem(IDC_BUTTON_AVI_RUN)->EnableWindow(1);
		GetDlgItem(IDC_BUTTON_AVI_STOP)->EnableWindow(0);

		GetDlgItem(IDC_BUTTON_AVI_OPEN)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_YUV_OPEN)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_YCbCr_OPEN)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_CAM_START)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_FILE_OPEN)->EnableWindow(0);

		GetDlgItem(IDC_BUTTON_AVIFORM_SAVE)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_AVIFORM_SAVE2)->EnableWindow(0);// MP4
		GetDlgItem(IDC_STATIC_BB_BDM_M_P2)->EnableWindow(0);
		GetDlgItem(IDC_SLIDER_MP4_SAVE_COMP_LEVEL)->EnableWindow(0);
		GetDlgItem(IDC_EDIT_MP4_SAVE_COMP_LEVEL)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_YUV_SAVE)->EnableWindow(1);
		GetDlgItem(IDC_BUTTON_YCbCr_SAVE)->EnableWindow(1);

		GetDlgItem(IDC_CHECK_SIDEBYSIDE)->EnableWindow(0);
		GetDlgItem(IDC_CHECK_UPANDDOWN)->EnableWindow(0);



		GetDlgItem(IDC_EDIT_SAVE_FPS)->EnableWindow(1);

		m_run_mode = 4;
	}
	else if (ycbcr_found1 || ycbcr_found2) {
		fopen_s(&m_fpYCbCr, const_cast<char*>(strFileName.c_str()), "rb");
		if (m_fpYCbCr == NULL) {
			//AfxMessageBox("m_fpYCbCr : file open failed");
			Memo_Write("m_fpYCbCr : failed to open file!");
		}
		else;

		_fseeki64(m_fpYCbCr, 0, SEEK_END);
		m_pFrame_end = _ftelli64(m_fpYCbCr);

		GetDlgItem(IDC_BUTTON_AVI_RUN)->EnableWindow(1);
		GetDlgItem(IDC_BUTTON_AVI_STOP)->EnableWindow(0);

		GetDlgItem(IDC_BUTTON_AVI_OPEN)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_YUV_OPEN)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_YCbCr_OPEN)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_CAM_START)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_FILE_OPEN)->EnableWindow(0);

		GetDlgItem(IDC_BUTTON_AVIFORM_SAVE)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_AVIFORM_SAVE2)->EnableWindow(0);// MP4
		GetDlgItem(IDC_STATIC_BB_BDM_M_P2)->EnableWindow(0);
		GetDlgItem(IDC_SLIDER_MP4_SAVE_COMP_LEVEL)->EnableWindow(0);
		GetDlgItem(IDC_EDIT_MP4_SAVE_COMP_LEVEL)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_YUV_SAVE)->EnableWindow(1);
		GetDlgItem(IDC_BUTTON_YCbCr_SAVE)->EnableWindow(1);


		GetDlgItem(IDC_EDIT_SAVE_FPS)->EnableWindow(1);

		m_run_mode = 5;
	}
	else
	{
		OnModeInit();
		Memo_Write("please select video format!");
	};

	m_frame_num = 0;
}

void CVS2022_DefaultDlg::OnButton_AviRun()
{
	GetDlgItem(IDC_BUTTON_CAM_TEST)->EnableWindow(0);

	m_height = atoi(m_edit_Video_height);
	m_width = atoi(m_edit_Video_width);
	fps = atoi(m_edit_frame_rate);

	if ((m_height != 0) && (m_width != 0) && (fps != 0)) {
		if (m_run_mode == 4) // yuv open
		{
			UpdateData(TRUE);
			// m_memo ===================================================
			switch (m_radio_read) {
			case 0: s.Format("YUV 444 format Read"); break;
			case 1: s.Format("YUV 422 format Read"); break;
			case 2: s.Format("YUV 420 format Read"); break;
			default: s.Format("YUV 420 format Read");
			}
			((CHistoryEdit*)GetDlgItem(IDC_EDIT_MEMO))->AppendString(s);

			s.Format("%d x %d pixel, %d fps\r\n", m_width, m_height, fps);
			((CHistoryEdit*)GetDlgItem(IDC_EDIT_MEMO))->AppendString(s);

			Memo_Write("------------");
			s.Format("fp end = %I64d", m_pFrame_end);
			((CHistoryEdit*)GetDlgItem(IDC_EDIT_MEMO))->AppendString(s);

			_fseeki64(m_fpYUV, -m_pFrame_end, SEEK_CUR); // Return to starting point

			__int64 fp_now = _ftelli64(m_fpYUV);
			s.Format("fp end = %I64d", fp_now);
			((CHistoryEdit*)GetDlgItem(IDC_EDIT_MEMO))->AppendString(s);
			Memo_Write("------------");

			m_YUVlength = m_height * m_width * 3; // 1 Fraem Length
			m_totalFrame = m_pFrame_end / m_YUVlength; // Total Frame Length

			s.Format("total file pointer : %I64d\r\n", m_pFrame_end);
			s.Format(s + "each frame length : %d\r\n", m_YUVlength);
			((CHistoryEdit*)GetDlgItem(IDC_EDIT_MEMO))->AppendString(s);

			s.Format("total frame = %I64d\r\n", m_totalFrame);
			((CHistoryEdit*)GetDlgItem(IDC_EDIT_MEMO))->AppendString(s);

			if (m_fpYUV == NULL) Memo_Write("open nothing");
			else;
		}

		else if (m_run_mode == 5) //YCbCr working
		{
			UpdateData(TRUE);

			switch (m_radio_read) {
			case 0: s.Format("YCbCr 444 format Read"); break;
			case 1: s.Format("YCbCr 422 format Read"); break;
			case 2: s.Format("YCbCr 420 format Read"); break;
			default: s.Format("YCbCr 420 format Read");
			}
			((CHistoryEdit*)GetDlgItem(IDC_EDIT_MEMO))->AppendString(s);

			s.Format("%d x %d pixel, %d fps\r\n", m_width, m_height, fps);
			((CHistoryEdit*)GetDlgItem(IDC_EDIT_MEMO))->AppendString(s);

			Memo_Write("------------");
			s.Format("fp end = %I64d", m_pFrame_end);
			((CHistoryEdit*)GetDlgItem(IDC_EDIT_MEMO))->AppendString(s);

			_fseeki64(m_fpYCbCr, -m_pFrame_end, SEEK_CUR); // Return to starting point

			__int64 fp_now = _ftelli64(m_fpYCbCr);
			s.Format("fp end = %I64d", fp_now);
			((CHistoryEdit*)GetDlgItem(IDC_EDIT_MEMO))->AppendString(s);
			Memo_Write("------------");

			m_YCbCrlength = m_height * m_width * 3;			// 1 Fraem Length
			m_totalFrame = m_pFrame_end / m_YCbCrlength;	// Total Frame Length

			s.Format("total file pointer : %I64d\r\n", m_pFrame_end);
			s.Format(s + "each frame length : %d\r\n", m_YCbCrlength);
			((CHistoryEdit*)GetDlgItem(IDC_EDIT_MEMO))->AppendString(s);

			s.Format("total frame = %I64d\r\n", m_totalFrame);
			((CHistoryEdit*)GetDlgItem(IDC_EDIT_MEMO))->AppendString(s);

			if (m_fpYCbCr == NULL) Memo_Write("open nothing");
			else;
		}
		else;

		// ThreadProcessingAVI
		m_pthread = AfxBeginThread(ThreadProcessingAVI, (LPVOID)this, 0);
		HANDLE hThread = m_pthread->m_hThread;
		Memo_Write("Video File Processing");

		GetDlgItem(IDC_BUTTON_AVI_RUN)->EnableWindow(0);
		GetDlgItem(IDC_EDIT_YUV_WIDTH)->EnableWindow(0);
		GetDlgItem(IDC_EDIT_YUV_HEIGHT)->EnableWindow(0);
		GetDlgItem(IDC_EDIT_YUV_FRAME)->EnableWindow(0);
		GetDlgItem(IDC_EDIT_SAVE_FPS)->EnableWindow(0); // fps ���׼���

		GetDlgItem(IDC_BUTTON_AVI_STOP)->EnableWindow(1);
		GetDlgItem(IDC_BUTTON_AVI_PAUSE)->EnableWindow(1);


		if ((ofmt_ctx != NULL) || (VideoOut.isOpened()) || (m_bYUVSave == TRUE) || (m_bYCbCrSave == TRUE)) GetDlgItem(IDC_BUTTON_AVI_STOP)->EnableWindow(0);
		else GetDlgItem(IDC_BUTTON_AVI_STOP)->EnableWindow(1);

		if (m_check_sidebyside == TRUE || m_check_upanddown == TRUE) {
			//AfxMessageBox(" ���� ���� ���Ŀ��� Pause ��ư�� ������ Side-by-side ������ ������ �� �ֽ��ϴ�. ");

			if ((mp4_save == FALSE) && (avi_save == FALSE)) {
				GetDlgItem(IDC_BUTTON_AVIFORM_SAVE2)->EnableWindow(0);
				GetDlgItem(IDC_BUTTON_AVIFORM_SAVE)->EnableWindow(0);
				GetDlgItem(IDC_BUTTON_YUV_SAVE)->EnableWindow(0);
				GetDlgItem(IDC_BUTTON_YCbCr_SAVE)->EnableWindow(0);
			}

		}
		else;
		// added 2022.08.02
		if (mp4_save || avi_save || yuv_save || ycbcr_save) {

			if (mp4_save == TRUE && (mp4_found1 || mp4_found2))
				GetDlgItem(IDC_BUTTON_AVIFORM_SAVE2)->EnableWindow(1);
			else
				GetDlgItem(IDC_BUTTON_AVIFORM_SAVE2)->EnableWindow(0);

			GetDlgItem(IDC_STATIC_BB_BDM_M_P2)->EnableWindow(0);
			GetDlgItem(IDC_SLIDER_MP4_SAVE_COMP_LEVEL)->EnableWindow(0);
			GetDlgItem(IDC_EDIT_MP4_SAVE_COMP_LEVEL)->EnableWindow(0);

			if (avi_save == TRUE && (mp4_found1 || mp4_found2 || avi_found1 || avi_found2))
				GetDlgItem(IDC_BUTTON_AVIFORM_SAVE)->EnableWindow(1);
			else
				GetDlgItem(IDC_BUTTON_AVIFORM_SAVE)->EnableWindow(0);
			if (yuv_save == TRUE && (mp4_found1 || mp4_found2 || avi_found1 || avi_found2 || yuv_found1 || yuv_found2 || ycbcr_found1 || ycbcr_found2))
				GetDlgItem(IDC_BUTTON_YUV_SAVE)->EnableWindow(1);
			else
				GetDlgItem(IDC_BUTTON_YUV_SAVE)->EnableWindow(0);
			if (ycbcr_save == TRUE && (mp4_found1 || mp4_found2 || avi_found1 || avi_found2 || yuv_found1 || yuv_found2 || ycbcr_found1 || ycbcr_found2))
				GetDlgItem(IDC_BUTTON_YCbCr_SAVE)->EnableWindow(1);
			else
				GetDlgItem(IDC_BUTTON_YCbCr_SAVE)->EnableWindow(0);
		}
		else {
			if (mp4_found1 || mp4_found2) {
				GetDlgItem(IDC_BUTTON_AVIFORM_SAVE2)->EnableWindow(1);
				GetDlgItem(IDC_STATIC_BB_BDM_M_P2)->EnableWindow(1);
				GetDlgItem(IDC_SLIDER_MP4_SAVE_COMP_LEVEL)->EnableWindow(1);
				GetDlgItem(IDC_EDIT_MP4_SAVE_COMP_LEVEL)->EnableWindow(1);
				GetDlgItem(IDC_BUTTON_AVIFORM_SAVE)->EnableWindow(1);
				GetDlgItem(IDC_BUTTON_YUV_SAVE)->EnableWindow(1);
				GetDlgItem(IDC_BUTTON_YCbCr_SAVE)->EnableWindow(1);
			}
			if (avi_found1 || avi_found2) {
				GetDlgItem(IDC_BUTTON_AVIFORM_SAVE2)->EnableWindow(0);
				GetDlgItem(IDC_STATIC_BB_BDM_M_P2)->EnableWindow(0);
				GetDlgItem(IDC_SLIDER_MP4_SAVE_COMP_LEVEL)->EnableWindow(0);
				GetDlgItem(IDC_EDIT_MP4_SAVE_COMP_LEVEL)->EnableWindow(0);
				GetDlgItem(IDC_BUTTON_AVIFORM_SAVE)->EnableWindow(1);
				GetDlgItem(IDC_BUTTON_YUV_SAVE)->EnableWindow(1);
				GetDlgItem(IDC_BUTTON_YCbCr_SAVE)->EnableWindow(1);
			}
			if (yuv_found1 || yuv_found2 || ycbcr_found1 || ycbcr_found2) {
				GetDlgItem(IDC_BUTTON_AVIFORM_SAVE2)->EnableWindow(0);
				GetDlgItem(IDC_STATIC_BB_BDM_M_P2)->EnableWindow(0);
				GetDlgItem(IDC_SLIDER_MP4_SAVE_COMP_LEVEL)->EnableWindow(0);
				GetDlgItem(IDC_EDIT_MP4_SAVE_COMP_LEVEL)->EnableWindow(0);
				GetDlgItem(IDC_BUTTON_AVIFORM_SAVE)->EnableWindow(0);
				GetDlgItem(IDC_BUTTON_YUV_SAVE)->EnableWindow(1);
				GetDlgItem(IDC_BUTTON_YCbCr_SAVE)->EnableWindow(1);
			}
		}
		GetDlgItem(IDC_BUTTON_AVI_STOP)->EnableWindow(1);
	}
	else {
		//AfxMessageBox(" frame ũ��� fps ���� 0�� �� �� �����ϴ�. ");
	}
}

void CVS2022_DefaultDlg::AviStopProc()
{

	m_bAviStop = TRUE;
	save_over = TRUE;

	Memo_Write("Video Play Stop");


	// reset the button states
	// open
	GetDlgItem(IDC_BUTTON_CAM_START)->EnableWindow(1);
	GetDlgItem(IDC_BUTTON_AVI_OPEN)->EnableWindow(1);
	GetDlgItem(IDC_BUTTON_YUV_OPEN)->EnableWindow(1);
	GetDlgItem(IDC_BUTTON_FILE_OPEN)->EnableWindow(1);
	GetDlgItem(IDC_BUTTON_YCbCr_OPEN)->EnableWindow(1);
	// Cam
	GetDlgItem(IDC_BUTTON_CAM_STOP)->EnableWindow(0);
	GetDlgItem(IDC_BUTTON_CAM_CAPTURE)->EnableWindow(0);
	GetDlgItem(IDC_BUTTON_CAM_AVISAVE)->EnableWindow(0); // MP4 �߰�
	// File
	GetDlgItem(IDC_BUTTON_FILE_RUN)->EnableWindow(0);
	GetDlgItem(IDC_BUTTON_FILE_CAPTURE)->EnableWindow(0);
	// MP4
	GetDlgItem(IDC_BUTTON_AVIFORM_SAVE2)->EnableWindow(0); //MP4 �߰�
	GetDlgItem(IDC_STATIC_BB_BDM_M_P2)->EnableWindow(1);
	GetDlgItem(IDC_SLIDER_MP4_SAVE_COMP_LEVEL)->EnableWindow(1);
	GetDlgItem(IDC_EDIT_MP4_SAVE_COMP_LEVEL)->EnableWindow(1);
	// Avi
	GetDlgItem(IDC_BUTTON_AVI_RUN)->EnableWindow(0);
	GetDlgItem(IDC_BUTTON_AVI_PAUSE)->EnableWindow(0);
	GetDlgItem(IDC_BUTTON_YUV_SAVE)->EnableWindow(0);
	GetDlgItem(IDC_BUTTON_AVI_STOP)->EnableWindow(0);
	GetDlgItem(IDC_BUTTON_VIDEO_CAPTURE)->EnableWindow(0);
	GetDlgItem(IDC_BUTTON_AVIFORM_SAVE)->EnableWindow(0);
	GetDlgItem(IDC_BUTTON_YCbCr_SAVE)->EnableWindow(0);
	GetDlgItem(IDC_CHECK_SIDEBYSIDE)->EnableWindow(1);
	GetDlgItem(IDC_CHECK_UPANDDOWN)->EnableWindow(1);

	if ((VideoOut.isOpened()) || (ofmt_ctx != NULL)) {
		if (VideoOut.isOpened()) {
			VideoOut.release();
			if (avi_save == TRUE) {
				CFileDialog fileSave(FALSE, "avi", NULL, OFN_FILEMUSTEXIST |
					OFN_PATHMUSTEXIST | OFN_EXPLORER,
					"AVI File(*.avi)", NULL);

				char szFilter[] = "AVI Files(*.avi)|*.avi";

				CString strSaveFileName;
				fileSave.m_ofn.lpstrFilter = szFilter;
				if (IDOK == fileSave.DoModal()) {
					strSaveFileName = fileSave.GetPathName();
					MoveFile("avitmp.avi", strSaveFileName);
				}
				else {
					DeleteFile("avitmp.avi");
				}
				GetDlgItem(IDC_BUTTON_AVIFORM_SAVE)->SetWindowText(".avi Save");
				avi_save = FALSE;
			}
			else;
		}

		if (ofmt_ctx != NULL) {
			if (mp4_save == TRUE && ifmt_ctx) {

				// FFMPEG save video and audio, added 2022.07.22
				for (int j = 0; j < ifmt_ctx->nb_streams; j++) {
					ret = flush_encoder(j);
					if (ret < 0) {
						Memo_Write("Failed to flush encoder!");
						for (int i = 0; i < ifmt_ctx->nb_streams; i++) {
							avcodec_close(ifmt_ctx->streams[i]->codec);
							if (ofmt_ctx && ofmt_ctx->nb_streams > i && ofmt_ctx->streams[i] && ofmt_ctx->streams[i]->codec)
								avcodec_close(ofmt_ctx->streams[i]->codec);
						}
						avformat_close_input(&ifmt_ctx);
						if (ofmt_ctx && !(ofmt_ctx->oformat->flags & AVFMT_NOFILE))
							avio_closep(&ofmt_ctx->pb);
						avformat_free_context(ofmt_ctx);
						if (ret < 0 && ret != AVERROR_EOF)
							Memo_Write("Error occurred!");
						av_frame_free(&avframe);
						av_packet_free(&pkt);
					}
				}
				av_write_trailer(ofmt_ctx);
				for (int i = 0; i < ifmt_ctx->nb_streams; i++) {
					avcodec_close(ifmt_ctx->streams[i]->codec);
					if (ofmt_ctx && ofmt_ctx->nb_streams > i && ofmt_ctx->streams[i] && ofmt_ctx->streams[i]->codec)
						avcodec_close(ofmt_ctx->streams[i]->codec);
				}
				avformat_close_input(&ifmt_ctx);
				if (ofmt_ctx && !(ofmt_ctx->oformat->flags & AVFMT_NOFILE))
					avio_closep(&ofmt_ctx->pb);
				avformat_free_context(ofmt_ctx);
				if (ret < 0 && ret != AVERROR_EOF)
					Memo_Write("Error occurred!");
				av_frame_free(&avframe);
				av_packet_free(&pkt);
				sws_freeContext(sws_ctx_bgr_yuv);

				// ask user to enter the file name and move the temporary file
				CFileDialog fileSave(FALSE, "MP4", NULL, OFN_FILEMUSTEXIST | //���� ����/���� ��ȭ���� 
					OFN_PATHMUSTEXIST | OFN_EXPLORER,
					"MP4 File(*.mp4)", NULL);

				char szFilter[] = "MP4 Files(*mp4)|*.mp4"; //SAVE STOP�� ������ ������ ������ Ȯ����.

				CString strSaveFileName;
				fileSave.m_ofn.lpstrFilter = szFilter;
				int nRet = fileSave.DoModal();
				if (nRet == IDOK) {
					strSaveFileName = fileSave.GetPathName();
					MoveFile(sfilename, strSaveFileName);
				}
				else {
					DeleteFile(sfilename);
				}

				GetDlgItem(IDC_BUTTON_AVIFORM_SAVE2)->SetWindowText(".mp4 Save");

				mp4_save = FALSE;


			}
			else;
		}
	}
	else;

	if (yuv_save == TRUE) {
		yuv_save = FALSE;
		if (m_bYUVSave == TRUE) {
			Memo_Write("Video File Save End");
			GetDlgItem(IDC_BUTTON_YUV_SAVE)->SetWindowText(".yuv Save");

			fclose(m_fpAviSave);

			CFileDialog fileSave(FALSE, "yuv", NULL, OFN_FILEMUSTEXIST |
				OFN_PATHMUSTEXIST | OFN_EXPLORER,
				"YUV File(*.yuv)|*.yuv;|All Files(*.*)|*.*||", NULL);

			char szFilter[] = "YUV Files(*.yuv)|*.yuv";

			CString strSaveFileName;
			fileSave.m_ofn.lpstrFilter = szFilter;
			if (IDOK == fileSave.DoModal()) {
				strSaveFileName = fileSave.GetPathName();
				MoveFile("yuv_temp.YUV", strSaveFileName);
			}
			else {
				DeleteFile("yuv_temp.YUV");
			}
		}
		else;
	}

	if (ycbcr_save == TRUE) {
		ycbcr_save = FALSE;
		if (m_bYCbCrSave == TRUE) {
			Memo_Write("Video File Save End");
			GetDlgItem(IDC_BUTTON_YCbCr_SAVE)->SetWindowText(".ycbcr Save");

			fclose(m_fpAviSave);

			CFileDialog fileSave(FALSE, "ycbcr", NULL, OFN_FILEMUSTEXIST |
				OFN_PATHMUSTEXIST | OFN_EXPLORER,
				"YCbCr File(*.YCbCr)|*.ycbcr;|All Files(*.*)|*.*||", NULL);

			char szFilter[] = "YCbCr Files(*.ycbcr)|*.ycbcr";

			CString strSaveFileName;
			fileSave.m_ofn.lpstrFilter = szFilter;
			if (IDOK == fileSave.DoModal()) {
				strSaveFileName = fileSave.GetPathName();
				MoveFile("ycbcr_temp.YCbCr", strSaveFileName);
			}
			else {
				DeleteFile("ycbcr_temp.YCbCr");
			}
		}
		else;
	}

	// clean ifmt_ctx for processing a new file (if not, cannot process a new file)
	if (ifmt_ctx) {
		for (int i = 0; i < ifmt_ctx->nb_streams; i++)
			avcodec_close(ifmt_ctx->streams[i]->codec);
		avformat_close_input(&ifmt_ctx);
	}
	avistopflag = 0;
	mp4_found1 = false;
	mp4_found2 = false;
	avi_found1 = false;
	avi_found2 = false;
	yuv_found1 = false;
	yuv_found2 = false;
	ycbcr_found1 = false;
	ycbcr_found2 = false;

}

void CVS2022_DefaultDlg::OnButton_AviStop()
{
	avistopflag = 1;
}

void CVS2022_DefaultDlg::OnButton_AviPause()
{
	if (!m_bAviPause) {
		GetDlgItem(IDC_BUTTON_VIDEO_CAPTURE)->EnableWindow(1);
		GetDlgItem(IDC_BUTTON_AVI_PAUSE)->SetWindowText("Resume");
		Memo_Write("Pause");
		m_bAviPause = TRUE;
	}
	else {
		GetDlgItem(IDC_BUTTON_VIDEO_CAPTURE)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_AVI_PAUSE)->SetWindowText("Pause");
		Memo_Write("Resume");
		m_bAviPause = FALSE;
	}
}

void CVS2022_DefaultDlg::OnButton_VideoCapture()
{
	m_capture_flag = TRUE;
}

void CVS2022_DefaultDlg::OnButton_AviSave()
{
	int savewidth;
	int saveheight;
	if (!VideoOut.isOpened()) {
		avi_save = TRUE;

		if (m_run_mode == 3 || m_run_mode == 6) {
			capture.read(SaveImage);  // get a frame 

			if (m_check_sidebyside == FALSE && m_check_upanddown == FALSE) {
				savewidth = SaveImage.cols;
				saveheight = SaveImage.rows;
			}

			else if (m_check_sidebyside == TRUE) {
				savewidth = SaveImage.cols * 2;
				saveheight = SaveImage.rows;
			}
			else if (m_check_upanddown == TRUE) {
				savewidth = SaveImage.cols;
				saveheight = SaveImage.rows * 2;
			}
			m_width = SaveImage.cols;
			m_height = SaveImage.rows;
		}
		else {
			if (m_check_sidebyside == FALSE && m_check_upanddown == FALSE) {
				UpdateData(TRUE);
				saveheight = atoi(m_edit_Video_height);
				savewidth = atoi(m_edit_Video_width);
				UpdateData(FALSE);
			}
			else if (m_check_sidebyside == TRUE) {
				UpdateData(TRUE);
				saveheight = atoi(m_edit_Video_height);
				savewidth = atoi(m_edit_Video_width) * 2;
				UpdateData(FALSE);
			}
			else if (m_check_upanddown == TRUE) {
				UpdateData(TRUE);
				saveheight = atoi(m_edit_Video_height) * 2;
				savewidth = atoi(m_edit_Video_width);
				UpdateData(FALSE);
			}
			UpdateData(TRUE);
			m_height = atoi(m_edit_Video_height);
			m_width = atoi(m_edit_Video_width);
			UpdateData(FALSE);
		}

		UpdateData(TRUE);
		save_fps = atoi(m_edit_save_fps);
		UpdateData(FALSE);

		//AfxMessageBox(" Codec ���ÿ� ���� .avi ������ ���� ������ �޶� �� �� �ֽ��ϴ�. ");

		cv::String strSaveFileName = "avitmp.avi";

		CFileFind pFind;
		BOOL bRet = pFind.FindFile(strSaveFileName.c_str());
		if (bRet == TRUE)
		{
			DeleteFile(strSaveFileName.c_str());
			bRet = FALSE;
		}
		else;


		VideoOut.open(strSaveFileName, VideoWriter::fourcc('D', 'I', 'V', '3'), save_fps, Size(savewidth, saveheight), 1);

		if (!VideoOut.isOpened())
		{
			DeleteFile("avitmp.avi");
			Memo_Write("avi codec not found!");
			return;
		}
		else;

		if (save_over == FALSE) {
			GetDlgItem(IDC_BUTTON_AVIFORM_SAVE)->SetWindowText("Save Stop");
			Memo_Write("Video Save Start");
		}

		GetDlgItem(IDC_BUTTON_YCbCr_SAVE)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_YUV_SAVE)->EnableWindow(0);
		GetDlgItem(IDC_EDIT_SAVE_FPS)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_AVIFORM_SAVE)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_AVIFORM_SAVE2)->EnableWindow(0);// MP4 �߰�
		GetDlgItem(IDC_STATIC_BB_BDM_M_P2)->EnableWindow(0);
		GetDlgItem(IDC_SLIDER_MP4_SAVE_COMP_LEVEL)->EnableWindow(0);
		GetDlgItem(IDC_EDIT_MP4_SAVE_COMP_LEVEL)->EnableWindow(0);
		if (m_pthread != NULL)
		{
			GetDlgItem(IDC_BUTTON_AVIFORM_SAVE)->EnableWindow(1);
		}
		m_bAvi_Save_Stop = FALSE;

		if (save_over == TRUE)
		{
			GetDlgItem(IDC_BUTTON_AVIFORM_SAVE)->SetWindowText(".avi Save");
			Memo_Write("[Warning] Video Save Fail");
			OnButton_AviStop();
			return;
		}
		else;

		if (m_bAviPause == TRUE) {
			GetDlgItem(IDC_BUTTON_AVI_PAUSE)->SetWindowText("Pause");
			Memo_Write("Resume");
			m_bAviPause = FALSE;
		}
		else;

	}
	else {
		m_bAvi_Save_Stop = TRUE;
		avi_save = FALSE;
		m_bAviStop = TRUE; // stop processing after saving

		// reset the button states
		// open
		GetDlgItem(IDC_BUTTON_CAM_START)->EnableWindow(1);
		GetDlgItem(IDC_BUTTON_AVI_OPEN)->EnableWindow(1);
		GetDlgItem(IDC_BUTTON_YUV_OPEN)->EnableWindow(1);
		GetDlgItem(IDC_BUTTON_FILE_OPEN)->EnableWindow(1);
		GetDlgItem(IDC_BUTTON_YCbCr_OPEN)->EnableWindow(1);
		// Cam
		GetDlgItem(IDC_BUTTON_CAM_STOP)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_CAM_CAPTURE)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_CAM_AVISAVE)->EnableWindow(0); // MP4 �߰�
		// File
		GetDlgItem(IDC_BUTTON_FILE_RUN)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_FILE_CAPTURE)->EnableWindow(0);
		// MP4
		GetDlgItem(IDC_BUTTON_AVIFORM_SAVE2)->EnableWindow(0); //MP4 �߰�
		GetDlgItem(IDC_STATIC_BB_BDM_M_P2)->EnableWindow(0);
		GetDlgItem(IDC_SLIDER_MP4_SAVE_COMP_LEVEL)->EnableWindow(0);
		GetDlgItem(IDC_EDIT_MP4_SAVE_COMP_LEVEL)->EnableWindow(0);
		// Avi
		GetDlgItem(IDC_BUTTON_AVI_RUN)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_AVI_PAUSE)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_YUV_SAVE)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_AVI_STOP)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_VIDEO_CAPTURE)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_AVIFORM_SAVE)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_YCbCr_SAVE)->EnableWindow(0);

		CFileDialog fileSave(FALSE, "avi", NULL, OFN_FILEMUSTEXIST |
			OFN_PATHMUSTEXIST | OFN_EXPLORER,
			"AVI File(*.avi)", NULL);

		char szFilter[] = "AVI Files(*.avi)|*.avi";

		CString strSaveFileName;
		fileSave.m_ofn.lpstrFilter = szFilter;
		if (IDOK == fileSave.DoModal()) {
			strSaveFileName = fileSave.GetPathName();
			MoveFile("avitmp.avi", strSaveFileName);
		}
		else {
			DeleteFile("avitmp.avi");
		}

		GetDlgItem(IDC_BUTTON_AVIFORM_SAVE)->SetWindowText(".avi Save");

		Memo_Write("Video Save end");//����

		VideoOut.release();

		// clean ifmt_ctx for processing a new file (if not, cannot process a new file)
		if (ifmt_ctx) {
			for (int i = 0; i < ifmt_ctx->nb_streams; i++)
				avcodec_close(ifmt_ctx->streams[i]->codec);
			avformat_close_input(&ifmt_ctx);
		}

		mp4_found1 = false;
		mp4_found2 = false;
		avi_found1 = false;
		avi_found2 = false;
		yuv_found1 = false;
		yuv_found2 = false;
		ycbcr_found1 = false;
		ycbcr_found2 = false;
	}
}

void CVS2022_DefaultDlg::OnBnClickedButtonMP4Save()
{
	GetDlgItem(IDC_BUTTON_AVIFORM_SAVE2)->SetWindowText("Save Stop"); // MP4 SAVE �� ��ưǥ�� 
	Memo_Write("Video Save Start");
	GetDlgItem(IDC_BUTTON_AVIFORM_SAVE2)->EnableWindow(0);
	GetDlgItem(IDC_BUTTON_AVIFORM_SAVE)->EnableWindow(0);
	GetDlgItem(IDC_BUTTON_YCbCr_SAVE)->EnableWindow(0);
	GetDlgItem(IDC_BUTTON_YUV_SAVE)->EnableWindow(0);
	GetDlgItem(IDC_EDIT_SAVE_FPS)->EnableWindow(0);
	GetDlgItem(IDC_STATIC_BB_BDM_M_P2)->EnableWindow(0);
	GetDlgItem(IDC_SLIDER_MP4_SAVE_COMP_LEVEL)->EnableWindow(0);
	GetDlgItem(IDC_EDIT_MP4_SAVE_COMP_LEVEL)->EnableWindow(0);

	if (m_pthread != NULL)
	{
		GetDlgItem(IDC_BUTTON_AVIFORM_SAVE2)->EnableWindow(1);
	}


	mp4saveflag = 1;
}

void CVS2022_DefaultDlg::Mp4SaveProc()
{
	if (mp4_save == FALSE) {
		mp4_save = TRUE;

		if (m_run_mode == 6) {
			capture.read(SaveImage);  // get a frame 

			m_width = SaveImage.cols;   // m_chech_avisave�� üũ���� �ʴ´ٸ� ������ ���� ���̰� ����.
			m_height = SaveImage.rows; // üũ�� �� ��� ������ ���Ͽ� ó�� ��, �� ������ ���� ���� �ȴ�.

		}

		else {
			if (m_check_sidebyside == FALSE) {
				UpdateData(TRUE);
				m_height = atoi(m_edit_Video_height);
				m_width = atoi(m_edit_Video_width);
				UpdateData(FALSE);
			}
			else {
				UpdateData(TRUE);
				m_height = atoi(m_edit_Video_height);
				m_width = atoi(m_edit_Video_width) * 2;
				UpdateData(FALSE);
			}
		}

		UpdateData(TRUE);
		save_fps = atoi(m_edit_save_fps);
		UpdateData(FALSE);

		// FFMPEG: save audio and video (added 2022.07.22)
		ret = open_output_file(sfilename, mp4_save_compression_level, m_check_sidebyside, m_check_upanddown);
		if (ret < 0) {
			Memo_Write("Could not open output file!");
			if (!ifmt_ctx) {
				Memo_Write("Please press STOP and MP4/AVI OPEN");
				GetDlgItem(IDC_BUTTON_AVI_STOP)->EnableWindow(1);
				return;
			}
			else {
				for (int i = 0; i < ifmt_ctx->nb_streams; i++) {
					avcodec_close(ifmt_ctx->streams[i]->codec);
					if (ofmt_ctx && ofmt_ctx->nb_streams > i && ofmt_ctx->streams[i] && ofmt_ctx->streams[i]->codec)
						avcodec_close(ofmt_ctx->streams[i]->codec);
				}
				avformat_close_input(&ifmt_ctx);
			}
			if (ofmt_ctx && !(ofmt_ctx->oformat->flags & AVFMT_NOFILE))
				avio_closep(&ofmt_ctx->pb);
			if (!ofmt_ctx)
				avformat_free_context(ofmt_ctx);
			if (ret < 0 && ret != AVERROR_EOF)
				Memo_Write("Error occurred!");
			if (!avframe)
				av_frame_free(&avframe);
			if (!pkt)
				av_packet_free(&pkt);
			return;
		}



		m_bAvi_Save_Stop = FALSE; // SAVE STOP�� ������ �������� STOP��ư�� Ȱ��ȭ ���� �ʴ´�. 

		if (m_bAviPause == TRUE) {
			GetDlgItem(IDC_BUTTON_AVI_PAUSE)->SetWindowText("Pause");
			Memo_Write("Resume");
			m_bAviPause = FALSE;
		}
		else;
	}
	else
	{
		m_bAviStop = TRUE;
		m_bAvi_Save_Stop = TRUE;
		mp4_save = FALSE;
		// stop processing after saving
		// reset the button states
		// open
		GetDlgItem(IDC_BUTTON_CAM_START)->EnableWindow(1);
		GetDlgItem(IDC_BUTTON_AVI_OPEN)->EnableWindow(1);
		GetDlgItem(IDC_BUTTON_YUV_OPEN)->EnableWindow(1);
		GetDlgItem(IDC_BUTTON_FILE_OPEN)->EnableWindow(1);
		GetDlgItem(IDC_BUTTON_YCbCr_OPEN)->EnableWindow(1);
		// Cam
		GetDlgItem(IDC_BUTTON_CAM_STOP)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_CAM_CAPTURE)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_CAM_AVISAVE)->EnableWindow(0); // MP4 �߰�
		// File
		GetDlgItem(IDC_BUTTON_FILE_RUN)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_FILE_CAPTURE)->EnableWindow(0);
		// MP4
		GetDlgItem(IDC_BUTTON_AVIFORM_SAVE2)->EnableWindow(0); //MP4 �߰�
		GetDlgItem(IDC_STATIC_BB_BDM_M_P2)->EnableWindow(0);
		GetDlgItem(IDC_SLIDER_MP4_SAVE_COMP_LEVEL)->EnableWindow(0);
		GetDlgItem(IDC_EDIT_MP4_SAVE_COMP_LEVEL)->EnableWindow(0);
		// Avi
		GetDlgItem(IDC_BUTTON_AVI_RUN)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_AVI_PAUSE)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_YUV_SAVE)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_AVI_STOP)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_VIDEO_CAPTURE)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_AVIFORM_SAVE)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_YCbCr_SAVE)->EnableWindow(0);


		//m_pthread->SuspendThread();
		// FFMPEG save video and audio, added 2022.07.22
		if (ifmt_ctx && ofmt_ctx) {
			for (int j = 0; j < ifmt_ctx->nb_streams; j++) {
				ret = flush_encoder(j);
				if (ret < 0) {
					Memo_Write("Failed to flush encoder!");
					for (int i = 0; i < ifmt_ctx->nb_streams; i++) {
						avcodec_close(ifmt_ctx->streams[i]->codec);
						if (ofmt_ctx && ofmt_ctx->nb_streams > i && ofmt_ctx->streams[i] && ofmt_ctx->streams[i]->codec)
							avcodec_close(ofmt_ctx->streams[i]->codec);
					}
					avformat_close_input(&ifmt_ctx);
					if (ofmt_ctx && !(ofmt_ctx->oformat->flags & AVFMT_NOFILE))
						avio_closep(&ofmt_ctx->pb);
					avformat_free_context(ofmt_ctx);
					if (ret < 0 && ret != AVERROR_EOF)
						Memo_Write("Error occurred!");
					av_frame_free(&avframe);
					av_packet_free(&pkt);
				}
			}
			av_write_trailer(ofmt_ctx);
			for (int i = 0; i < ifmt_ctx->nb_streams; i++) {
				avcodec_close(ifmt_ctx->streams[i]->codec);
				if (ofmt_ctx && ofmt_ctx->nb_streams > i && ofmt_ctx->streams[i] && ofmt_ctx->streams[i]->codec)
					avcodec_close(ofmt_ctx->streams[i]->codec);
			}
			avformat_close_input(&ifmt_ctx);
			if (ofmt_ctx && !(ofmt_ctx->oformat->flags & AVFMT_NOFILE))
				avio_closep(&ofmt_ctx->pb);
			avformat_free_context(ofmt_ctx);
			if (ret < 0 && ret != AVERROR_EOF)
				Memo_Write("Error occurred!");
			av_frame_free(&avframe);
			av_packet_free(&pkt);
			sws_freeContext(sws_ctx_bgr_yuv);

			// ask user to enter the file name and move the temporary file
			CFileDialog fileSave(FALSE, "MP4", NULL, OFN_FILEMUSTEXIST | //���� ����/���� ��ȭ���� 
				OFN_PATHMUSTEXIST | OFN_EXPLORER,
				"MP4 File(*.mp4)", NULL);

			char szFilter[] = "MP4 Files(*mp4)|*.mp4"; //SAVE STOP�� ������ ������ ������ Ȯ����.

			CString strSaveFileName;
			fileSave.m_ofn.lpstrFilter = szFilter;
			int nRet = fileSave.DoModal();
			if (nRet == IDOK) {
				strSaveFileName = fileSave.GetPathName();
				MoveFile(sfilename, strSaveFileName);
			}
			else {
				DeleteFile(sfilename);
			}

			GetDlgItem(IDC_BUTTON_AVIFORM_SAVE2)->SetWindowText(".mp4 Save");

			Memo_Write("Video Save end");

		}
		else
		{
			if (!ifmt_ctx)
			{
				Memo_Write("video save failed, ifmt_ctx is null");
			}
			else if (!ofmt_ctx)
			{
				Memo_Write("video save failed, ofmt_ctx is null");
			}
		}
		mp4_found1 = false;
		mp4_found2 = false;
		avi_found1 = false;
		avi_found2 = false;
		yuv_found1 = false;
		yuv_found2 = false;
		ycbcr_found1 = false;
		ycbcr_found2 = false;
	}
	mp4saveflag = 0;
}

void CVS2022_DefaultDlg::OnButton_YuvSave()
{

	yuv_save = TRUE;

	if (!m_bYUVSave) {
		if (dialogInit == FALSE) {
			m_bYUVSave = TRUE;

			CString strSaveFileName = "yuv_temp.YUV";

			CFileFind pFind;
			BOOL bRet = pFind.FindFile(strSaveFileName);
			if (bRet == TRUE)
			{
				DeleteFile(strSaveFileName);
				bRet = FALSE;
			}
			else;
			fopen_s(&m_fpAviSave, strSaveFileName, "wb+"); // file open
			if (m_fpAviSave == NULL) {
				Memo_Write("Failed to open file!");
				DeleteFile(strSaveFileName);
			}
			else;
			/*
			if (m_run_mode == 4) {
				//_fseeki64(m_fpYUV, 0, SEEK_CUR);
				if (_ftelli64(m_fpYUV) != 0) {
					//AfxMessageBox("rewind file failed");
					Memo_Write("Failed to rewind file!");
				}
				else;
			}
			else;
			*/

			GetDlgItem(IDC_BUTTON_YUV_SAVE)->SetWindowText("Save Stop");
			GetDlgItem(IDC_BUTTON_AVIFORM_SAVE2)->EnableWindow(0);// MP4 �߰�
			GetDlgItem(IDC_STATIC_BB_BDM_M_P2)->EnableWindow(0);
			GetDlgItem(IDC_SLIDER_MP4_SAVE_COMP_LEVEL)->EnableWindow(0);
			GetDlgItem(IDC_EDIT_MP4_SAVE_COMP_LEVEL)->EnableWindow(0);
			GetDlgItem(IDC_BUTTON_AVIFORM_SAVE)->EnableWindow(0);
			GetDlgItem(IDC_BUTTON_YUV_SAVE)->EnableWindow(0);
			GetDlgItem(IDC_BUTTON_YCbCr_SAVE)->EnableWindow(0);
			GetDlgItem(IDC_EDIT_SAVE_FPS)->EnableWindow(0);
			if (m_pthread != NULL)
			{
				GetDlgItem(IDC_BUTTON_YUV_SAVE)->EnableWindow(1);
			}

		}
		else;
	}
	else {
		GetDlgItem(IDC_BUTTON_YUV_SAVE)->SetWindowText(".yuv Save");
		m_bYUVSave = FALSE;
		Memo_Write("Save End");
		m_bAviStop = TRUE; // stop processing after saving

		// reset the button states
		// open
		GetDlgItem(IDC_BUTTON_CAM_START)->EnableWindow(1);
		GetDlgItem(IDC_BUTTON_AVI_OPEN)->EnableWindow(1);
		GetDlgItem(IDC_BUTTON_YUV_OPEN)->EnableWindow(1);
		GetDlgItem(IDC_BUTTON_FILE_OPEN)->EnableWindow(1);
		GetDlgItem(IDC_BUTTON_YCbCr_OPEN)->EnableWindow(1);
		// Cam
		GetDlgItem(IDC_BUTTON_CAM_STOP)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_CAM_CAPTURE)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_CAM_AVISAVE)->EnableWindow(0); // MP4 �߰�
		// File
		GetDlgItem(IDC_BUTTON_FILE_RUN)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_FILE_CAPTURE)->EnableWindow(0);
		// MP4
		GetDlgItem(IDC_BUTTON_AVIFORM_SAVE2)->EnableWindow(0); //MP4 �߰�
		GetDlgItem(IDC_STATIC_BB_BDM_M_P2)->EnableWindow(0);
		GetDlgItem(IDC_SLIDER_MP4_SAVE_COMP_LEVEL)->EnableWindow(0);
		GetDlgItem(IDC_EDIT_MP4_SAVE_COMP_LEVEL)->EnableWindow(0);
		// Avi
		GetDlgItem(IDC_BUTTON_AVI_RUN)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_AVI_PAUSE)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_YUV_SAVE)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_AVI_STOP)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_VIDEO_CAPTURE)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_AVIFORM_SAVE)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_YCbCr_SAVE)->EnableWindow(0);

		fclose(m_fpAviSave);

		CFileDialog fileSave(FALSE, "yuv", NULL, OFN_FILEMUSTEXIST |
			OFN_PATHMUSTEXIST | OFN_EXPLORER,
			"YUV File(*.yuv)|*.yuv;|All Files(*.*)|*.*||", NULL);

		char szFilter[] = "YUV Files(*.yuv)|*.yuv";

		CString strSaveFileName;
		fileSave.m_ofn.lpstrFilter = szFilter;
		if (IDOK == fileSave.DoModal()) {
			strSaveFileName = fileSave.GetPathName();
			MoveFile("yuv_temp.YUV", strSaveFileName);
		}
		else {
			DeleteFile("yuv_temp.YUV");
		}

		// clean ifmt_ctx for processing a new file (if not, cannot process a new file)
		if (ifmt_ctx) {
			for (int i = 0; i < ifmt_ctx->nb_streams; i++)
				avcodec_close(ifmt_ctx->streams[i]->codec);
			avformat_close_input(&ifmt_ctx);
		}

		mp4_found1 = false;
		mp4_found2 = false;
		avi_found1 = false;
		avi_found2 = false;
		yuv_found1 = false;
		yuv_found2 = false;
		ycbcr_found1 = false;
		ycbcr_found2 = false;
	}
}

void CVS2022_DefaultDlg::OnButton_YcbcrSave()
{
	ycbcr_save = TRUE;

	if (!m_bYCbCrSave) {
		if (dialogInit == FALSE) {
			m_bYCbCrSave = TRUE;

			CString strSaveFileName = "ycbcr_temp.YCbCr";

			CFileFind pFind;
			BOOL bRet = pFind.FindFile(strSaveFileName);
			if (bRet == TRUE)
			{
				DeleteFile(strSaveFileName);
				bRet = FALSE;
			}
			else;
			fopen_s(&m_fpAviSave, strSaveFileName, "wb+"); // file open
			if (m_fpAviSave == NULL) {
				//AfxMessageBox("file open failed");
				Memo_Write("Failed to open file!");
				DeleteFile(strSaveFileName);
			}
			else;
			/*if (m_run_mode == 5) {
				_fseeki64(m_fpYCbCr, 0, SEEK_SET);
				if (_ftelli64(m_fpYCbCr) != 0) {
					//AfxMessageBox("rewind file failed");
					Memo_Write("Failed to rewind file!");
				}
				else
			}
			else;*/
			GetDlgItem(IDC_BUTTON_YCbCr_SAVE)->SetWindowText("Save Stop");
			GetDlgItem(IDC_BUTTON_AVIFORM_SAVE2)->EnableWindow(0); // MP4 �߰�
			GetDlgItem(IDC_STATIC_BB_BDM_M_P2)->EnableWindow(0);
			GetDlgItem(IDC_SLIDER_MP4_SAVE_COMP_LEVEL)->EnableWindow(0);
			GetDlgItem(IDC_EDIT_MP4_SAVE_COMP_LEVEL)->EnableWindow(0);
			GetDlgItem(IDC_BUTTON_AVIFORM_SAVE)->EnableWindow(0);
			GetDlgItem(IDC_BUTTON_YUV_SAVE)->EnableWindow(0);
			GetDlgItem(IDC_BUTTON_YCbCr_SAVE)->EnableWindow(0);
			GetDlgItem(IDC_EDIT_SAVE_FPS)->EnableWindow(0);
			if (m_pthread != NULL)
			{
				GetDlgItem(IDC_BUTTON_YCbCr_SAVE)->EnableWindow(1);
			}
		}
		else;
	}
	else {
		//fclose(m_fpAviSave);
		GetDlgItem(IDC_BUTTON_YCbCr_SAVE)->SetWindowText(".ycbcr Save");
		m_bYCbCrSave = FALSE;
		Memo_Write("Save End");
		m_bAviStop = TRUE; // stop processing after saving

		// reset the button states
		// open
		GetDlgItem(IDC_BUTTON_CAM_START)->EnableWindow(1);
		GetDlgItem(IDC_BUTTON_AVI_OPEN)->EnableWindow(1);
		GetDlgItem(IDC_BUTTON_YUV_OPEN)->EnableWindow(1);
		GetDlgItem(IDC_BUTTON_FILE_OPEN)->EnableWindow(1);
		GetDlgItem(IDC_BUTTON_YCbCr_OPEN)->EnableWindow(1);
		// Cam
		GetDlgItem(IDC_BUTTON_CAM_STOP)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_CAM_CAPTURE)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_CAM_AVISAVE)->EnableWindow(0); // MP4 �߰�
		// File
		GetDlgItem(IDC_BUTTON_FILE_RUN)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_FILE_CAPTURE)->EnableWindow(0);
		// MP4
		GetDlgItem(IDC_BUTTON_AVIFORM_SAVE2)->EnableWindow(0); //MP4 �߰�
		GetDlgItem(IDC_STATIC_BB_BDM_M_P2)->EnableWindow(0);
		GetDlgItem(IDC_SLIDER_MP4_SAVE_COMP_LEVEL)->EnableWindow(0);
		GetDlgItem(IDC_EDIT_MP4_SAVE_COMP_LEVEL)->EnableWindow(0);
		// Avi
		GetDlgItem(IDC_BUTTON_AVI_RUN)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_AVI_PAUSE)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_YUV_SAVE)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_AVI_STOP)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_VIDEO_CAPTURE)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_AVIFORM_SAVE)->EnableWindow(0);
		GetDlgItem(IDC_BUTTON_YCbCr_SAVE)->EnableWindow(0);

		fclose(m_fpAviSave);

		CFileDialog fileSave(FALSE, "ycbcr", NULL, OFN_FILEMUSTEXIST |
			OFN_PATHMUSTEXIST | OFN_EXPLORER,
			"YCbCr File(*.YCbCr)|*.ycbcr;|All Files(*.*)|*.*||", NULL);

		char szFilter[] = "YCbCr Files(*.ycbcr)|*.ycbcr";

		CString strSaveFileName;
		fileSave.m_ofn.lpstrFilter = szFilter;
		if (IDOK == fileSave.DoModal()) {
			strSaveFileName = fileSave.GetPathName();
			MoveFile("ycbcr_temp.YCbCr", strSaveFileName);
		}
		else {
			DeleteFile("ycbcr_temp.YCbCr");
		}

		// clean ifmt_ctx for processing a new file (if not, cannot process a new file)
		if (ifmt_ctx) {
			for (int i = 0; i < ifmt_ctx->nb_streams; i++)
				avcodec_close(ifmt_ctx->streams[i]->codec);
			avformat_close_input(&ifmt_ctx);
		}

		mp4_found1 = false;
		mp4_found2 = false;
		avi_found1 = false;
		avi_found2 = false;
		yuv_found1 = false;
		yuv_found2 = false;
		ycbcr_found1 = false;
		ycbcr_found2 = false;
	}
}

//-----------------------------------------------------------------------------//
/////////////////////////////////////////////////////////////////////////////////



/////////////////////////////////////////////////////////////////////////////////
//save option------------------------------------------------------------------//
void CVS2022_DefaultDlg::OnCheck_SideBySide()
{
	m_check_sidebyside = !m_check_sidebyside;
	if (m_check_sidebyside == FALSE);
	else {
		Memo_Write("Input and Output video will be save together.");
		Memo_Write("Left : Input video");
		Memo_Write("Right : Output video");
		Memo_Write("============================");
		if (m_check_upanddownbutton.GetCheck() == BST_CHECKED)
		{
			m_check_upanddown = FALSE;
			m_check_upanddownbutton.SetCheck(BST_UNCHECKED);
		}
	}
}

void CVS2022_DefaultDlg::OnCheck_UpAndDown()
{
	m_check_upanddown = !m_check_upanddown;
	if (m_check_upanddown == FALSE);
	else {
		Memo_Write("Input and Output video will be save together.");
		Memo_Write("Up : input video");
		Memo_Write("Down : output video");
		Memo_Write("=============================================");
		if (m_check_sidebysidebutton.GetCheck() == BST_CHECKED)
		{
			m_check_sidebyside = FALSE;
			m_check_sidebysidebutton.SetCheck(BST_UNCHECKED);
		}
	}

}

void CVS2022_DefaultDlg::OnEdit_SaveFps()
{
	UpdateData(TRUE);
	fps = atoi(m_edit_save_fps);
	UpdateData(FALSE);
}

//control compression level for mp4
void CVS2022_DefaultDlg::OnNMCustomdrawSliderMp4SaveCompLevel(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMCUSTOMDRAW pNMCD = reinterpret_cast<LPNMCUSTOMDRAW>(pNMHDR);
	// TODO: Add your control notification handler code here
	*pResult = 0;
	mp4_save_compression_level = mp4_save_compression_level_slider.GetPos();
	UpdateData(FALSE);
}
//--------------------------------------------------------------save option End//
/////////////////////////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////////////////////////
//frame option-----------------------------------------------------------------//
void CVS2022_DefaultDlg::OnEdit_YuvWidth()
{
	UpdateData(TRUE);
	m_width = atoi(m_edit_Video_width);
	UpdateData(FALSE);
}

void CVS2022_DefaultDlg::OnEdit_YuvHeight()
{
	UpdateData(TRUE);
	m_height = atoi(m_edit_Video_height);
	UpdateData(FALSE);
}

void CVS2022_DefaultDlg::OnEdit_YuvFrame()
{
	UpdateData(TRUE);
	fps = atoi(m_edit_frame_rate);
	UpdateData(FALSE);
}
//-------------------------------------------------------------frame option End//
/////////////////////////////////////////////////////////////////////////////////



/////////////////////////////////////////////////////////////////////////////////
//other functions--------------------------------------------------------------//

//Video playing speed control button
void CVS2022_DefaultDlg::OnSlide_Delaycount(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMCUSTOMDRAW pNMCD = reinterpret_cast<LPNMCUSTOMDRAW>(pNMHDR);

	*pResult = 0;

	m_delay_count = m_slide_delay_count.GetPos();
	UpdateData(FALSE);
}

//repeat image processing 
void CVS2022_DefaultDlg::OnEdit_RepeatProcessing()
{
	UpdateData(TRUE);
	fps = atoi(m_repeat_processing);
	UpdateData(FALSE);
}

//init function (return to initial state)
void CVS2022_DefaultDlg::OnModeInit()
{
	m_pthread = NULL;
	dialogInit = TRUE;
	RedrawWindow();

	UpdateData(TRUE);
	m_edit_save_fps.Format("30");
	save_fps = atoi(m_edit_save_fps); // 초기 fps 30

	m_repeat_processing.Format("1");
	repeat_proc = atoi(m_repeat_processing); // 초기 proc 1
	UpdateData(FALSE);

	if (!SaveImage.empty()) SaveImage.release();
	//temp_SaveImage = Mat(640, 480, CV_8UC3);
	SaveImage = Mat(480, 640, CV_8UC3);

	// Cam
	GetDlgItem(IDC_BUTTON_CAM_START)->EnableWindow(0);
	GetDlgItem(IDC_BUTTON_CAM_STOP)->EnableWindow(0);
	GetDlgItem(IDC_BUTTON_CAM_CAPTURE)->EnableWindow(0);
	//GetDlgItem(IDC_BUTTON_CAM_YUVSAVE)->EnableWindow(0);
	GetDlgItem(IDC_BUTTON_CAM_AVISAVE)->EnableWindow(0);
	//GetDlgItem(IDC_BUTTON_CAM_YCbCrSAVE)->EnableWindow(0);

	// File
	GetDlgItem(IDC_BUTTON_FILE_RUN)->EnableWindow(0);
	GetDlgItem(IDC_BUTTON_FILE_CAPTURE)->EnableWindow(0);

	// Avi
	GetDlgItem(IDC_BUTTON_AVI_RUN)->EnableWindow(0);
	GetDlgItem(IDC_BUTTON_AVI_PAUSE)->EnableWindow(0);
	GetDlgItem(IDC_BUTTON_YUV_SAVE)->EnableWindow(0);
	GetDlgItem(IDC_BUTTON_AVI_STOP)->EnableWindow(0);
	GetDlgItem(IDC_BUTTON_VIDEO_CAPTURE)->EnableWindow(0);
	GetDlgItem(IDC_BUTTON_AVIFORM_SAVE)->EnableWindow(0);
	GetDlgItem(IDC_BUTTON_YCbCr_SAVE)->EnableWindow(0);

	//Etc Controls
	GetDlgItem(IDC_EDIT_YUV_HEIGHT)->EnableWindow(1);
	GetDlgItem(IDC_EDIT_YUV_WIDTH)->EnableWindow(1);
	GetDlgItem(IDC_EDIT_YUV_FRAME)->EnableWindow(1);

	GetDlgItem(IDC_RADIO_YUV444R)->EnableWindow(1);
	GetDlgItem(IDC_RADIO_YUV422R)->EnableWindow(1);
	GetDlgItem(IDC_RADIO_YUV420R)->EnableWindow(1);

	GetDlgItem(IDC_RADIO_YUV444W)->EnableWindow(1);
	GetDlgItem(IDC_RADIO_YUV422W)->EnableWindow(1);
	GetDlgItem(IDC_RADIO_YUV420W)->EnableWindow(1);

	GetDlgItem(IDC_CHECK_SIDEBYSIDE)->EnableWindow(1);
	GetDlgItem(IDC_CHECK_UPANDDOWN)->EnableWindow(1);

	GetDlgItem(IDC_EDIT_Repeat_Processing)->EnableWindow(0);
	GetDlgItem(IDC_EDIT_SAVE_FPS)->EnableWindow(0);

	m_run_mode = 0;

	avi_save = FALSE;
	mp4_save = FALSE;//����
	yuv_save = FALSE;
	ycbcr_save = FALSE; // ���� 20. 01. 13

	cam_mp4_save = FALSE;

	save_over = FALSE; // ���� 20. 01. 11

	frame = NULL;
	//capture = NULL;
	VideoOut.release();
	VideoOutPro.release();
	g_OnOff = TRUE;

	m_bAviPause = FALSE;
	GetDlgItem(IDC_BUTTON_AVI_PAUSE)->SetWindowText("Pause");

	m_bYUVSave = FALSE;
	m_bYCbCrSave = FALSE;

	m_bAvi_Save_Stop = FALSE;
	m_bCamStop = FALSE;


	mp4saveflag = 0;
	camstopflag = 0;
	cammp4flag = 0;
	avistopflag = 0;


	CWnd* pStatic = GetDlgItem(IDC_STATIC_VIEW);
	pStatic->SetWindowPos(NULL, 0, 0, 640, 480, SWP_SHOWWINDOW);

	pStatic = GetDlgItem(IDC_STATIC_VIEW2);
	pStatic->SetWindowPos(NULL, 645, 0, 640, 480, SWP_SHOWWINDOW);

	// Get Release File path ====================//
	TCHAR path[_MAX_PATH];
	GetModuleFileName(NULL, path, sizeof(path));

	m_ReleasePath = path;
	int k = m_ReleasePath.ReverseFind('\\');
	m_ReleasePath = m_ReleasePath.Left(k);



	UpdateData(FALSE);
	//-------------------------------------------------------------------------
}

//init algorithm button (Buttons that is not related to the algorithm should not be initialized, ex)save option)
void CVS2022_DefaultDlg::OnButton_default()
{
	m_radio_read = 0;
	m_radio_write = 0;

	//set delay
	m_slide_delay_count.SetRange(0, 5000);
	m_slide_delay_count.SetPos(0);

	// MP4 save
	mp4_save_compression_level_slider.SetRange(0, 128);
	mp4_save_compression_level_slider.SetPos(64);
	UpdateData(FALSE);
}

//Memo Function
void CVS2022_DefaultDlg::Memo_Write(CString string)
{
	s.Format(string);
	((CHistoryEdit*)GetDlgItem(IDC_EDIT_MEMO))->AppendString(s);
}

//-----------------------------------------------------------other functions End//
//////////////////////////////////////////////////////////////////////////////////



///////////////////////////////////////////////////////////////////////////////// 
//proc funtions----------------------------------------------------------------//

//Sub thread for proc
UINT ThreadProcessingAVI(LPVOID lParam)
{
	CVS2022_DefaultDlg* pDlg = (CVS2022_DefaultDlg*)AfxGetApp()->m_pMainWnd;

	CString s;
	int height = pDlg->m_height;
	int width = pDlg->m_width;
	int frame_length = height * width;
	//can't find frame_length for YUV, YCbCr format
	//allocate by default width and height

	int nFrame = 0;
	int i = 0;

	if (pDlg->m_run_mode == 4) {
		frameY = new BYTE[frame_length];
		frameU = new BYTE[frame_length];
		frameV = new BYTE[frame_length];
	}
	else if (pDlg->m_run_mode == 5) {
		frameY1 = new BYTE[frame_length];
		frameCb = new BYTE[frame_length];
		frameCr = new BYTE[frame_length];
	}
	else;

	while (1) {
		//mp4 save 준비 및 마무리를 mfc 메인 스레드에서 동작시킬 경우 변수 접근 오류로 프로그램이 간헐적으로 터지는 현상 발생
		//mp4 button 이벤트에서는 플래그 신호만 주고, 기능은 proc 스레드에서 동작하도록 하는 부분
		if (mp4saveflag)
		{
			pDlg->Mp4SaveProc();
		}
		if (camstopflag)
		{
			pDlg->CamStopProc();
		}
		if (cammp4flag)
		{
			pDlg->CamMp4SaveProc();
		}
		if (avistopflag)
		{
			pDlg->AviStopProc();
		}
		if ((pDlg->m_bAviStop == TRUE) || (pDlg->m_bCamStop == TRUE)) {
			break;
		}
		else;
		if (!(pDlg->m_bAviPause)) {
			// Still Mode �϶�
			if (pDlg->m_run_mode == 1) {
				if (ifmt_ctx && pDlg->cam_mp4_save) {
					// FFMPEG save video and audio, added 2022.07.25
					pkt = av_packet_alloc();
					if (!pkt) {
						((CHistoryEdit*)(pDlg->GetDlgItem(IDC_EDIT_MEMO)))->AppendString("Could not allocate packet!\r\n");
						break;
					}
					pkt->data = NULL;
					pkt->size = 0;

					ret = av_read_frame(ifmt_ctx, pkt);
					if (ret < 0) {
						((CHistoryEdit*)(pDlg->GetDlgItem(IDC_EDIT_MEMO)))->AppendString("Error reading input packet!\r\n");
						break;
					}
					stream_index = pkt->stream_index;
					type = ifmt_ctx->streams[pkt->stream_index]->codec->codec_type;
					avframe = av_frame_alloc();
					if (!avframe) {
						((CHistoryEdit*)(pDlg->GetDlgItem(IDC_EDIT_MEMO)))->AppendString("Failed to allocate new frame!\r\n");
						break;
					}
					av_packet_rescale_ts(pkt,
						ifmt_ctx->streams[stream_index]->time_base,
						ifmt_ctx->streams[stream_index]->codec->time_base);
					if (type == AVMEDIA_TYPE_AUDIO)
						ret = avcodec_decode_audio4(ifmt_ctx->streams[stream_index]->codec, avframe, &got_frame, pkt);
					else if (type == AVMEDIA_TYPE_VIDEO)
						ret = avcodec_decode_video2(ifmt_ctx->streams[stream_index]->codec, avframe, &got_frame, pkt);
					else;
					if (ret < 0) {
						av_frame_free(&avframe);
						((CHistoryEdit*)(pDlg->GetDlgItem(IDC_EDIT_MEMO)))->AppendString("Failed to decode!\r\n");
						break;
					}

					if (got_frame) {
						if (stream_index == video_index) {
							sws_scale(sws_ctx, (uint8_t const* const*)avframe->data, avframe->linesize, 0, ifmt_ctx->streams[video_index]->codec->height, pFrameRGB->data, pFrameRGB->linesize);

							SaveImage = Mat(avframe->height, avframe->width, CV_8UC3, pFrameRGB->data[0]);
							//Mat img(avframe->height, avframe->width, CV_8UC3, pFrameRGB->data[0]);

							//cap >> pDlg->m_SaveImage;
							//pDlg->m_SaveImage = img;
							//pDlg->p_SaveImage = pDlg->m_SaveImage;
							//SaveImage = pDlg->p_SaveImage;

							pDlg->PostMessage(UM_UPDATE);
							pDlg->Processing();
							pDlg->m_frame_num++;

							if (pDlg->cam_mp4_save && encode_video) {
								encode_video = !write_video_frame(oc, &video_st);
							}
						}
						else if (stream_index == audio_index) {
							if (pDlg->cam_mp4_save && encode_audio) {
								encode_audio = !write_audio_frame(oc, &audio_st, avframe);
							}
						}
					}
					else {
						av_frame_free(&avframe);
					}
					av_packet_free(&pkt);
				}
				else {
					pkt = av_packet_alloc();
					if (!pkt) {
						((CHistoryEdit*)(pDlg->GetDlgItem(IDC_EDIT_MEMO)))->AppendString("Could not allocate packet!\r\n");
						break;
					}
					pkt->data = NULL;
					pkt->size = 0;

					ret = av_read_frame(ifmt_ctx, pkt);
					if (ret < 0) {
						((CHistoryEdit*)(pDlg->GetDlgItem(IDC_EDIT_MEMO)))->AppendString("Error reading input packet!\r\n");
						break;
					}
					stream_index = pkt->stream_index;
					type = ifmt_ctx->streams[pkt->stream_index]->codec->codec_type;
					avframe = av_frame_alloc();
					if (!avframe) {
						((CHistoryEdit*)(pDlg->GetDlgItem(IDC_EDIT_MEMO)))->AppendString("Failed to allocate new frame!\r\n");
						break;
					}
					av_packet_rescale_ts(pkt,
						ifmt_ctx->streams[stream_index]->time_base,
						ifmt_ctx->streams[stream_index]->codec->time_base);
					if (type == AVMEDIA_TYPE_AUDIO)
						ret = avcodec_decode_audio4(ifmt_ctx->streams[stream_index]->codec, avframe, &got_frame, pkt);
					else if (type == AVMEDIA_TYPE_VIDEO)
						ret = avcodec_decode_video2(ifmt_ctx->streams[stream_index]->codec, avframe, &got_frame, pkt);
					else;
					if (ret < 0) {
						av_frame_free(&avframe);
						((CHistoryEdit*)(pDlg->GetDlgItem(IDC_EDIT_MEMO)))->AppendString("Failed to decode!\r\n");
						break;
					}

					if (got_frame) {
						if (stream_index == video_index) {
							sws_scale(sws_ctx, (uint8_t const* const*)avframe->data, avframe->linesize, 0, ifmt_ctx->streams[video_index]->codec->height, pFrameRGB->data, pFrameRGB->linesize);
							cv::Mat img(avframe->height, avframe->width, CV_8UC3, pFrameRGB->data[0]);

							//cap >> pDlg->m_SaveImage;
							pDlg->m_SaveImage = img;
							pDlg->p_SaveImage = pDlg->m_SaveImage;
							SaveImage = pDlg->p_SaveImage;

							pDlg->PostMessage(UM_UPDATE);
							pDlg->Processing();
							pDlg->m_frame_num++;
						}
						else;
					}
					else {
						av_frame_free(&avframe);
					}
					av_packet_free(&pkt);
				}
			}
			else if (pDlg->m_run_mode == 2) {
				pDlg->PostMessage(UM_UPDATE);
				repeatprocendflag = FALSE;
				for (i = 1; i <= pDlg->repeat_proc; i++) {
					pDlg->Processing();
					pDlg->m_frame_num++;
				}

				pDlg->GetDlgItem(IDC_BUTTON_FILE_RUN)->EnableWindow(1);
				pDlg->m_repeat_processing.Format("1");
				pDlg->repeat_proc = atoi(pDlg->m_repeat_processing);
				pDlg->UpdateData(FALSE);
				repeatprocendflag = TRUE;
				break;
			}
			else if (pDlg->m_run_mode == 3) {
				pDlg->capture.read(SaveImage);  // get a frame 
				if (SaveImage.empty()) {
					if ((pDlg->m_bYUVSave == TRUE) || (pDlg->m_bYCbCrSave == TRUE)) fclose(pDlg->m_fpAviSave);
					else;
					break;
				}                    // always check     
				else;

				if (pDlg->m_bAvi_Save_Stop == TRUE) {
					VideoOut.release();
					//VideoOut = NULL;
				}
				else;

				pDlg->PostMessage(UM_UPDATE);
				pDlg->Processing();
				if (pDlg->m_frame_num == total_frame_count - 2)
					break;
				else
					pDlg->m_frame_num++;
			}
			else if (pDlg->m_run_mode == 4) {
				// ���� ������ ���� ���
				pDlg->m_frame_num = int(pDlg->m_pFrame_now / pDlg->m_YUVlength);

				if (pDlg->m_frame_num == pDlg->m_totalFrame) {
					_fseeki64(pDlg->m_fpYUV, 0, SEEK_SET); // ���������͸� 0���� �̵�
					pDlg->m_frame_num = 0;               // ������ ���� �ʱ�ȭ
					pDlg->m_pFrame_now = 0;
					pDlg->m_YUVlength = 0;

					((CHistoryEdit*)(pDlg->GetDlgItem(IDC_EDIT_MEMO)))->AppendString("Frame End\r\n");

					// YUV ���Ϸ� ���� ������ ��
					if (pDlg->m_bYUVSave == TRUE) {
						fclose(pDlg->m_fpYUV);
						fclose(pDlg->m_fpAviSave);
						break;
					}
					// YCbCr ���Ϸ� ���� ������ ��
					else if (pDlg->m_bYCbCrSave == TRUE) {
						fclose(pDlg->m_fpAviSave);
						break;
					}
					else;
					break;
				}
				else;
				// YUV ���� �б�
				//fread(������ġ, �о�� ũ�� ,�о�� ũ��, �о�� ��ġ) �о�� ũ�� �ΰ��� ���� ũ�⸸ŭ �ҷ���.
				fread(frameY, sizeof(BYTE), frame_length, pDlg->m_fpYUV);
				fread(frameU, sizeof(BYTE), frame_length, pDlg->m_fpYUV);
				fread(frameV, sizeof(BYTE), frame_length, pDlg->m_fpYUV);

				if (pDlg->m_bAvi_Save_Stop == TRUE) {
					VideoOut.release();
					//VideoOut = NULL;
				}
				else;

				// YUV ������ ���� ������ ����
				pDlg->m_pFrame_now = _ftelli64(pDlg->m_fpYUV);

				pDlg->PostMessage(UM_UPDATE);
				pDlg->Processing();
			}
			else if (pDlg->m_run_mode == 5) {
				// ���� ������ ���� ���
				pDlg->m_frame_num = int(pDlg->m_pFrame_now / pDlg->m_YCbCrlength);

				if (pDlg->m_frame_num == pDlg->m_totalFrame) {
					_fseeki64(pDlg->m_fpYCbCr, 0, SEEK_SET); // ���������͸� 0���� �̵�
					pDlg->m_frame_num = 0;               // ������ ���� �ʱ�ȭ
					pDlg->m_pFrame_now = 0;
					pDlg->m_YCbCrlength = 0;
					((CHistoryEdit*)(pDlg->GetDlgItem(IDC_EDIT_MEMO)))->AppendString("Frame End\r\n");

					// YUV ���Ϸ� ���� ������ ��
					if (pDlg->m_bYUVSave == TRUE) {
						fclose(pDlg->m_fpAviSave);
						break;
					}
					// YCbCr ���Ϸ� ���� ������ ��
					else if (pDlg->m_bYCbCrSave == TRUE) {
						fclose(pDlg->m_fpYCbCr);
						fclose(pDlg->m_fpAviSave);
						break;
					}
					else;
					break;
				}
				else;
				s.Format("%d", _ftelli64(pDlg->m_fpYCbCr));
				(pDlg->SetDlgItemTextA(IDC_EDIT1, s));


				// YCbCr ���� �б�
				fread(frameY1, sizeof(BYTE), frame_length, pDlg->m_fpYCbCr);
				fread(frameCb, sizeof(BYTE), frame_length, pDlg->m_fpYCbCr);
				fread(frameCr, sizeof(BYTE), frame_length, pDlg->m_fpYCbCr);

				// YCbCr ������ ���� ������ ����
				pDlg->m_pFrame_now = _ftelli64(pDlg->m_fpYCbCr);
				pDlg->PostMessage(UM_UPDATE);
				pDlg->Processing();
			}
			else if (pDlg->m_run_mode == 6) {
				if (ifmt_ctx && ofmt_ctx && pDlg->mp4_save) {
					// mp4_save is required, because this portion of code will still be called after clicking "Save End"
					// FFMPEG save video and audio, added 2022.07.25
					pkt = av_packet_alloc();
					if (!pkt) {
						((CHistoryEdit*)(pDlg->GetDlgItem(IDC_EDIT_MEMO)))->AppendString("Could not allocate packet!\r\n");
						break;
					}
					pkt->data = NULL;
					pkt->size = 0;

					ret = av_read_frame(ifmt_ctx, pkt);
					if (ret < 0) {
						((CHistoryEdit*)(pDlg->GetDlgItem(IDC_EDIT_MEMO)))->AppendString("Error reading input packet!\r\n");
						break;
					}
					stream_index = pkt->stream_index;
					type = ifmt_ctx->streams[pkt->stream_index]->codec->codec_type;
					avframe = av_frame_alloc();
					if (!avframe) {
						((CHistoryEdit*)(pDlg->GetDlgItem(IDC_EDIT_MEMO)))->AppendString("Failed to allocate new frame!\r\n");
						break;

					}
					av_packet_rescale_ts(pkt,
						ifmt_ctx->streams[stream_index]->time_base,
						ifmt_ctx->streams[stream_index]->codec->time_base);
					if (type == AVMEDIA_TYPE_AUDIO) {
						ret = avcodec_decode_audio4(ifmt_ctx->streams[stream_index]->codec, avframe, &got_frame, pkt);
					}
					else if (type == AVMEDIA_TYPE_VIDEO) {
						ret = avcodec_decode_video2(ifmt_ctx->streams[stream_index]->codec, avframe, &got_frame, pkt);
					}
					else;
					if (ret < 0) {
						av_frame_free(&avframe);
						((CHistoryEdit*)(pDlg->GetDlgItem(IDC_EDIT_MEMO)))->AppendString("Failed to decode!\r\n");
						break;
					}



					if (got_frame) {
						if (stream_index == video_index) {
							pDlg->capture.read(SaveImage);
							//SaveImage = avframe_to_cvmat(avframe);
							//pDlg->testcapture.read(SaveImage);// get a frame 
							if (SaveImage.empty()) {
								if ((pDlg->m_bYUVSave == TRUE) || (pDlg->m_bYCbCrSave == TRUE)) fclose(pDlg->m_fpAviSave);
								else;
								break;
							}                    // always check     
							else;

							if (pDlg->m_bAvi_Save_Stop == TRUE) {
								VideoOut.release();
								//VideoOut = NULL;
							}
							else;

							pDlg->PostMessage(UM_UPDATE);
							pDlg->Processing();
							//저장 processing


							if (pDlg->m_frame_num == total_frame_count - 2)
								break;
							else
								pDlg->m_frame_num++;

							const int stride[] = { mresultImg.step[0] };
							if (avframe) // for preventing "Access Violation"
							{
								if (pDlg->m_check_sidebyside == TRUE)
								{
									av_image_alloc(avframe->data, avframe->linesize, avframe->width * 2, avframe->height, AV_PIX_FMT_YUV420P, 24);
									avframe->width = avframe->width * 2;
								}
								else if (pDlg->m_check_upanddown == TRUE)
								{
									av_image_alloc(avframe->data, avframe->linesize, avframe->width, avframe->height * 2, AV_PIX_FMT_YUV420P, 24);
									avframe->height = avframe->height * 2;
								}
								//mresultImg = Mat(540, 1920, CV_8UC3);
								sws_scale(sws_ctx_bgr_yuv, &mresultImg.data, stride, 0, mresultImg.rows, avframe->data, avframe->linesize);


							}
						}
						if (avframe) { // for preventing "Access Violation"
							if (stream_index == video_index)
								avframe->pts = av_frame_get_best_effort_timestamp(avframe) - temp_video_pts;
							else
								avframe->pts = av_frame_get_best_effort_timestamp(avframe) - temp_audio_pts;

							ret = encode_write_frame(avframe, stream_index, NULL);
							av_frame_free(&avframe);
							if (ret < 0) {
								((CHistoryEdit*)(pDlg->GetDlgItem(IDC_EDIT_MEMO)))->AppendString("Error muxing video packet!\r\n");
								break;
							}
						}
					}
					else {
						av_frame_free(&avframe);
					}
					av_packet_free(&pkt);
				}
				else {
					pkt = av_packet_alloc();
					if (!pkt) {
						((CHistoryEdit*)(pDlg->GetDlgItem(IDC_EDIT_MEMO)))->AppendString("Could not allocate packet!\r\n");
						break;
					}
					pkt->data = NULL;
					pkt->size = 0;

					ret = av_read_frame(ifmt_ctx, pkt);
					if (ret < 0) {
						((CHistoryEdit*)(pDlg->GetDlgItem(IDC_EDIT_MEMO)))->AppendString("Error reading input packet!\r\n");
						break;
					}
					stream_index = pkt->stream_index;
					type = ifmt_ctx->streams[pkt->stream_index]->codec->codec_type;
					avframe = av_frame_alloc();
					if (!avframe) {
						((CHistoryEdit*)(pDlg->GetDlgItem(IDC_EDIT_MEMO)))->AppendString("Failed to allocate new frame!\r\n");
						break;

					}
					av_packet_rescale_ts(pkt,
						ifmt_ctx->streams[stream_index]->time_base,
						ifmt_ctx->streams[stream_index]->codec->time_base);

					if (type == AVMEDIA_TYPE_AUDIO)
						ret = avcodec_decode_audio4(ifmt_ctx->streams[stream_index]->codec, avframe, &got_frame, pkt);

					else if (type == AVMEDIA_TYPE_VIDEO)
						ret = avcodec_decode_video2(ifmt_ctx->streams[stream_index]->codec, avframe, &got_frame, pkt);
					else;
					if (ret < 0) {
						av_frame_free(&avframe);
						((CHistoryEdit*)(pDlg->GetDlgItem(IDC_EDIT_MEMO)))->AppendString("Failed to decode!\r\n");
						break;
					}

					if (got_frame) {
						if (stream_index == video_index) {
							pDlg->capture.read(SaveImage);
							//SaveImage = avframe_to_cvmat(avframe);
							if (SaveImage.empty()) {
								if ((pDlg->m_bYUVSave == TRUE) || (pDlg->m_bYCbCrSave == TRUE)) fclose(pDlg->m_fpAviSave);
								else;
								break;
							}                    // always check     
							else;

							if (pDlg->m_bAvi_Save_Stop == TRUE) {
								VideoOut.release();
								//VideoOut = NULL;
							}
							else;

							pDlg->PostMessage(UM_UPDATE);
							pDlg->Processing();
							//재생 processing
							temp_video_pts = avframe->pts;
							if (pDlg->m_frame_num == total_frame_count - 2)
								break;
							else
								pDlg->m_frame_num++;
						}
						else
							temp_audio_pts = avframe->pts;
					}
					else {
						av_frame_free(&avframe);
					}
					av_packet_free(&pkt);
				}
			}
			else;
		}
		else {
			if (pDlg->m_capture_flag == TRUE) pDlg->Processing();
			else;
		}
		if (ProcessExitFlag == FALSE)
		{
			break;
		}
		else;
	}
	s.Format("thread end");

	((CHistoryEdit*)(pDlg->GetDlgItem(IDC_EDIT_MEMO)))->AppendString(s);

	if ((pDlg->m_run_mode == 3) || (pDlg->m_run_mode == 4) || (pDlg->m_run_mode == 5) || (pDlg->m_run_mode == 6)) {
		pDlg->AviStopProc();
	}
	else;

	pDlg->GetDlgItem(IDC_BUTTON_CAM_START)->EnableWindow(0);
	pDlg->GetDlgItem(IDC_BUTTON_CAM_TEST)->EnableWindow(1);
	pDlg->GetDlgItem(IDC_BUTTON_AVI_OPEN)->EnableWindow(1);
	pDlg->GetDlgItem(IDC_BUTTON_YUV_OPEN)->EnableWindow(1);
	pDlg->GetDlgItem(IDC_BUTTON_FILE_OPEN)->EnableWindow(1);
	pDlg->GetDlgItem(IDC_BUTTON_YCbCr_OPEN)->EnableWindow(1);


	if ((pDlg->m_run_mode == 1) || (pDlg->m_run_mode == 3) || (pDlg->m_run_mode == 6)) {
		if (pDlg->capture.isOpened())
			pDlg->capture.release();
	}
	else if (pDlg->m_run_mode == 4) {
		delete[] frameY;
		delete[] frameU;
		delete[] frameV;
	}
	else if (pDlg->m_run_mode == 5) {
		delete[] frameY1;
		delete[] frameCb;
		delete[] frameCr;
	}
	else;

	if (pDlg->m_run_mode != 2) pDlg->OnModeInit();

	mp4_found1 = false;
	mp4_found2 = false;
	avi_found1 = false;
	avi_found2 = false;
	yuv_found1 = false;
	yuv_found2 = false;
	ycbcr_found1 = false;
	ycbcr_found2 = false;

	return 0;
}

//proc funtion for drawing image, video, cam and processing algorithm
void CVS2022_DefaultDlg::Processing(void)
{
	CClientDC dc(this);
	CRect rtDisplay;

	// Display Frame Num. =======================//
	s.Format("frame : %d", m_frame_num);
	GetDlgItem(IDC_STATIC_FRAME_NUM)->SetWindowText(s);
	//============================================//
	register int i = 0, j = 0, x = 0, y = 0;

	register float y_mean_width = 0;
	register float y_mean_height = 0;
	register float y_mean_final = 0;

	BYTE* pimg = 0;
	int ws;

	// �ӵ� ���� ����
	_int64 freq = 0, start = 0, end = 0;
	QueryPerformanceFrequency((LARGE_INTEGER*)(&freq)); //���ļ��� ����
	QueryPerformanceCounter((LARGE_INTEGER*)&start);	//���� �ð��� ����

	// cam, avi, still �Է� �� ��, data from SaveImage
	if (m_run_mode != 4 && m_run_mode != 5)
	{
		if (m_run_mode == 1)// cvFlip(SaveImage);			//���Ϲ���
		{
		}
		else;
		pimg = (BYTE*)SaveImage.data;
		ws = SaveImage.cols * SaveImage.channels();
		m_width = SaveImage.cols;
		m_height = SaveImage.rows;

		if (m_run_mode == 3 || m_run_mode == 6) {
			s.Format("%d", m_height); GetDlgItem(IDC_EDIT_YUV_HEIGHT)->SetWindowText(s);
			s.Format("%d", m_width);  GetDlgItem(IDC_EDIT_YUV_WIDTH)->SetWindowText(s);
			s.Format("%d", fps);      GetDlgItem(IDC_EDIT_YUV_FRAME)->SetWindowText(s);
		}
		else {
			GetDlgItem(IDC_EDIT_YUV_HEIGHT)->EnableWindow(0);
			GetDlgItem(IDC_EDIT_YUV_WIDTH)->EnableWindow(0);
			GetDlgItem(IDC_EDIT_YUV_HEIGHT)->EnableWindow(0);
		}
	}
	else;


	// Color Converting ============================================================
	// Color converting �κ� ����======================================================================

	//��¿� ������ ����
	m_CImage.Create(m_width, m_height, 24);
	m_CDstImage.Create(m_width, m_height, 24);
	if (m_check_sidebyside == TRUE)
		m_CFullImage.Create(2 * m_width, m_height, 24);
	else if (m_check_upanddown == TRUE)
		m_CFullImage.Create(m_width, 2 * m_height, 24);
	else
		m_CFullImage.Create(2 * m_width, m_height, 24);

	CColorPixel24Ptr ptrCImg(m_CImage);
	CColorPixel24Ptr ptrCDstImg(m_CDstImage);
	CColorPixel24Ptr ptrCFullImg(m_CFullImage);

	// ������� ����.-----------------------------------------------------------------------------
	BYTE* imgYS = new BYTE[m_width * m_height];
	BYTE* imgCbS = new BYTE[m_width * m_height];
	BYTE* imgCrS = new BYTE[m_width * m_height];
	BYTE* imgRGB_3 = new BYTE[m_width * m_height];

	BYTE* imgYUVy = new BYTE[m_width * m_height];
	BYTE* imgYUVu = new BYTE[m_width * m_height];
	BYTE* imgYUVv = new BYTE[m_width * m_height];

	BYTE* imgYCbCry = new BYTE[m_width * m_height];
	BYTE* imgYCbCrcb = new BYTE[m_width * m_height];
	BYTE* imgYCbCrcr = new BYTE[m_width * m_height];

	BYTE* imgYCbCry_pr;
	BYTE* imgYCbCrcb_pr;
	BYTE* imgYCbCrcr_pr;
	BYTE* imgYUVy_pr;
	BYTE* imgYUVu_pr;
	BYTE* imgYUVv_pr;

	if (m_check_sidebyside == FALSE && m_check_upanddown == FALSE)
	{
		imgYCbCry_pr = new BYTE[m_width * m_height];
		imgYCbCrcb_pr = new BYTE[m_width * m_height];
		imgYCbCrcr_pr = new BYTE[m_width * m_height];

		imgYUVy_pr = new BYTE[m_width * m_height];
		imgYUVu_pr = new BYTE[m_width * m_height];
		imgYUVv_pr = new BYTE[m_width * m_height];
	}
	else
	{
		imgYCbCry_pr = new BYTE[2 * m_width * m_height];
		imgYCbCrcb_pr = new BYTE[2 * m_width * m_height];
		imgYCbCrcr_pr = new BYTE[2 * m_width * m_height];

		imgYUVy_pr = new BYTE[2 * m_width * m_height];
		imgYUVu_pr = new BYTE[2 * m_width * m_height];
		imgYUVv_pr = new BYTE[2 * m_width * m_height];
	}
	//-----------------------------------------------------------------------------


	// input color converting ===========================================================
	// run mode=5 (YCbCr) => YCbCr
	// run mode=4 (YUV) => YUV -> RGB -> YCbCr
	// other,              RGB -> YCbCr
	if (m_run_mode == 5)  // YCbCr �Է�
	{
		for (j = 0; j < m_height; j++) {
			for (i = 0; i < m_width; i++) {
				float fR, fG, fB;
				float fY1, fCb, fCr;

				fY1 = (float)frameY1[j * m_width + i];
				fCb = (float)frameCb[j * m_width + i];
				fCr = (float)frameCr[j * m_width + i];

				imgYS[j * m_width + i] = (BYTE)fY1;
				imgCbS[j * m_width + i] = (BYTE)fCb;
				imgCrS[j * m_width + i] = (BYTE)fCr;

				// ycbcr to rgb ----------------------------------------------------------------
				fR = floor(r_y1_lut[int(fY1)] + r_cb_lut[int(fCb)] + r_cr_lut[int(fCr)] + 0.5f);
				if (fR > 255.f) fR = 255.0f;
				else if (fR < 0.f) fR = 0.0f;
				else;

				fG = floor(g_y1_lut[int(fY1)] + g_cb_lut[int(fCb)] + g_cr_lut[int(fCr)] + 0.5f);
				if (fG > 255.f) fG = 255.0f;
				else if (fG < 0.f) fG = 0.0f;
				else;

				fB = floor(b_y1_lut[int(fY1)] + b_cb_lut[int(fCb)] + 0.5f);
				if (fB > 255.f) fB = 255.0f;
				else if (fB < 0.f) fB = 0.0f;
				else;

				// rgb to yuv, avi mode -------------------------------------------------
				float fY2, fU, fV;
				fY2 = floor(y2_r_lut[int(fR)] + y2_g_lut[int(fG)] + y2_b_lut[int(fB)] + 16.0f);
				if (fY2 > 255.f) fY2 = 255.0f;
				else if (fY2 < 0.f) fY2 = 0.0f;
				else;

				fU = floor(u_r_lut[int(fR)] + u_g_lut[int(fG)] + u_b_lut[int(fB)] + 128.0f);
				if (fU > 255.f) fU = 255.0f;
				else if (fU < 0.f) fU = 0.0f;
				else;

				fV = floor(v_r_lut[int(fR)] + v_g_lut[int(fG)] + v_b_lut[int(fB)] + 128.0f);
				if (fV > 255.f) fV = 255.0f;
				else if (fV < 0.f) fV = 0.0f;
				else;

				ptrCImg[j][i].R = BYTE(fR);
				ptrCImg[j][i].G = BYTE(fG);
				ptrCImg[j][i].B = BYTE(fB);

				//--- ��������� ó������ ���� ������ ��� ----//

				//------------------------------------------//

				y_mean_width += imgYS[j * m_width + i];

				// ycbcr save -----------------------------
				imgYCbCry[j * m_width + i] = BYTE(fY1);
				imgYCbCrcb[j * m_width + i] = BYTE(fCb);
				imgYCbCrcr[j * m_width + i] = BYTE(fCr);
				//위치 이동

				if (m_check_sidebyside == TRUE) {
					ptrCFullImg[j][i].R = (BYTE)fR;
					ptrCFullImg[j][i].G = (BYTE)fG;
					ptrCFullImg[j][i].B = (BYTE)fB;
					//sidebyside 일 경우 왼쪽 부분에 input을 미리 넣어놔야함.
					imgYCbCry_pr[j * 2 * m_width + i] = BYTE(fY1);
					imgYCbCrcb_pr[j * 2 * m_width + i] = BYTE(fCb);
					imgYCbCrcr_pr[j * 2 * m_width + i] = BYTE(fCr);
					imgYUVy_pr[j * 2 * m_width + i] = BYTE(fY2);
					imgYUVu_pr[j * 2 * m_width + i] = BYTE(fU);
					imgYUVv_pr[j * 2 * m_width + i] = BYTE(fV);
				}
				else if (m_check_upanddown == TRUE)
				{
					ptrCFullImg[j][i].R = (BYTE)fR;
					ptrCFullImg[j][i].G = (BYTE)fG;
					ptrCFullImg[j][i].B = (BYTE)fB;
					//upanddown 일 경우 위쪽 부분에 input을 미리 넣어놔야함.
					imgYCbCry_pr[j * m_width + i] = BYTE(fY1);
					imgYCbCrcb_pr[j * m_width + i] = BYTE(fCb);
					imgYCbCrcr_pr[j * m_width + i] = BYTE(fCr);
					imgYUVy_pr[j * m_width + i] = BYTE(fY2);
					imgYUVu_pr[j * m_width + i] = BYTE(fU);
					imgYUVv_pr[j * m_width + i] = BYTE(fV);
				}
				else {
					imgYCbCry_pr[j * m_width + i] = BYTE(fY1);
					imgYCbCrcb_pr[j * m_width + i] = BYTE(fCb);
					imgYCbCrcr_pr[j * m_width + i] = BYTE(fCr);
				}


				// --------------------------------------
			}
			y_mean_height += (float)y_mean_width / (float)m_width;
			y_mean_width = 0;
		}
	}
	else if (m_run_mode == 4) {  // YUV ���� �Է�
		for (j = 0; j < m_height; j++) {
			for (i = 0; i < m_width; i++) {
				float fY2, fU, fV;
				float fR, fG, fB;

				fY2 = (float)frameY[j * m_width + i];
				fU = (float)frameU[j * m_width + i];
				fV = (float)frameV[j * m_width + i];

				// yuv to rgb -----------------------------------------------
				fR = r_y2_lut[int(fY2)] + r_v_lut[int(fV)];
				if (fR > 255.f) fR = 255.0f;
				else if (fR < 0.f) fR = 0.0f;
				else;

				fG = g_y2_lut[int(fY2)] + g_u_lut[int(fU)] + g_v_lut[int(fV)];
				if (fG > 255.f) fG = 255.0f;
				else if (fG < 0.f) fG = 0.0f;
				else;

				fB = b_y2_lut[int(fY2)] + b_u_lut[int(fU)];
				if (fB > 255.f) fB = 255.0f;
				else if (fB < 0.f) fB = 0.0f;
				else;

				ptrCImg[j][i].R = BYTE(fR);
				ptrCImg[j][i].G = BYTE(fG);
				ptrCImg[j][i].B = BYTE(fB);

				//--- ��������� ó������ ���� ������ ��� ----//

				//------------------------------------------//

				// rgb to ycbcr -------------------------------------------------------------------------------

				imgYS[j * m_width + i] = (BYTE)(y1_r_lut[int(fR)] + y1_g_lut[int(fG)] + y1_b_lut[int(fB)]);
				imgCbS[j * m_width + i] = (BYTE)((cb_r_lut[int(fR)] + cb_g_lut[int(fG)] + cb_b_lut[int(fB)]) + 128.0f);
				imgCrS[j * m_width + i] = (BYTE)((cr_r_lut[int(fR)] + cr_g_lut[int(fG)] + cr_b_lut[int(fB)]) + 128.0f);

				y_mean_width += imgYS[j * m_width + i];
				imgRGB_3[j * m_width + i] = (BYTE)((fR + fG + fB) / 3);

				// yuv save -----------------------------
				imgYUVy[j * m_width + i] = BYTE(fY2);
				imgYUVu[j * m_width + i] = BYTE(fU);
				imgYUVv[j * m_width + i] = BYTE(fV);
				if (m_check_sidebyside == FALSE && m_check_upanddown == FALSE) {
					imgYUVy_pr[j * m_width + i] = BYTE(fY2);
					imgYUVu_pr[j * m_width + i] = BYTE(fU);
					imgYUVv_pr[j * m_width + i] = BYTE(fV);
				}
				else if (m_check_sidebyside == TRUE) {
					ptrCFullImg[j][i].R = BYTE(fR);
					ptrCFullImg[j][i].G = BYTE(fG);
					ptrCFullImg[j][i].B = BYTE(fB);
					imgYUVy_pr[j * 2 * m_width + i] = BYTE(fY2);
					imgYUVu_pr[j * 2 * m_width + i] = BYTE(fU);
					imgYUVv_pr[j * 2 * m_width + i] = BYTE(fV);
					imgYCbCry_pr[j * 2 * m_width + i] = imgYS[j * m_width + i];
					imgYCbCrcb_pr[j * 2 * m_width + i] = imgCbS[j * m_width + i];
					imgYCbCrcr_pr[j * 2 * m_width + i] = imgCrS[j * m_width + i];
				}
				else
				{
					ptrCFullImg[j][i].R = BYTE(fR);
					ptrCFullImg[j][i].G = BYTE(fG);
					ptrCFullImg[j][i].B = BYTE(fB);
					imgYUVy_pr[j * m_width + i] = BYTE(fY2);
					imgYUVu_pr[j * m_width + i] = BYTE(fU);
					imgYUVv_pr[j * m_width + i] = BYTE(fV);
					imgYCbCry_pr[j * m_width + i] = imgYS[j * m_width + i];
					imgYCbCrcb_pr[j * m_width + i] = imgCbS[j * m_width + i];
					imgYCbCrcr_pr[j * m_width + i] = imgCrS[j * m_width + i];
				}
				// -------------------------------------
			}
			y_mean_height += (float)y_mean_width / (float)m_width;
			y_mean_width = 0;
		}
	}
	else { 	// �׿� �Է� (cam, still, avi)
		for (j = 0; j < m_height; j++) {
			for (i = 0; i < m_width; i++) {
				float fY2, fU, fV;
				float fR, fG, fB;

				fR = ptrCImg[j][i].R = pimg[j * ws + i * 3 + 2];
				fG = ptrCImg[j][i].G = pimg[j * ws + i * 3 + 1];
				fB = ptrCImg[j][i].B = pimg[j * ws + i * 3 + 0];

				//--- ��������� ó������ ���� ������ ��� ----//
				if (m_check_sidebyside == TRUE || m_check_upanddown == TRUE) {
					fR = ptrCFullImg[j][i].R = pimg[j * ws + i * 3 + 2];
					fG = ptrCFullImg[j][i].G = pimg[j * ws + i * 3 + 1];
					fB = ptrCFullImg[j][i].B = pimg[j * ws + i * 3 + 0];
				}
				else;
				//------------------------------------------//

				// rgb to ycbcr -------------------------------------------------------------------------------
				imgYCbCry[j * m_width + i] = imgYS[j * m_width + i] = (BYTE)(y1_r_lut[int(fR)] + y1_g_lut[int(fG)] + y1_b_lut[int(fB)]);
				imgYCbCrcb[j * m_width + i] = imgCbS[j * m_width + i] = (BYTE)((cb_r_lut[int(fR)] + cb_g_lut[int(fG)] + cb_b_lut[int(fB)]) + 128.0f);
				imgYCbCrcr[j * m_width + i] = imgCrS[j * m_width + i] = (BYTE)((cr_r_lut[int(fR)] + cr_g_lut[int(fG)] + cr_b_lut[int(fB)]) + 128.0f);

				y_mean_width += imgYS[j * m_width + i];
				imgRGB_3[j * m_width + i] = (BYTE)((fR + fG + fB) / 3);

				// rgb to yuv, avi mode -------------------------------------------------
				fY2 = floor(y2_r_lut[int(fR)] + y2_g_lut[int(fG)] + y2_b_lut[int(fB)] + 16.0f);
				if (fY2 > 255.f) fY2 = 255.0f;
				else if (fY2 < 0.f) fY2 = 0.0f;
				else;

				fU = floor(u_r_lut[int(fR)] + u_g_lut[int(fG)] + u_b_lut[int(fB)] + 128.0f);
				if (fU > 255.f) fU = 255.0f;
				else if (fU < 0.f) fU = 0.0f;
				else;

				fV = floor(v_r_lut[int(fR)] + v_g_lut[int(fG)] + v_b_lut[int(fB)] + 128.0f);
				if (fV > 255.f) fV = 255.0f;
				else if (fV < 0.f) fV = 0.0f;
				else;

				imgYUVy[j * m_width + i] = BYTE(fY2);
				imgYUVu[j * m_width + i] = BYTE(fU);
				imgYUVv[j * m_width + i] = BYTE(fV);
				if (m_check_sidebyside == TRUE)
				{
					imgYCbCry_pr[j * 2 * m_width + i] = imgYCbCry[j * m_width + i];
					imgYCbCrcb_pr[j * 2 * m_width + i] = imgYCbCrcb[j * m_width + i];
					imgYCbCrcr_pr[j * 2 * m_width + i] = imgYCbCrcr[j * m_width + i];
					imgYUVy_pr[j * 2 * m_width + i] = imgYUVy[j * m_width + i];
					imgYUVu_pr[j * 2 * m_width + i] = imgYUVu[j * m_width + i];
					imgYUVv_pr[j * 2 * m_width + i] = imgYUVv[j * m_width + i];
				}
				else if (m_check_upanddown == TRUE)
				{
					imgYCbCry_pr[j * m_width + i] = imgYCbCry[j * m_width + i];
					imgYCbCrcb_pr[j * m_width + i] = imgYCbCrcb[j * m_width + i];
					imgYCbCrcr_pr[j * m_width + i] = imgYCbCrcr[j * m_width + i];
					imgYUVy_pr[j * m_width + i] = imgYUVy[j * m_width + i];
					imgYUVu_pr[j * m_width + i] = imgYUVu[j * m_width + i];
					imgYUVv_pr[j * m_width + i] = imgYUVv[j * m_width + i];
				}
			}
			y_mean_height += (float)y_mean_width / (float)m_width;
			y_mean_width = 0;
		}
	}

	// =================================================================================
	// Luminance Average
	UpdateData(TRUE);
	y_mean_final = y_mean_height / (float)m_height;
	y_mean_height = 0.0;
	m_Y_average = float(floor(y_mean_final * 100.0 + 0.5) / 100.0);
	UpdateData(FALSE);
	// =================================================================================
	UpdateData(TRUE);



	//********************************************//
	// ------------ Operation Body -------------- //
	//********************************************// 

	// === NHG-like Haze (testcode.py 3번째 방식) ===
// 전역/헤더 수정 없이, 내부 정적 상태만 사용
	{
		// 입력 YCbCr 버퍼: imgYS, imgCbS, imgCrS
		// 출력도 동일 버퍼에 되돌려 넣어, 아래 색변환/렌더 파이프라인 그대로 사용

		// ---- 파라미터 (testcode.py와 동일) ----, *** 가까이에 있는 안개 ***
		const double spatial_cutoff = 0.01;   // 공간 저역 (정규화 주파수)  -> 시그마로 근사
		const double temporal_cutoff = 0.01;  // 시간 저역 (정규화 주파수) -> EMA 알파로 근사
		const double spatial_scale_factor = 1.0;
		const double contrast = 0.8;
		const double gamma_v = 0.6;
		const float  A_atm = 200.0f;

		// 깊이 전송맵(시그모이드) 파라미터 (testcode.py 기본), *** 멀리 있는 안개 ***
		const float beta = 2.0f;
		const float k = 20.0f; 
		const float p0 = 0.7f; 

		static cv::Mat t_prev;                  // 이전 전송맵(시간 저역용)
		static bool    t_inited = false;
		static cv::Mat t_depth;                  // 깊이 전송맵 (고정)
		static bool    depth_inited = false;
		static cv::RNG rng(12345);

		// ---------- 1) 공간 저역 노이즈 생성 (가우시안 블러로 3D-FFT의 공간 LPF 근사) ----------
		cv::Mat noise(m_height, m_width, CV_32F);
		rng.fill(noise, cv::RNG::NORMAL, 0.0, 1.0);

		// spatial_cutoff(0~0.5)를 공간 시그마로 대강 매핑 (경험적)
		// cutoff가 작을수록 더 흐릿하게: sigma ≈ 0.5 / max(cutoff,1e-3)
		const double sigma = 0.5 / std::max(spatial_cutoff, 1e-3);
		cv::Mat noise_lp;
		cv::GaussianBlur(noise, noise_lp, cv::Size(0, 0), sigma, sigma, cv::BORDER_REFLECT101);

		// ---------- 2) 시간 저역 필터링 (EMA로 3D-FFT의 시간 LPF 근사) ----------
		// cutoff가 작을수록 천천히 변함: alpha를 작게. 대략 alpha ≈ temporal_cutoff*2 (0<alpha<=1)
		const float alpha = (float)(std::min)(1.0, std::max(0.01, temporal_cutoff * 2.0));
		if (!t_inited) {
			t_prev = noise_lp.clone();
			t_inited = true;
		}
		else {
			t_prev = (1.0f - alpha) * t_prev + alpha * noise_lp;
		}

		// ---------- 3) [0,1] 정규화 후 contrast/gamma 적용 ----------
		double vmin, vmax;
		cv::minMaxLoc(t_prev, &vmin, &vmax);
		cv::Mat t_norm = (t_prev - (float)vmin) / (float)((vmax - vmin) + 1e-12f);
		cv::Mat t_map;
		cv::pow((cv::min)(cv::max(t_norm * (float)contrast, 0.0f), 1.0f), (float)gamma_v, t_map); // clip & gamma

		// ---------- 4) 깊이 전송맵 t_depth(y) 생성 (아래=근거리, 위=원거리, 시그모이드) ----------
		if (!depth_inited) {
			t_depth.create(m_height, m_width, CV_32F);
			// p: 아래(1) -> 위(0)
			for (int y = 0; y < m_height; ++y) {
				float p = 1.0f - (m_height > 1 ? (float)y / (float)(m_height - 1) : 0.0f);
				// 시그모이드 깊이
				float s = 1.0f / (1.0f + std::exp(-k * (p - p0)));
				// 0~1 정규화 (수치안정 상수)
				// s_min≈1/(1+exp(k*p0)), s_max≈1/(1+exp(-k*(1-p0)))
				float s_min = 1.0f / (1.0f + std::exp(k * (p0)));          // p=0 근사
				float s_max = 1.0f / (1.0f + std::exp(-k * (1.0f - p0)));   // p=1 근사
				float depth = (s - s_min) / std::max(1e-6f, (s_max - s_min));
				float trow = std::exp(-beta * depth); // t_depth
				for (int x = 0; x < m_width; ++x) {
					t_depth.at<float>(y, x) = trow;
				}
			}
			depth_inited = true;
		}
		cv::Mat t_final = t_map.mul(t_depth); // 최종 전송맵

		// ---------- 5) Koschmieder: I = J*t + A*(1-t) ----------
		// 현재 버퍼는 YCbCr이므로, RGB로 역변환 -> 블렌딩 -> 다시 YCbCr로 저장
		// (아래 LUT는 파일 상단에 이미 존재하는 것들을 그대로 사용)
		for (int y = 0; y < m_height; ++y) {
			const float* tptr = t_final.ptr<float>(y);
			for (int x = 0; x < m_width; ++x) {
				BYTE BY1 = imgYS[y * m_width + x];
				BYTE BCb = imgCbS[y * m_width + x];
				BYTE BCr = imgCrS[y * m_width + x];

				// YCbCr -> RGB (파일에 있는 LUT 사용: r_y1_lut, r_cb_lut, r_cr_lut, g_*, b_*)
				float R = floor(r_y1_lut[int(BY1)] + r_cb_lut[int(BCb)] + r_cr_lut[int(BCr)] + 0.5f);
				float G = floor(g_y1_lut[int(BY1)] + g_cb_lut[int(BCb)] + g_cr_lut[int(BCr)] + 0.5f);
				float B = floor(b_y1_lut[int(BY1)] + b_cb_lut[int(BCb)] + 0.5f);
				if (R < 0.f) R = 0.f; else if (R > 255.f) R = 255.f;
				if (G < 0.f) G = 0.f; else if (G > 255.f) G = 255.f;
				if (B < 0.f) B = 0.f; else if (B > 255.f) B = 255.f;

				float t = tptr[x];
				float R_hz = R * t + A_atm * (1.0f - t);
				float G_hz = G * t + A_atm * (1.0f - t);
				float B_hz = B * t + A_atm * (1.0f - t);

				// RGB -> YCbCr (파일의 LUT 사용: y1_*, cb_*, cr_*)
				int Ri = (int)std::round((std::min)(255.f, std::max(0.f, R_hz)));
				int Gi = (int)std::round((std::min)(255.f, std::max(0.f, G_hz)));
				int Bi = (int)std::round((std::min)(255.f, std::max(0.f, B_hz)));

				imgYS[y * m_width + x] = (BYTE)(y1_r_lut[Ri] + y1_g_lut[Gi] + y1_b_lut[Bi]);
				imgCbS[y * m_width + x] = (BYTE)((cb_r_lut[Ri] + cb_g_lut[Gi] + cb_b_lut[Bi]) + 128.0f);
				imgCrS[y * m_width + x] = (BYTE)((cr_r_lut[Ri] + cr_g_lut[Gi] + cr_b_lut[Bi]) + 128.0f);
			}
		}
	}
	// === End of Haze ===


	//********************************************//
	// ------------ Operation End  -------------- //
	//********************************************// 

		// Webcam MP4 save
	if (m_run_mode == 1 && cam_mp4_save) {
		for (y = 0; y < m_height; y++)
			for (x = 0; x < m_width; x++)
				video_st.cam_result_y[y * m_width + x] = imgYS[y * m_width + x];

		for (y = 0; y < m_height / 2; y++) {
			for (x = 0; x < m_width / 2; x++) {
				video_st.cam_result_u[y * m_width / 2 + x] = imgCbS[2 * y * m_width + 2 * x];
				video_st.cam_result_v[y * m_width / 2 + x] = imgCrS[2 * y * m_width + 2 * x];
			}
		}
	}

	// color converting
	for (y = 0; y < m_height; y++) {
		for (x = 0; x < m_width; x++) {
			BYTE BY1, BCb, BCr;
			float fR, fG, fB;
			float fY2, fU, fV;
			float fY1, fCb, fCr;

			BY1 = imgYS[y * m_width + x];
			BCb = imgCbS[y * m_width + x];
			BCr = imgCrS[y * m_width + x];

			// ycbcr to rgb --------------------------------------------------------------
			fR = floor(r_y1_lut[int(BY1)] + r_cb_lut[int(BCb)] + r_cr_lut[int(BCr)] + 0.5f);
			if (fR > 255.f) fR = 255.0f;
			else if (fR < 0.f) fR = 0.0f;
			else;

			fG = floor(g_y1_lut[int(BY1)] + g_cb_lut[int(BCb)] + g_cr_lut[int(BCr)] + 0.5f);
			if (fG > 255.f) fG = 255.0f;
			else if (fG < 0.f) fG = 0.0f;
			else;

			fB = floor(b_y1_lut[int(BY1)] + b_cb_lut[int(BCb)] + 0.5f);
			if (fB > 255.f) fB = 255.0f;
			else if (fB < 0.f) fB = 0.0f;
			else;

			ptrCDstImg[y][x].R = BYTE(fR);
			ptrCDstImg[y][x].G = BYTE(fG);
			ptrCDstImg[y][x].B = BYTE(fB);

			//--- ��������� ó������ ���� ������ ��� ----//
			if (m_check_sidebyside == TRUE) {
				ptrCFullImg[y][m_width + x].R = BYTE(fR);
				ptrCFullImg[y][m_width + x].G = BYTE(fG);
				ptrCFullImg[y][m_width + x].B = BYTE(fB);
			}
			else if (m_check_upanddown == TRUE) {

				ptrCFullImg[m_height + y][x].R = BYTE(fR);
				ptrCFullImg[m_height + y][x].G = BYTE(fG);
				ptrCFullImg[m_height + y][x].B = BYTE(fB);
			}
			//------------------------------------------//

			// yuv save �� ���, rgb to yuv -------------------------------------------------------
			if (m_bYUVSave == TRUE) {

				fY2 = floor(y2_r_lut[int(fR)] + y2_g_lut[int(fG)] + y2_b_lut[int(fB)] + 16.0f);
				if (fY2 > 255.f) imgYUVy_pr[y * m_width + x] = BYTE(255);          //ó������� imgYUV_pr�� ����
				else if (fY2 < 0.f) imgYUVy_pr[y * m_width + x] = BYTE(0);
				else;

				fU = floor(u_r_lut[int(fR)] + u_g_lut[int(fG)] + u_b_lut[int(fB)] + 128.0f);
				if (fU > 255.f) imgYUVu_pr[y * m_width + x] = BYTE(255);
				else if (fU < 0.f) imgYUVu_pr[y * m_width + x] = BYTE(0);
				else;

				fV = floor(v_r_lut[int(fR)] + v_g_lut[int(fG)] + v_b_lut[int(fB)] + 128.0f);
				if (fV > 255.f) imgYUVv_pr[y * m_width + x] = BYTE(255);
				else if (fV < 0.f) imgYUVv_pr[y * m_width + x] = BYTE(0);
				else;


				if (m_check_sidebyside == TRUE)
				{
					//imgYUVy_pr[y * 2 * m_width + x] = BYTE(BY1);
					//imgYUVu_pr[y * 2 * m_width + x] = BYTE(BCb);
					//imgYUVv_pr[y * 2 * m_width + x] = BYTE(BCr);
					imgYUVy_pr[y * 2 * m_width + m_width + x] = BYTE(fY2);
					imgYUVu_pr[y * 2 * m_width + m_width + x] = BYTE(fU);
					imgYUVv_pr[y * 2 * m_width + m_width + x] = BYTE(fV);
				}
				else if (m_check_upanddown == TRUE)
				{
					//imgYUVy_pr[y * m_width + x] = BYTE(BY1);
					//imgYUVu_pr[y * m_width + x] = BYTE(BCb);
					//imgYUVv_pr[y * m_width + x] = BYTE(BCr);
					imgYUVy_pr[m_height * m_width + y * m_width + x] = BYTE(fY2);
					imgYUVu_pr[m_height * m_width + y * m_width + x] = BYTE(fU);
					imgYUVv_pr[m_height * m_width + y * m_width + x] = BYTE(fV);

				}
				else
				{
					imgYUVy_pr[y * m_width + x] = BYTE(fY2);
					imgYUVu_pr[y * m_width + x] = BYTE(fU);
					imgYUVv_pr[y * m_width + x] = BYTE(fV);
				}


			} // YUV �� ------------------------------------------------------------------------------

			  // ycbcr save �� ���, rgb to ycbcr -------------------------------------------------------
			else if (m_bYCbCrSave == TRUE) {

				fY1 = floor(y1_r_lut[int(fR)] + y1_g_lut[int(fG)] + y1_b_lut[int(fB)]);
				if (fY1 > 255.f) imgYCbCry_pr[y * m_width + x] = BYTE(255);          //ó������� imgYUV_pr�� ����
				else if (fY1 < 0.f) imgYCbCry_pr[y * m_width + x] = BYTE(0);
				else;

				fCb = floor(cb_r_lut[int(fR)] + cb_g_lut[int(fG)] + cb_b_lut[int(fB)]) + 128.0f;
				if (fCb > 255.f) imgYCbCrcb_pr[y * m_width + x] = BYTE(255);
				else if (fCb < 0.f) imgYCbCrcb_pr[y * m_width + x] = BYTE(0);
				else;

				fCr = floor(cr_r_lut[int(fR)] + cr_g_lut[int(fG)] + cr_b_lut[int(fB)]) + 128.0f;
				if (fCr > 255.f) imgYCbCrcr_pr[y * m_width + x] = BYTE(255);
				else if (fCr < 0.f) imgYCbCrcr_pr[y * m_width + x] = BYTE(0);
				else;

				if (m_check_sidebyside == TRUE)
				{
					//imgYCbCry_pr[y * 2 * m_width + x] = BYTE(BY1);
					//imgYCbCrcb_pr[y * 2 * m_width + x] = BYTE(BCb);
					//imgYCbCrcr_pr[y * 2 * m_width + x] = BYTE(BCr);
					imgYCbCry_pr[y * 2 * m_width + m_width + x] = BYTE(fY1);
					imgYCbCrcb_pr[y * 2 * m_width + m_width + x] = BYTE(fCb);
					imgYCbCrcr_pr[y * 2 * m_width + m_width + x] = BYTE(fCr);
				}
				else if (m_check_upanddown == TRUE)
				{
					//imgYCbCry_pr[y * m_width + x] = BYTE(BY1);
					//imgYCbCrcb_pr[y * m_width + x] = BYTE(BCb);
					//imgYCbCrcr_pr[y * m_width + x] = BYTE(BCr);
					imgYCbCry_pr[m_height * m_width + y * m_width + x] = BYTE(fY1);
					imgYCbCrcb_pr[m_height * m_width + y * m_width + x] = BYTE(fCb);
					imgYCbCrcr_pr[m_height * m_width + y * m_width + x] = BYTE(fCr);
				}
				else {
					imgYCbCry_pr[y * m_width + x] = BYTE(fY1);
					imgYCbCrcb_pr[y * m_width + x] = BYTE(fCb);
					imgYCbCrcr_pr[y * m_width + x] = BYTE(fCr);
				}

			} // YCbCr �� ------------------------------------------------------------------------------
			else;
		}
	}

	// YUV �������� ���� ==========================================================
	if ((m_run_mode == 3) || (m_run_mode == 4) || (m_run_mode == 5) || (m_run_mode == 6)) {         // video file save�� ó���� ��� ���� ����
		if (m_bYUVSave == TRUE) {
			if (m_frame_num == 0) {
				s.Format("Video File Save Start\r\n");
				((CHistoryEdit*)GetDlgItem(IDC_EDIT_MEMO))->AppendString(s);
			}
			else;

			if (m_fpAviSave != NULL && yuv_save == TRUE) {
				if (m_check_sidebyside == FALSE && m_check_upanddown == FALSE) {
					fwrite(imgYUVy_pr, sizeof(BYTE), m_height * m_width, m_fpAviSave);
					fwrite(imgYUVu_pr, sizeof(BYTE), m_height * m_width, m_fpAviSave);
					fwrite(imgYUVv_pr, sizeof(BYTE), m_height * m_width, m_fpAviSave);
				}
				else {
					fwrite(imgYUVy_pr, sizeof(BYTE), m_height * 2 * m_width, m_fpAviSave);
					fwrite(imgYUVu_pr, sizeof(BYTE), m_height * 2 * m_width, m_fpAviSave);
					fwrite(imgYUVv_pr, sizeof(BYTE), m_height * 2 * m_width, m_fpAviSave);
				}
				//fwrite((void*) buffer, size_t size, size_t count, FILE* stream);
				//fwrite(�о�ð�, ũ��, ����, ������ġ)
			}
			else AfxMessageBox("save failed");
		}
		else;
	}
	else if (m_run_mode == 1) {                              // cam save�� ó���� ������ ����
		if (m_bYUVSave == TRUE) {
			//waitKey(30);
			if (m_frame_num == 0) {
				VideoSave.Format("Camera Save Start\r\n");
				((CHistoryEdit*)GetDlgItem(IDC_EDIT_MEMO))->AppendString(VideoSave);
			}
			else;

			if ((m_fpAviSave != NULL) | (m_fpAviSavePro != NULL)) {
				fwrite(imgYUVy, sizeof(BYTE), m_height * m_width, m_fpAviSave);
				fwrite(imgYUVu, sizeof(BYTE), m_height * m_width, m_fpAviSave);
				fwrite(imgYUVv, sizeof(BYTE), m_height * m_width, m_fpAviSave);

				fwrite(imgYUVy_pr, sizeof(BYTE), m_height * m_width, m_fpAviSavePro);
				fwrite(imgYUVu_pr, sizeof(BYTE), m_height * m_width, m_fpAviSavePro);
				fwrite(imgYUVv_pr, sizeof(BYTE), m_height * m_width, m_fpAviSavePro);
			}
			else AfxMessageBox("save failed");
		}
		else;
	}
	else;

	// YCbCr �������� ���� ==========================================================
	if ((m_run_mode == 3) || (m_run_mode == 4) || (m_run_mode == 5) || (m_run_mode == 6)) {         // video file save�� ó���� ��� ���� ����
		if (m_bYCbCrSave == TRUE) {
			if (m_frame_num == 0) {
				s.Format("Video File Save Start\r\n");
				((CHistoryEdit*)GetDlgItem(IDC_EDIT_MEMO))->AppendString(s);
			}
			else;

			if (m_fpAviSave != NULL && ycbcr_save == TRUE) {
				if (m_check_sidebyside == FALSE && m_check_upanddown == FALSE)
				{
					fwrite(imgYCbCry_pr, sizeof(BYTE), m_height * m_width, m_fpAviSave);
					fwrite(imgYCbCrcb_pr, sizeof(BYTE), m_height * m_width, m_fpAviSave);
					fwrite(imgYCbCrcr_pr, sizeof(BYTE), m_height * m_width, m_fpAviSave);
				}
				else
				{
					fwrite(imgYCbCry_pr, sizeof(BYTE), 2 * m_height * m_width, m_fpAviSave);
					fwrite(imgYCbCrcb_pr, sizeof(BYTE), 2 * m_height * m_width, m_fpAviSave);
					fwrite(imgYCbCrcr_pr, sizeof(BYTE), 2 * m_height * m_width, m_fpAviSave);
				}
			}
			else {
				//AfxMessageBox("save failed");
			}
		}
		else;
	}

	else if (m_run_mode == 1) {                              // cam save�� ó���� ������ ����
		if (m_bYCbCrSave == TRUE) {
			//waitKey(30);
			if (m_frame_num == 0) {
				VideoSave.Format("Camera Save Start\r\n");
				((CHistoryEdit*)GetDlgItem(IDC_EDIT_MEMO))->AppendString(VideoSave);
			}
			else;

			if ((m_fpAviSave != NULL) || (m_fpAviSavePro != NULL)) {
				fwrite(imgYCbCry, sizeof(BYTE), m_height * m_width, m_fpAviSave);
				fwrite(imgYCbCrcb, sizeof(BYTE), m_height * m_width, m_fpAviSave);
				fwrite(imgYCbCrcr, sizeof(BYTE), m_height * m_width, m_fpAviSave);

				fwrite(imgYCbCry_pr, sizeof(BYTE), m_height * m_width, m_fpAviSavePro);
				fwrite(imgYCbCrcb_pr, sizeof(BYTE), m_height * m_width, m_fpAviSavePro);
				fwrite(imgYCbCrcr_pr, sizeof(BYTE), m_height * m_width, m_fpAviSavePro);
			}
			else {
				//AfxMessageBox("save failed");
			}
		}
		else;
	}
	else;


	// BMP �������� ���� ==========================================================
	if ((m_run_mode == 1) || (m_run_mode == 3) || (m_run_mode == 4) || (m_run_mode == 5) || (m_run_mode == 6)) {

		if (m_capture_flag) {

			CFileDialog fileOpen(FALSE, NULL, NULL, OFN_FILEMUSTEXIST |
				OFN_PATHMUSTEXIST | OFN_EXPLORER,
				"BMP Image(*.bmp)|*.bmp|JPG Image(*.jpg)|*.jpg|All Files(*.*)|*.*||", NULL);

			if (fileOpen.DoModal() == IDOK) { //return;
				if (m_check_sidebyside == FALSE && m_check_upanddown == FALSE)
				{
					StillSave = fileOpen.GetPathName();
					StillSavePRO = fileOpen.GetPathName();

					StillSave.Format(StillSave + "_org%d.bmp", m_frame_num);     // ó�� �� image
					m_CImage.Save(StillSave);
					((CHistoryEdit*)GetDlgItem(IDC_EDIT_MEMO))->AppendString(StillSave);

					StillSavePRO.Format(StillSavePRO + "_process%d.bmp", m_frame_num);  //ó�� �� image
					m_CDstImage.Save(StillSavePRO);
					((CHistoryEdit*)GetDlgItem(IDC_EDIT_MEMO))->AppendString(StillSavePRO);
				}
				else if (m_check_sidebyside == TRUE)
				{
					StillSave = fileOpen.GetPathName();
					StillSave.Format(StillSave + "_sidebyside%d.bmp", m_frame_num);     // ó�� �� image
					m_CFullImage.Save(StillSave);
					((CHistoryEdit*)GetDlgItem(IDC_EDIT_MEMO))->AppendString(StillSave);
				}
				else// if (m_check_sidebyside == TRUE)
				{
					StillSave = fileOpen.GetPathName();
					StillSave.Format(StillSave + "_upanddown%d.bmp", m_frame_num);     // ó�� �� image
					m_CFullImage.Save(StillSave);
					((CHistoryEdit*)GetDlgItem(IDC_EDIT_MEMO))->AppendString(StillSave);
				}/*
				StillSave = fileOpen.GetPathName();
				StillSavePRO = fileOpen.GetPathName();

				StillSave.Format(StillSave + "_org%d.bmp", m_frame_num);     // ó�� �� image
				m_CImage.Save(StillSave);
				((CHistoryEdit *)GetDlgItem(IDC_EDIT_MEMO))->AppendString(StillSave);

				StillSavePRO.Format(StillSavePRO + "_process%d.bmp", m_frame_num);  //ó�� �� image
				m_CDstImage.Save(StillSavePRO);
				((CHistoryEdit *)GetDlgItem(IDC_EDIT_MEMO))->AppendString(StillSavePRO);*/
			}
			else;
		}
		else;
		m_capture_flag = FALSE;
	}
	else {
		if (m_capture_flag) {

			CFileDialog fileOpen(FALSE, NULL, NULL, OFN_FILEMUSTEXIST |
				OFN_PATHMUSTEXIST | OFN_EXPLORER,
				"BMP Image(*.bmp)|*.bmp|JPG Image(*.jpg)|*.jpg|All Files(*.*)|*.*||", NULL);

			if (fileOpen.DoModal() == IDOK) { //return;
				if (m_check_sidebyside == FALSE && m_check_upanddown == FALSE)
				{
					//StillSave = fileOpen.GetPathName();
					StillSavePRO = fileOpen.GetPathName();

					//StillSave.Format(StillSave + "_org%d.bmp", m_frame_num);     // ó�� �� image
					//m_CImage.Save(StillSave);
					//((CHistoryEdit*)GetDlgItem(IDC_EDIT_MEMO))->AppendString(StillSave);

					StillSavePRO.Format(StillSavePRO + "_process%d.bmp", m_frame_num);  //ó�� �� image
					m_CDstImage.Save(StillSavePRO);
					((CHistoryEdit*)GetDlgItem(IDC_EDIT_MEMO))->AppendString(StillSavePRO);
				}
				else if (m_check_sidebyside == TRUE)
				{
					StillSave = fileOpen.GetPathName();
					StillSave.Format(StillSave + "_sidebyside%d.bmp", m_frame_num);     // ó�� �� image
					m_CFullImage.Save(StillSave);
					((CHistoryEdit*)GetDlgItem(IDC_EDIT_MEMO))->AppendString(StillSave);
				}
				else// if (m_check_sidebyside == TRUE)
				{
					StillSave = fileOpen.GetPathName();
					StillSave.Format(StillSave + "_upanddown%d.bmp", m_frame_num);     // ó�� �� image
					m_CFullImage.Save(StillSave);
					((CHistoryEdit*)GetDlgItem(IDC_EDIT_MEMO))->AppendString(StillSave);
				}
			}

		}
		else;
		m_capture_flag = FALSE;
	}

	// AVI �������� ���� ==========================================================


	if (m_check_sidebyside == FALSE && m_check_upanddown == FALSE) { //avisave가 0, -> 분기점 미 작동?
		if (ofmt_ctx != NULL || VideoOut.isOpened()) // VideoOut for AVI SAVE -> videout이 성공적으로 열렸는지, outputformatcontext가 성공적으로 할당 되었는지
		{
			Mat resultImg;
			resultImg = Mat(m_height, m_width, CV_8UC3);
			//resultImg = &temp_resultImg;
			pimg = (BYTE*)resultImg.data;
			ws = resultImg.cols * resultImg.channels();

			if ((m_run_mode == 3) || (m_run_mode == 4) || (m_run_mode == 5) || (m_run_mode == 6)) {
				CColorPixel24Ptr ptrCDstImg(m_CDstImage);

				for (j = 0; j < resultImg.rows; j++) {
					//y = j;
					//if (resultImg->origin == 1) y = j;
					//else 
					y = resultImg.rows - j - 1;

					for (i = 0; i < resultImg.cols; i++) {
						pimg[y * ws + i * 3 + 0] = ptrCDstImg[j][i].B;
						pimg[y * ws + i * 3 + 1] = ptrCDstImg[j][i].G;
						pimg[y * ws + i * 3 + 2] = ptrCDstImg[j][i].R;
					}
				}
			}
			else if (m_run_mode == 1) {
				//waitKey(30); // dw // draw Image ��û ó���� ���� delay

				CColorPixel24Ptr ptrCImg(m_CImage);

				for (j = 0; j < resultImg.rows; j++) {
					//y = j;
					//if (resultImg->origin == 1) y = j;
					//else 
					y = resultImg.rows - j - 1;

					for (i = 0; i < resultImg.cols; i++) {
						pimg[y * ws + i * 3 + 0] = ptrCImg[j][i].B;
						pimg[y * ws + i * 3 + 1] = ptrCImg[j][i].G;
						pimg[y * ws + i * 3 + 2] = ptrCImg[j][i].R;
					}
				}
			}
			else;


			flip(resultImg, resultImg, 0);
			if (ofmt_ctx != NULL)
				mresultImg = resultImg;//cvarrToMat(resultImg, true);
			if (VideoOut.isOpened())
				VideoOut.write(resultImg);
			resultImg.release();
		}
		else;

		if (VideoOutPro.isOpened())
		{
			Mat resultImg;
			resultImg = Mat(m_height, m_width, CV_8UC3);
			//resultImg = &temp_resultImg;
			pimg = (BYTE*)resultImg.data;
			ws = resultImg.cols * resultImg.channels();

			CColorPixel24Ptr ptrCDstImg(m_CDstImage);

			for (j = 0; j < resultImg.rows; j++) {
				//y = j;
				//if (resultImg->origin == 1) y = j;
				//else 
				y = resultImg.rows - j - 1;

				for (i = 0; i < resultImg.cols; i++) {
					pimg[y * ws + i * 3 + 0] = ptrCDstImg[j][i].B;
					pimg[y * ws + i * 3 + 1] = ptrCDstImg[j][i].G;
					pimg[y * ws + i * 3 + 2] = ptrCDstImg[j][i].R;
				}
			}

			flip(resultImg, resultImg, 0);
			VideoOut.write(resultImg);
			resultImg.release();
		}
		else;
	}
	else if (m_check_sidebyside == TRUE) {
		if (ofmt_ctx != NULL || VideoOut.isOpened()) // VideoOut for AVI SAVE
		{
			Mat resultImg;
			resultImg = Mat(m_height, 2 * m_width, CV_8UC3);
			//resultImg = &temp_resultImg;
			pimg = (BYTE*)resultImg.data;
			ws = resultImg.cols * resultImg.channels();

			CColorPixel24Ptr ptrCFullImg(m_CFullImage);

			for (j = 0; j < resultImg.rows; j++) {
				//y = j;
				//if (resultImg->origin == 1) y = j;
				//else 
				y = resultImg.rows - j - 1;

				for (i = 0; i < resultImg.cols; i++) {
					pimg[y * ws + i * 3 + 0] = ptrCFullImg[j][i].B;
					pimg[y * ws + i * 3 + 1] = ptrCFullImg[j][i].G;
					pimg[y * ws + i * 3 + 2] = ptrCFullImg[j][i].R;
				}

			}

			flip(resultImg, resultImg, 0);
			if (ofmt_ctx != NULL)
				mresultImg = resultImg;// cvarrToMat(resultImg, true);
			if (VideoOut.isOpened())
				VideoOut.write(resultImg);
			resultImg.release();
		}
		else;

	}
	else
	{
		if (ofmt_ctx != NULL || VideoOut.isOpened()) // VideoOut for AVI SAVE
		{
			Mat resultImg;
			resultImg = Mat(2 * m_height, m_width, CV_8UC3);
			//resultImg = &temp_resultImg;
			pimg = (BYTE*)resultImg.data;
			ws = resultImg.cols * resultImg.channels();

			CColorPixel24Ptr ptrCFullImg(m_CFullImage);

			for (j = 0; j < resultImg.rows; j++) {
				//y = j;
				//if (resultImg->origin == 1) y = j;
				//else 
				y = resultImg.rows - j - 1;

				for (i = 0; i < resultImg.cols; i++) {
					pimg[y * ws + i * 3 + 0] = ptrCFullImg[j][i].B;
					pimg[y * ws + i * 3 + 1] = ptrCFullImg[j][i].G;
					pimg[y * ws + i * 3 + 2] = ptrCFullImg[j][i].R;
				}

			}

			flip(resultImg, resultImg, 0);
			if (ofmt_ctx != NULL)
				mresultImg = resultImg;// cvarrToMat(resultImg, true);
			if (VideoOut.isOpened())
				VideoOut.write(resultImg);
			resultImg.release();
		}
		else;
	}
	//�ӵ�����	
	double delay_count = m_delay_count;
	waitKey(delay_count);

	//Input Image Display
	GetDlgItem(IDC_STATIC_VIEW)->GetWindowRect(rtDisplay);
	ScreenToClient(rtDisplay);
	m_CImage.Draw(dc.m_hDC, rtDisplay.left, rtDisplay.top, rtDisplay.Width(), rtDisplay.Height());

	//Output Image Display
	GetDlgItem(IDC_STATIC_VIEW2)->GetWindowRect(rtDisplay);
	ScreenToClient(rtDisplay);
	m_CDstImage.Draw(dc.m_hDC, rtDisplay.left, rtDisplay.top, rtDisplay.Width(), rtDisplay.Height());

	//////////////////////////////////////////////////////////////////////
	/*	if (m_run_mode == 1) m_frame_num++;
	else*/;

	//���� �����°� ����
	if (atoi(m_edit_save_fps) == 0) m_edit_save_fps = temp_m_edit_save_fps;
	else temp_m_edit_save_fps = m_edit_save_fps;

	if (atoi(m_repeat_processing) == 0) m_repeat_processing = temp_m_repeat_processing;
	else temp_m_repeat_processing = m_repeat_processing;

	if (atoi(m_edit_Video_width) == 0) m_edit_Video_width = temp_m_edit_Video_width;
	else temp_m_edit_Video_width = m_edit_Video_width;

	if (atoi(m_edit_Video_height) == 0) m_edit_Video_height = temp_m_edit_Video_height;
	else temp_m_edit_Video_height = m_edit_Video_height;

	if (atoi(m_edit_frame_rate) == 0) m_edit_frame_rate = temp_m_edit_frame_rate;
	else temp_m_edit_frame_rate = m_edit_frame_rate;

	//���� �Ҵ� ����
	m_CImage.Free();
	m_CDstImage.Free();
	m_CFullImage.Free();

	free(imgYS);
	free(imgCbS);
	free(imgCrS);
	free(imgRGB_3);

	free(imgYUVy);
	free(imgYUVu);
	free(imgYUVv);

	free(imgYUVy_pr);
	free(imgYUVu_pr);
	free(imgYUVv_pr);

	free(imgYCbCry);
	free(imgYCbCrcb);
	free(imgYCbCrcr);

	free(imgYCbCry_pr);
	free(imgYCbCrcb_pr);
	free(imgYCbCrcr_pr);

	//delete [] pimg;

	///////////////////////////////////////////////////////////////

	// �ӵ� ���� ���÷���
	QueryPerformanceCounter((LARGE_INTEGER*)&end); //���� �ð��� ����
	elapsed = double(end - start) / (double)freq * (double)1000.0; // <= ���μ��̽ð� (1:s,1000:ms,10^6:us) 
	double temp = double(1000) / double(fps) - double(elapsed);
	if (fps > 0) { // fps ���׼���
		key = waitKey(temp);
	}
	else fps = 30;
	if (temp >= 0)
	{
		temp = double(temp + elapsed);
	}
	else
	{
		temp = double(elapsed);
	}
	s.Format("%.2fms, %.2ffps", double(temp), double(1000) / double(temp));
	GetDlgItem(IDC_STATIC_FPS)->SetWindowText(s);



	_CrtDumpMemoryLeaks();
}

//------------------------------------------------------------proc funtions End//
/////////////////////////////////////////////////////////////////////////////////


void CVS2022_DefaultDlg::YUV_to_RGB(float Input_Y, float Input_U, float Input_V)
{
	Conv_R = r_y2_lut[int(Input_Y)] + r_v_lut[int(Input_V)];
	if (Conv_R > 255.f) Conv_R = 255.0f;
	else if (Conv_R < 0.f)   Conv_R = 0.0f;
	else;

	Conv_G = g_y2_lut[int(Input_Y)] + g_u_lut[int(Input_U)] + g_v_lut[int(Input_V)];
	if (Conv_G > 255.f) Conv_G = 255.0f;
	else if (Conv_G < 0.f)   Conv_G = 0.0f;
	else;

	Conv_B = b_y2_lut[int(Input_Y)] + b_u_lut[int(Input_U)];
	if (Conv_B > 255.f) Conv_B = 255.0f;
	else if (Conv_B < 0.f)   Conv_B = 0.0f;
	else;
}

void CVS2022_DefaultDlg::YCbCr_to_RGB(float Input_Y, float Input_Cb, float Input_Cr)
{
	Conv_R = floor(r_y1_lut[int(Input_Y)] + r_cb_lut[int(Input_Cb)] + r_cr_lut[int(Input_Cr)] + 0.5f);
	if (Conv_R > 255.f) Conv_R = 255.0f;
	else if (Conv_R < 0.f) Conv_R = 0.0f;
	else;

	Conv_G = floor(g_y1_lut[int(Input_Y)] + g_cb_lut[int(Input_Cb)] + g_cr_lut[int(Input_Cr)] + 0.5f);
	if (Conv_G > 255.f) Conv_G = 255.0f;
	else if (Conv_G < 0.f) Conv_G = 0.0f;
	else;

	Conv_B = floor(b_y1_lut[int(Input_Y)] + b_cb_lut[int(Input_Cb)] + 0.5f);
	if (Conv_B > 255.f) Conv_B = 255.0f;
	else if (Conv_B < 0.f) Conv_B = 0.0f;
	else;
}

void CVS2022_DefaultDlg::RGB_to_YUV(float Input_R, float Input_G, float Input_B)
{
	Conv_Y2 = floor(y2_r_lut[int(Input_R)] + y2_g_lut[int(Input_G)] + y2_b_lut[int(Input_B)] + 16.0f);
	if (Conv_Y2 > 255.f) Conv_Y2 = 255.0f;          //ó������� imgYUV_pr�� ����
	else if (Conv_Y2 < 0.f) Conv_Y2 = 0.0f;
	else;

	Conv_U = floor(u_r_lut[int(Input_R)] + u_g_lut[int(Input_G)] + u_b_lut[int(Input_B)] + 128.0f);
	if (Conv_U > 255.f) Conv_U = 255.0f;
	else if (Conv_U < 0.f) Conv_U = 0.0f;
	else;

	Conv_V = floor(v_r_lut[int(Input_R)] + v_g_lut[int(Input_G)] + v_b_lut[int(Input_B)] + 128.0f);
	if (Conv_V > 255.f) Conv_V = 255.0f;
	else if (Conv_V < 0.f) Conv_V = 0.0f;
	else;
}

void CVS2022_DefaultDlg::RGB_to_YCbCr(float Input_R, float Input_G, float Input_B)
{
	Conv_Y1 = floor(y1_r_lut[int(Input_R)] + y1_g_lut[int(Input_G)] + y1_b_lut[int(Input_B)]);
	if (Conv_Y1 > 255.f) Conv_Y1 = 255.0f;
	else if (Conv_Y1 < 0.f) Conv_Y1 = 0.0f;
	else;

	Conv_Cb = floor(cb_r_lut[int(Input_R)] + cb_g_lut[int(Input_G)] + cb_b_lut[int(Input_B)]) + 128.0f;
	if (Conv_Cb > 255.f) Conv_Cb = 255.0f;
	else if (Conv_Cb < 0.f) Conv_Cb = 0.0f;
	else;

	Conv_Cr = floor(cr_r_lut[int(Input_R)] + cr_g_lut[int(Input_G)] + cr_b_lut[int(Input_B)]) + 128.0f;
	if (Conv_Cr > 255.f) Conv_Cr = 255.0f;
	else if (Conv_Cr < 0.f) Conv_Cr = 0.0f;
	else;
}

void CVS2022_DefaultDlg::OnRadio_Yuv444r()
{
	m_radio_read = 0;
}

void CVS2022_DefaultDlg::OnRadio_Yuv422r()
{
	m_radio_read = 1;
}

void CVS2022_DefaultDlg::OnRadio_Yuv420r()
{
	m_radio_read = 2;
}

void CVS2022_DefaultDlg::OnRadio_Yuv444w()
{
	m_radio_write = 0;
}

void CVS2022_DefaultDlg::OnRadio_Yuv422w()
{
	m_radio_write = 1;
}

void CVS2022_DefaultDlg::OnRadio_Yuv420w()
{
	m_radio_write = 2;
}


BOOL CVS2022_DefaultDlg::PreTranslateMessage(MSG* pMsg)
{
	// TODO: ���⿡ Ư��ȭ�� �ڵ带 �߰� ��/�Ǵ� �⺻ Ŭ������ ȣ���մϴ�.

	// EnterKey Ignore-------------------------------------------
	if (pMsg->message == WM_KEYDOWN && pMsg->wParam == VK_RETURN)
		return TRUE;
	//-----------------------------------------------------------

	return CDialogEx::PreTranslateMessage(pMsg);
}

void CVS2022_DefaultDlg::OnSize(UINT nType, int cx, int cy)
{
	CDialogEx::OnSize(nType, cx, cy);

	// TODO: Add your message handler code here.
	m_nCurHeight = cy;
	m_nCurWidth = cx;
	int nScrollMax;
	int nHScrollMax;



	if (cy < m_rect.Height())
	{
		nScrollMax = m_rect.Height() - cy;
	}
	else
		nScrollMax = 0;
	if (cx < m_rect.Width())
	{
		nHScrollMax = m_rect.Width() - cx;
	}
	else
		nHScrollMax = 0;

	//((CHistoryEdit *)GetDlgItem(IDC_EDIT_MEMO))->AppendString(s);

	SCROLLINFO si;
	si.cbSize = sizeof(SCROLLINFO);
	si.fMask = SIF_ALL; // SIF_ALL = SIF_PAGE | SIF_RANGE | SIF_POS;
	si.nMin = 0;
	si.nMax = nScrollMax;
	si.nPage = si.nMax / 10;
	si.nPos = 0;
	SetScrollInfo(SB_VERT, &si, TRUE);

	SCROLLINFO siH;
	siH.cbSize = sizeof(SCROLLINFO);
	siH.fMask = SIF_ALL; // SIF_ALL = SIF_PAGE | SIF_RANGE | SIF_POS;
	siH.nMin = 0;
	siH.nMax = nHScrollMax;
	siH.nPage = siH.nMax / 10;
	siH.nPos = 0;
	SetScrollInfo(SB_HORZ, &siH, TRUE);
}

void CVS2022_DefaultDlg::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.

	CDialogEx::OnVScroll(nSBCode, nPos, pScrollBar);

	// TODO: Add your message handler code here and/or call default.
	int nDelta;
	int nMaxPos = m_rect.Height() - m_nCurHeight;

	switch (nSBCode)
	{
	case SB_LINEDOWN:
		if (m_nScrollPos >= nMaxPos)
			return;
		nDelta = min(nMaxPos / 10, nMaxPos - m_nScrollPos);
		break;

	case SB_LINEUP:
		if (m_nScrollPos <= 0)
			return;
		nDelta = -min(nMaxPos / 10, m_nScrollPos);
		break;

	case SB_PAGEDOWN:
		if (pScrollBar != NULL) return;
		if (m_nScrollPos >= nMaxPos)
			return;
		nDelta = min(nMaxPos / 10, nMaxPos - m_nScrollPos);
		break;

	case SB_THUMBTRACK:
		if (pScrollBar != NULL) return;
		nDelta = (int)nPos - m_nScrollPos;
		break;

	case SB_PAGEUP:
		if (pScrollBar != NULL) return;
		if (m_nScrollPos <= 0)
			return;
		nDelta = -min(nMaxPos / 10, m_nScrollPos);
		break;

	default:
		return;
	}
	m_nScrollPos += nDelta;
	SetScrollPos(SB_VERT, m_nScrollPos, TRUE);
	ScrollWindow(0, -nDelta);
	CDialog::OnVScroll(nSBCode, nPos, pScrollBar);

}

void CVS2022_DefaultDlg::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.

	//CDialogEx::OnHScroll(nSBCode, nPos, pScrollBar);

	int nDelta;
	int nHMaxPos = m_rect.Width() - m_nCurWidth;

	switch (nSBCode)
	{
	case SB_LINERIGHT:
		if (m_nHScrollPos >= nHMaxPos)
			return;
		nDelta = min(nHMaxPos / 10, nHMaxPos - m_nHScrollPos);
		break;

	case SB_LINELEFT:
		if (m_nHScrollPos <= 0)
			return;
		nDelta = -min(nHMaxPos / 10, m_nHScrollPos);
		break;

	case SB_PAGERIGHT:
		if (pScrollBar != NULL) return;
		if (m_nHScrollPos >= nHMaxPos)
			return;
		nDelta = min(nHMaxPos / 10, nHMaxPos - m_nHScrollPos);
		break;

	case SB_THUMBTRACK:
		if (pScrollBar != NULL) return;
		nDelta = (int)nPos - m_nHScrollPos;
		break;

	case SB_PAGELEFT:
		if (pScrollBar != NULL) return;
		if (m_nHScrollPos <= 0)
			return;
		nDelta = -min(nHMaxPos / 10, m_nHScrollPos);
		break;

	default:
		return;
	}
	m_nHScrollPos += nDelta;
	SetScrollPos(SB_HORZ, m_nHScrollPos, TRUE);
	ScrollWindow(-nDelta, 0);

	CDialog::OnHScroll(nSBCode, nPos, pScrollBar);
}

BOOL CVS2022_DefaultDlg::OnMouseWheel(UINT nFlags, short zDelta, CPoint pt)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.




	// nWheelScrollLines �� �ѹ��� �̵��ϴ� �� �� (Reg���� �о� �´�)
	HKEY hKey = 0;
	DWORD dwType = REG_BINARY;
	DWORD dwSize = 10;
	BYTE* pByte = new BYTE[dwSize];

	ZeroMemory(pByte, dwSize);

	RegOpenKey(HKEY_CURRENT_USER, "Control Panel\\Desktop", &hKey);
	RegQueryValueEx(hKey, "WheelScrollLines", NULL, &dwType, pByte, &dwSize);
	RegCloseKey(hKey);

	int nWheelScrollLines = atoi((char*)pByte);
	delete pByte;

	// nWheelScrollPixel = �� �ѹ��� �̵��ϴ� Pixel
	int nScrollMin, nScrollMax;
	GetScrollRange(SB_VERT, &nScrollMin, &nScrollMax);
	int nSign = -(zDelta / abs(zDelta));

	int nWheelScrollPixel = nSign * (nScrollMax + 1) * nWheelScrollLines / 50;


	// Scroll ���� ������ ���� �ʵ��� �Ѵ�.
	long nScrollY = GetScrollPos(SB_VERT);
	long nScrollLimitY = GetScrollLimit(SB_VERT);

	if (nScrollY + nWheelScrollPixel < 0)
		nWheelScrollPixel = -nScrollY;

	if (nScrollY + nWheelScrollPixel > nScrollLimitY)
		nWheelScrollPixel = nScrollLimitY - nScrollY;



	// nWheelScrollPixel ������ �ϰ���� ó��

	m_nScrollPos += nWheelScrollPixel;
	SetScrollPos(SB_VERT, m_nScrollPos, TRUE);
	ScrollWindow(0, -nWheelScrollPixel);

	return CDialogEx::OnMouseWheel(nFlags, zDelta, pt);
}




/////////////////////////////////////////////////////////////////////////////////
//algorithm functions start (button, operation, etc.---------------------------//


