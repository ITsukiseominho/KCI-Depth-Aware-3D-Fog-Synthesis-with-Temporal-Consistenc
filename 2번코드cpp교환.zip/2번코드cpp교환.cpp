#include "pch.h"
#include "framework.h"
#include "VS2022_Default.h"
#include "VS2022_DefaultDlg.h"
#include "afxdialogex.h"
#include <opencv2/opencv.hpp>

extern "C" {
#include <libavcodec/avcodec.h>
#include <libavformat/avformat.h>
#include <libswscale/swscale.h>
#include <libavdevice/avdevice.h>
#include <libavutil/imgutils.h>
}

#include <iostream>
#include <string>
#include <vector>
#include <thread>
#include <memory>
#include <fstream>
#include <sstream>
#include <chrono>

using namespace cv;
using namespace std;

// ���� ���� ����

AVFormatContext* ifmt_ctx = nullptr;
AVCodecContext* video_dec_ctx = nullptr;
AVCodecContext* audio_dec_ctx = nullptr;
SwsContext* sws_ctx = nullptr;

AVStream* video_stream = nullptr;
AVStream* audio_stream = nullptr;

int video_stream_index = -1;
int audio_stream_index = -1;

bool camstopflag = false;
bool cammp4flag = false;

CString m_camVideoName;
CString m_camAudioName;

CWinThread* m_pthread = nullptr;
int m_run_mode = 0;     // 1: camera 2: image 3: video

// LUT ���̺� (RGB <-> YCbCr / YUV ��ȯ��)
vector<float> y1_r_lut(256), y1_g_lut(256), y1_b_lut(256);
vector<float> cb_r_lut(256), cb_g_lut(256), cb_b_lut(256);
vector<float> cr_r_lut(256), cr_g_lut(256), cr_b_lut(256);

// ���� �Լ�

inline void SafeReleaseFFmpeg() {
    if (video_dec_ctx) {
        avcodec_free_context(&video_dec_ctx);
        video_dec_ctx = nullptr;
    }
    if (audio_dec_ctx) {
        avcodec_free_context(&audio_dec_ctx);
        audio_dec_ctx = nullptr;
    }
    if (ifmt_ctx) {
        avformat_close_input(&ifmt_ctx);
        ifmt_ctx = nullptr;
    }
    if (sws_ctx) {
        sws_freeContext(sws_ctx);
        sws_ctx = nullptr;
    }
}

// ����� �޽���
inline void DebugMsg(const std::string& msg) {
    std::cout << "[DEBUG] " << msg << std::endl;
}

// CVS2022_DefaultDlg Ŭ���� ����

CVS2022_DefaultDlg::CVS2022_DefaultDlg(CWnd* pParent /*=nullptr*/)
    : CDialogEx(IDD_VS2022_DEFAULT_DIALOG, pParent)
{
    m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CVS2022_DefaultDlg::DoDataExchange(CDataExchange* pDX)
{
    CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CVS2022_DefaultDlg, CDialogEx)
    ON_BN_CLICKED(IDC_BUTTON_CAMSTART, &CVS2022_DefaultDlg::OnButton_CamStart)
    ON_BN_CLICKED(IDC_BUTTON_CAMSTOP, &CVS2022_DefaultDlg::OnButton_CamStop)
    ON_BN_CLICKED(IDC_BUTTON_CAMSAVE, &CVS2022_DefaultDlg::OnButton_CamMp4save)
END_MESSAGE_MAP()

// ���̾�α� �ʱ�ȭ

BOOL CVS2022_DefaultDlg::OnInitDialog()
{
    CDialogEx::OnInitDialog();

    SetIcon(m_hIcon, TRUE);
    SetIcon(m_hIcon, FALSE);

    // �⺻ �ػ� �� ��� �ʱ�ȭ
    m_run_mode = 0;
    camstopflag = false;
    cammp4flag = false;

    DebugMsg("Dialog Initialized. Setting up LUT...");

    // LUT �ʱ�ȭ
    for (int i = 0; i < 256; ++i) {
        y1_r_lut[i] = static_cast<float>(0.299 * i);
        y1_g_lut[i] = static_cast<float>(0.587 * i);
        y1_b_lut[i] = static_cast<float>(0.114 * i);

        cb_r_lut[i] = static_cast<float>(-0.1687 * i);
        cb_g_lut[i] = static_cast<float>(-0.3313 * i);
        cb_b_lut[i] = static_cast<float>(0.5 * i);

        cr_r_lut[i] = static_cast<float>(0.5 * i);
        cr_g_lut[i] = static_cast<float>(-0.4187 * i);
        cr_b_lut[i] = static_cast<float>(-0.0813 * i);
    }

    DebugMsg("LUT initialization complete.");

    return TRUE;
}
// ī�޶� ���� ���� �Լ�

void CVS2022_DefaultDlg::OnButton_CamStart()
{
    DebugMsg("Camera Start button clicked.");

    camstopflag = false;
    cammp4flag = false;

    // ���õ� ī�޶� ��ġ �̸� ��������
    GetDlgItemText(IDC_COMBO_CAMSEL, m_camVideoName);
    GetDlgItemText(IDC_COMBO_AUDIOSEL, m_camAudioName);

    CString camInput;
    camInput.Format(L"video=%s:audio=%s", m_camVideoName, m_camAudioName);

    std::string camStr = CT2A(camInput);

    // FFmpeg �Է� ���� ����
    AVInputFormat* ifmt = av_find_input_format("dshow");
    if (!ifmt) {
        AfxMessageBox(L"Cannot find DirectShow format.");
        return;
    }

    DebugMsg("Opening FFmpeg input device...");

    if (avformat_open_input(&ifmt_ctx, camStr.c_str(), ifmt, nullptr) < 0) {
        AfxMessageBox(L"Failed to open camera device.");
        return;
    }

    if (avformat_find_stream_info(ifmt_ctx, nullptr) < 0) {
        AfxMessageBox(L"Failed to get stream info.");
        avformat_close_input(&ifmt_ctx);
        return;
    }

    // ���� ��Ʈ�� ã��
    for (unsigned int i = 0; i < ifmt_ctx->nb_streams; ++i) {
        if (ifmt_ctx->streams[i]->codecpar->codec_type == AVMEDIA_TYPE_VIDEO) {
            video_stream_index = static_cast<int>(i);
            break;
        }
    }

    if (video_stream_index == -1) {
        AfxMessageBox(L"Cannot find video stream.");
        avformat_close_input(&ifmt_ctx);
        return;
    }

    DebugMsg("Video stream found.");

    // ������ ����
    m_pthread = AfxBeginThread(ThreadProcessingAVI, this);
    if (!m_pthread) {
        AfxMessageBox(L"Failed to start processing thread.");
        avformat_close_input(&ifmt_ctx);
        return;
    }

    DebugMsg("Capture thread started successfully.");
}

void CVS2022_DefaultDlg::OnButton_CamStop()
{
    DebugMsg("Camera Stop button clicked.");
    camstopflag = true;
    Sleep(500);

    SafeReleaseFFmpeg();
    DebugMsg("FFmpeg resources released.");
}

void CVS2022_DefaultDlg::OnButton_CamMp4save()
{
    DebugMsg("MP4 Save button clicked.");

    if (!ifmt_ctx || video_stream_index < 0) {
        AfxMessageBox(L"No video stream to save.");
        return;
    }

    cammp4flag = !cammp4flag; // ��� ������� ����
    if (cammp4flag) {
        DebugMsg("Starting MP4 save procedure...");

        CString filename = L"ffmpeg_save.mp4";
        std::string saveFile = CT2A(filename);

        AVFormatContext* ofmt_ctx = nullptr;
        if (avformat_alloc_output_context2(&ofmt_ctx, nullptr, nullptr, saveFile.c_str()) < 0 || !ofmt_ctx) {
            AfxMessageBox(L"Cannot create output context.");
            return;
        }

        AVStream* in_stream = ifmt_ctx->streams[video_stream_index];
        AVStream* out_stream = avformat_new_stream(ofmt_ctx, nullptr);
        if (!out_stream) {
            AfxMessageBox(L"Cannot allocate output stream.");
            avformat_free_context(ofmt_ctx);
            return;
        }

        if (avcodec_parameters_copy(out_stream->codecpar, in_stream->codecpar) < 0) {
            AfxMessageBox(L"Failed to copy codec parameters.");
            avformat_free_context(ofmt_ctx);
            return;
        }

        out_stream->codecpar->codec_tag = 0;

        if (!(ofmt_ctx->oformat->flags & AVFMT_NOFILE)) {
            if (avio_open(&ofmt_ctx->pb, saveFile.c_str(), AVIO_FLAG_WRITE) < 0) {
                AfxMessageBox(L"Cannot open output file.");
                avformat_free_context(ofmt_ctx);
                return;
            }
        }

        if (avformat_write_header(ofmt_ctx, nullptr) < 0) {
            AfxMessageBox(L"Failed to write header.");
            avformat_close_input(&ifmt_ctx);
            avformat_free_context(ofmt_ctx);
            return;
        }

        DebugMsg("MP4 header written, start writing frames...");

        AVPacket packet;
        av_init_packet(&packet);

        while (cammp4flag && av_read_frame(ifmt_ctx, &packet) >= 0) {
            if (packet.stream_index == video_stream_index) {
                packet.pts = av_rescale_q_rnd(packet.pts,
                    ifmt_ctx->streams[video_stream_index]->time_base,
                    out_stream->time_base,
                    (AVRounding)(AV_ROUND_NEAR_INF | AV_ROUND_PASS_MINMAX));
                packet.dts = packet.pts;
                packet.duration = av_rescale_q(packet.duration,
                    ifmt_ctx->streams[video_stream_index]->time_base,
                    out_stream->time_base);
                packet.pos = -1;
                packet.stream_index = 0;
                av_interleaved_write_frame(ofmt_ctx, &packet);
            }
            av_packet_unref(&packet);
        }

        av_write_trailer(ofmt_ctx);
        avformat_close_input(&ifmt_ctx);

        if (!(ofmt_ctx->oformat->flags & AVFMT_NOFILE)) {
            avio_closep(&ofmt_ctx->pb);
        }

        avformat_free_context(ofmt_ctx);
        cammp4flag = false;

        DebugMsg("MP4 save completed successfully.");
        AfxMessageBox(L"MP4 ���� �Ϸ�.");
    }
    else {
        DebugMsg("MP4 saving stopped by user.");
        AfxMessageBox(L"MP4 ���� ������.");
    }
}
// ���� �� ���� ó�� ���� �Լ�

void CVS2022_DefaultDlg::OnButton_FileOpen()
{
    DebugMsg("Opening image file...");

    CFileDialog dlg(TRUE, L"*.bmp", nullptr,
        OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST,
        L"Image Files (*.bmp;*.jpg;*.png)|*.bmp;*.jpg;*.png||", this);

    if (dlg.DoModal() != IDOK)
        return;

    CString path = dlg.GetPathName();
    std::string filePath = CT2A(path);

    Mat image = imread(filePath, IMREAD_COLOR);
    if (image.empty()) {
        AfxMessageBox(L"�̹����� �ҷ��� �� �����ϴ�.");
        return;
    }

    imshow("�ҷ��� �̹���", image);
    DebugMsg("Image successfully loaded and displayed.");
}

void CVS2022_DefaultDlg::OnButton_AviOpen()
{
    DebugMsg("Opening video file...");

    CFileDialog dlg(TRUE, L"*.mp4", nullptr,
        OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST,
        L"Video Files (*.mp4;*.avi)|*.mp4;*.avi||", this);

    if (dlg.DoModal() != IDOK)
        return;

    CString path = dlg.GetPathName();
    std::string filePath = CT2A(path);

    VideoCapture cap(filePath);
    if (!cap.isOpened()) {
        AfxMessageBox(L"���� ������ �� �� �����ϴ�.");
        return;
    }

    DebugMsg("Video file opened successfully.");

    Mat frame;
    while (cap.read(frame)) {
        if (frame.empty()) break;
        imshow("Video Preview", frame);

        if (waitKey(33) == 27) break; // ESC�� �ߴ�
    }

    cap.release();
    destroyWindow("Video Preview");

    DebugMsg("Video playback finished.");
}

// ���� ��ȯ (RGB <-> YCbCr)

void RGBtoYCbCr(const Mat& src, Mat& dst)
{
    dst.create(src.size(), src.type());

    for (int y = 0; y < src.rows; ++y) {
        for (int x = 0; x < src.cols; ++x) {
            Vec3b rgb = src.at<Vec3b>(y, x);
            uchar R = rgb[2], G = rgb[1], B = rgb[0];

            uchar Y = static_cast<uchar>(clamp(0.299 * R + 0.587 * G + 0.114 * B, 0.0, 255.0));
            uchar Cb = static_cast<uchar>(clamp(-0.1687 * R - 0.3313 * G + 0.5 * B + 128.0, 0.0, 255.0));
            uchar Cr = static_cast<uchar>(clamp(0.5 * R - 0.4187 * G - 0.0813 * B + 128.0, 0.0, 255.0));

            dst.at<Vec3b>(y, x) = Vec3b(Cb, Y, Cr);
        }
    }
}

void YCbCrtoRGB(const Mat& src, Mat& dst)
{
    dst.create(src.size(), src.type());

    for (int y = 0; y < src.rows; ++y) {
        for (int x = 0; x < src.cols; ++x) {
            Vec3b ycc = src.at<Vec3b>(y, x);
            uchar Cb = ycc[0], Y = ycc[1], Cr = ycc[2];

            int R = static_cast<int>(Y + 1.402 * (Cr - 128));
            int G = static_cast<int>(Y - 0.344136 * (Cb - 128) - 0.714136 * (Cr - 128));
            int B = static_cast<int>(Y + 1.772 * (Cb - 128));

            dst.at<Vec3b>(y, x) = Vec3b(
                static_cast<uchar>(clamp(B, 0, 255)),
                static_cast<uchar>(clamp(G, 0, 255)),
                static_cast<uchar>(clamp(R, 0, 255))
            );
        }
    }
}

// ThreadProcessingAVI (ī�޶� ������ ó�� ����)

UINT ThreadProcessingAVI(LPVOID pParam)
{
    auto* dlg = reinterpret_cast<CVS2022_DefaultDlg*>(pParam);
    DebugMsg("ThreadProcessingAVI started.");

    AVPacket packet;
    AVFrame* pFrame = av_frame_alloc();
    AVFrame* pFrameBGR = av_frame_alloc();

    int ret = 0;
    Mat frame;

    while (!camstopflag && (ret = av_read_frame(ifmt_ctx, &packet)) >= 0) {
        if (packet.stream_index == video_stream_index) {
            ret = avcodec_send_packet(video_dec_ctx, &packet);
            if (ret < 0) continue;

            while (ret >= 0) {
                ret = avcodec_receive_frame(video_dec_ctx, pFrame);
                if (ret == AVERROR(EAGAIN) || ret == AVERROR_EOF)
                    break;
                if (ret < 0)
                    break;

                if (!sws_ctx) {
                    sws_ctx = sws_getContext(pFrame->width, pFrame->height,
                        static_cast<AVPixelFormat>(pFrame->format),
                        pFrame->width, pFrame->height, AV_PIX_FMT_BGR24,
                        SWS_BICUBIC, nullptr, nullptr, nullptr);
                }

                if (!frame.data) frame = Mat(Size(pFrame->width, pFrame->height), CV_8UC3);

                uint8_t* dest[4] = { frame.data, nullptr, nullptr, nullptr };
                int dest_linesize[4] = { static_cast<int>(frame.step), 0, 0, 0 };

                sws_scale(sws_ctx, pFrame->data, pFrame->linesize, 0,
                    pFrame->height, dest, dest_linesize);

                imshow("Camera Stream", frame);

                if (waitKey(1) == 27) { // ESC
                    camstopflag = true;
                    break;
                }
            }
        }
        av_packet_unref(&packet);
    }

    av_frame_free(&pFrame);
    av_frame_free(&pFrameBGR);

    DebugMsg("ThreadProcessingAVI finished.");
    return 0;
}
// ���� ó�� �� �޽��� �ڵ鷯

void CVS2022_DefaultDlg::OnCancel()
{
    DebugMsg("OnCancel called - application closing.");

    camstopflag = true;
    Sleep(300);

    SafeReleaseFFmpeg();

    CDialogEx::OnCancel();
}

void CVS2022_DefaultDlg::OnClose()
{
    DebugMsg("OnClose event received.");

    camstopflag = true;
    Sleep(300);

    SafeReleaseFFmpeg();

    CDialogEx::OnClose();
}

void CVS2022_DefaultDlg::OnDestroy()
{
    DebugMsg("OnDestroy event called.");
    CDialogEx::OnDestroy();

    SafeReleaseFFmpeg();
}

// ��Ÿ ��ƿ �Լ�

// RGB -> YUV ��ȯ
void RGBtoYUV(const Mat& src, Mat& dst)
{
    dst.create(src.size(), src.type());
    for (int y = 0; y < src.rows; ++y) {
        for (int x = 0; x < src.cols; ++x) {
            Vec3b rgb = src.at<Vec3b>(y, x);
            uchar R = rgb[2], G = rgb[1], B = rgb[0];

            uchar Y = static_cast<uchar>(clamp((0.299 * R + 0.587 * G + 0.114 * B), 0.0, 255.0));
            uchar U = static_cast<uchar>(clamp((-0.14713 * R - 0.28886 * G + 0.436 * B + 128), 0.0, 255.0));
            uchar V = static_cast<uchar>(clamp((0.615 * R - 0.51499 * G - 0.10001 * B + 128), 0.0, 255.0));

            dst.at<Vec3b>(y, x) = Vec3b(U, Y, V);
        }
    }
}

// YUV -> RGB ��ȯ
void YUVtoRGB(const Mat& src, Mat& dst)
{
    dst.create(src.size(), src.type());
    for (int y = 0; y < src.rows; ++y) {
        for (int x = 0; x < src.cols; ++x) {
            Vec3b yuv = src.at<Vec3b>(y, x);
            uchar U = yuv[0], Y = yuv[1], V = yuv[2];

            int R = static_cast<int>(Y + 1.13983 * (V - 128));
            int G = static_cast<int>(Y - 0.39465 * (U - 128) - 0.58060 * (V - 128));
            int B = static_cast<int>(Y + 2.03211 * (U - 128));

            dst.at<Vec3b>(y, x) = Vec3b(
                static_cast<uchar>(clamp(B, 0, 255)),
                static_cast<uchar>(clamp(G, 0, 255)),
                static_cast<uchar>(clamp(R, 0, 255))
            );
        }
    }
}

// ���α׷� ���� �� �ڿ� ����

void CVS2022_DefaultDlg::CleanUp()
{
    DebugMsg("CleanUp called. Releasing all FFmpeg resources.");

    SafeReleaseFFmpeg();

    if (m_pthread != nullptr) {
        WaitForSingleObject(m_pthread->m_hThread, INFINITE);
        m_pthread = nullptr;
    }

    DebugMsg("All resources released successfully.");
}

// End of File